<?php

 // start session, authenticate user....
 session_start();
 
 // Start output buffer
 ob_start();
 
 // include config file containing directory paths
 require_once 'include/config.php';
 
 // include error handling class php file
 require_once 'error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 
 // Call the home page functions to display html content on screen
 
 fixed_html_header('CalculTELLER: Terms and Conditions',
                      '', $user_name, $member);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

?>

  <div class="extra_page_content">
    
   <h1>Calculteller Privacy Policy</h1>
    
    <p>
     Last updated: November 3, 2018.
     CalculTELLER is aware that you care how information about you is used and 
     shared, and we appreciate your trust that we will do so carefully and 
     sensibly. This notice describes our privacy policy. By visiting 
     calculteller, you are accepting the practices described in this Privacy 
     Notice.
     </p> 
     <h2>What Personal Information About User Does Calculteller Gather?</h2>
       <p>
         The information we learn from customers helps us personalize and 
         continually improve your CalculTELLER experience. Here are the types 
         of information we gather. Information You Give Us: We receive and store
          any information you enter on our Web site or give us in any other way.
           We use the information that you provide for such purposes as 
           responding to your requests, customizing future expriences for you,
            improving our application, and communicating with you. Automatic 
            Information: We receive and store certain types of information 
            whenever you interact with us. For example, like many Web sites, 
            we use "cookies," and we obtain certain types of information when 
            your Web browser accesses calculteller or advertisements and other 
            content served by or on behalf of calculteller on other Web sites.
      <h2>What About Cookies?</h2>
         <p>
         Cookies are unique identifiers that we transfer to your device to 
         enable our systems to recognize your device and to provide features 
         such as, Recommended for You, personalized advertisements on other 
         Web sites. Cookies and Submission of Information This site uses COOKIES
          to store user preferences in order the enhance user experience on 
          this site. Calculteller respects your privacy. We don NOT share 
          your private information with third parties. 
          This site contains links to other sites. Calculteller is not 
          responsible for the content of any linked site. The inclusion of any 
          link does not imply endorsement or approval by calculteller of the 
          information or products available at these sites.
          </p>
      <h2>Does Top10greatcars.com Share the Information It Receives?</h2>
        <p>
         Information about our customers is an important part of our 
         application, and we are not in the business of selling it to others.
         We do NOT share your personal information with third parties. We 
         use your information only within our company to provide your 
         reliable and optimum services.
        </p> 
    
    
    <!--End of extra-page-content div-->
  </div>
<?php

fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();
?>