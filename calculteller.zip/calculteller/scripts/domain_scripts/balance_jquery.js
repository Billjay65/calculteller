$(document).ready(function(){

  /*

    $("#balanceFormTab1").submit(function(){
        $.post( "balance.php",
        $("#balanceFormTab1").serialize(),
        function(data){
                   alert(data);    
        });
        return false;      
    });   
   */ 
    
});




//window.addEventListener('load', function() { // not needed because
// we are using onsubmit directly on the form

// New coded
/*
var balanceFormTab1 = document.getElementById('balanceFormTab1');

balanceFormTab1.addEventListener("submit", addProductToCart, false );
*/
// END new code

console.log("balance_query started successfully")

// Holds an instance of XMLHttpRequest
var xmlHttp = createXmlHttpRequestObject();

// Display error messages (true) or degrade to non-AJAX behavior (false) 
var showErrors = true;

// Contains the link or form clicked or submitted by the visitor
var actionObject = '';

// Creates an XMLHttpRequest instance
function createXmlHttpRequestObject()
{
  // Will store the XMLHttpRequest object
  var xmlHttp;

  // Create the XMLHttpRequest object
  try
  {
    // Try to create native XMLHttpRequest object 
    xmlHttp = new XMLHttpRequest();
  }
  catch(e)
  {
    // Assume IE6 or older
    var XmlHttpVersions = new Array(
      "MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.5.0", "MSXML2.XMLHTTP.4.0", 
      "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP");

    // Try every id until one works
    for (i = 0; i < XmlHttpVersions.length && !xmlHttp; i++)
    {
      try
      {
        // Try to create XMLHttpRequest object
        xmlHttp = new ActiveXObject(XmlHttpVersions[i]);
      }
      catch (e) {} // Ignore potential error
    }
  }

  // If the XMLHttpRequest object was created successfully, return it 
  if (xmlHttp)
  {
    return xmlHttp;
  }
  // If an error happened, pass it to handleError
  else 
  {
    handleError("Error creating the XMLHttpRequest object.");
  }
}

// Displays an the error message or degrades to non-AJAX behavior
function handleError($message)
{
  // Ignore errors if showErrors is false
  if (showErrors)
  {
    // Display error message
    alert("Error encountered: \n" + $message);
    return false;
  }
  // Fall back to non-AJAX behavior 
  else if (!actionObject.tagName)
  {
    return true;
  }
  // Fall back to non-AJAX behavior by following the link
  else if (actionObject.tagName == 'A')
  {
    window.location = actionObject.href;
  }
  // Fall back to non-AJAX behavior by submitting the form
  else if (actionObject.tagName == 'FORM')
  {
    actionObject.submit();
  }
}

// Calculates the balance simple
function findBalanceSimple(form)
{
  
  console.log("Called function addProductToCart");
  
 
  // Display "Updating" message
  document.getElementById('updating').style.visibility = 'visible';

  // Degrade to classical form submit if XMLHttpRequest is not available 
  if (!xmlHttp) return true;
  
   
  // Create the URL we open asynchronously 
  request = form.action;
  params  = '';

  
  // obtain selected attributes
  formSelects = form.elements;
  if (formSelects)
  {
    for (i = 0; i < formSelects.length; i++)
    {
      params += '&' + formSelects[i].name + '=';
      value = formSelects[i].value;
      params += value;
    }
  }
  
  console.log(params);
  
  

  // Try to connect to the server
  try
  {
    // Continue only if the XMLHttpRequest object isn't busy
    if (xmlHttp.readyState == 4 || xmlHttp.readyState == 0)
    {
      // Make a server request to validate the extracted data
      xmlHttp.open("POST", request, true);
      xmlHttp.setRequestHeader("Content-Type", 
                               "application/x-www-form-urlencoded");
      xmlHttp.onreadystatechange = findBalanceSimpleStateChange;
      xmlHttp.send(params);
    }
  }
  catch (e)
  {
    // Handle error
    handleError(e.toString());
  }
  

  // Stop classical form submit if AJAX action succeeded
  return false;
}

// Function that retrieves the HTTP response
function findBalanceSimpleStateChange()
{
   console.log("Called function addToCartStateChange");
  
  // When readyState is 4, we also read the server response
  if (xmlHttp.readyState == 4)
  {
    // Continue only if HTTP status is "OK"
    if (xmlHttp.status == 200)
    {
      try
      {
        updateBalanceSimple();
      }
      catch (e)
      {
        handleError(e.toString());
      }
    }
    else
    {
      handleError(xmlHttp.statusText);
    }
  }
  
}

// Process server's response
function updateBalanceSimple()
{
  console.log("Called function updateCartSummary");
  
 
  console.log("Called function updateCartSummary");
  
  // Read the response
  response = xmlHttp.responseText;
  
  
  console.log(response);
  
  
  // Server error?
  if (response.indexOf("ERRNO") >= 0 || response.indexOf("error") >= 0)
  {
    handleError(response);
  }
  else
  {
    var matches = response.match(/<input type="text" name="amount3"([\s\S]*)id="amount3">/gm);
  
    // <input type=\"text\" name=\"amount3\"  class=\"introaloneanswer\"  \r\n                    value=\"0\" id=\"amount3\">
  
    console.log(matches);
  
    var valueString = matches[0];
  
    console.log(typeof(valueString));
  
    var matches = valueString.match(/value="([\w]*)"/);
  
    value = matches[1];
  
    console.log(matches);
  
    // Update the cart summary box and hide the Loading message
    document.getElementById("amount3").value = value;
    // Hide the "Updating..." message
    document.getElementById('updating').style.visibility = 'hidden';
  }

  
    /*
  // const xmlDoc = xmlHttp.responseXML;
  //console.log(xmlDoc);
  
  // The fix is to parse the responseText back to an XML document ,
  // and then use this.
  var parser = new DOMParser();
  var xmlDoc = parser.parseFromString(xmlHttp.responseText, "application/xml");
  console.log(xmlDoc);
    
const x = xmlDoc.getElementsByTagName("ARTIST");

let txt = "";
for (let i = 0; i < x.length; i++) {
  txt += x[i].childNodes[0].nodeValue + "<br>";
}
document.getElementById("demo").innerHTML = txt;
  */

   
}



   




//});
