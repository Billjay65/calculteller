 function validate(){ 
  
     var emailID = document.contactForm.email.value; 
     atpos = emailID.indexOf("@"); 
     dotpos = emailID.lastIndexOf("."); 
     
     var txtadd =document.getElementById("txtSum");
    
     
   if (atpos < 1 || ( dotpos - atpos < 2 ))  
   { 
       alert("Please enter correct email ") 
       document.contactForm.email.focus() ; 
       return false; 
   } 
    if( document.contactForm.name.value =="") 
   { 
     alert( "Please provide your name!" ); 
     document.contactForm.name.focus() ; 
     return false; 
   }
    if( document.contactForm.subject.value =="") 
   { 
     alert( "Please provide a Subject!" ); 
     document.contactForm.subject.focus() ; 
     return false; 
   } 
  
   if( document.contactForm.message.value =="") 
   { 
     alert( "Please type your message!" ); 
     document.contactForm.message.focus() ; 
     return false; 
   }
    
   
  
   if(!(txtadd.value == "5")) 
   { 
     alert( "Please enter correct verification value" ); 
     document.contactForm.txtSum.focus() ; 
     return false; 
   } 
   
  
    return (true)
  }