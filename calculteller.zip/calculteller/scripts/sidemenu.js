
 /* Set the width of the side navigation to 250px */
 function openNav() {
     var mySidenav = document.getElementById("mySidenav");
     mySidenav.style.width = "250px";
   
 }

 /* Set the width of the side navigation to 0 */
 function closeNav() {
    var mySidenav = document.getElementById("mySidenav");
   mySidenav.style.width = "0";
 }
   
 