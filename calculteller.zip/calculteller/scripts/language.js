/* Set the width of the side navigation to 250px */
 function openLang() {
     var mySidenav = document.getElementById("lang_header_form");
     mySidenav.style.width = "250px";
   
 }

 /* Set the width of the side navigation to 0 */
 function closeLang() {
    var mySidenav = document.getElementById("lang_header_form");
   mySidenav.style.width = "0";
 }