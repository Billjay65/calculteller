<?php

 // start session, authenticate user....
 session_start();
 
 // Start output buffer
 ob_start();
 
 // include config file containing directory paths
 require_once 'include/config.php';
 
 // include error handling class php file
 require_once 'error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 
 
 //Variable to get search_term from form displayed in header
 if(isset($_GET['search_term']) && isset($_GET['search_button'])) 
 {
      $search_term = $_GET['search_term']; 

  }
/*Search functions used to search and display results*/

function fixed_html_sidebar_search(){

?>
 
    <div id="sidebar">
  <!--side bar: contains SEARCH BOX at the top and CalcuTeller functions.. -->
    
 <?php
 
}

function display_domains_list_search($search_term){

 
   $domainId = '';
   $selectedDomain = 0;
   $selected = '';
 
 // number of records to be displayed per page
 $records_per_page = DOMAINS_PER_PAGE;
 
 // look for starting marker
 // if not available, assume 0
 (!isset($_GET['start'])) ? $start = 0 : $start = $_GET['start'];
 
 // look for domain_id to use in domain list foward and back links
 // if not available set domaind_id to empty string 
 
 (!isset($_GET['domain_id'])) ? $domainId='' : $domainId = $_GET['domain_id'];
 
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];  
    
    
    
        
    
 //start of new code
 function getmicrotime() 
 { 
    list($usec, $sec) = explode(" ", microtime()); 
    return ((float)$usec + (float)$sec); 
 } 

//max number of results on the page 
 $RESULTS_LIMIT=DOMAINS_PER_PAGE; 

if(isset($_GET['search_term']) && (!empty($_GET['search_term'])) && isset($_GET['search_button'])) 
{ 
      $search_term = trim($_GET['search_term']); 
      
    if(!isset($first_pos)) 
    { 
        $first_pos = 0; 
    } 
    
    $start_search = getmicrotime(); 
    
    
    $query = "SELECT * FROM domain WHERE MATCH(name,description) 
                 AGAINST('$search_term')";   
    $result = getAll($query, $params=NULL); 
    
    $numRows = sizeof($result); 
     


    //additional check. Insurance method to re-search the database again in case of too 
    //many matches (too many matches cause returning of 0 results) 
    if($numRows != 0) 
    { 
        $sql = "SELECT * FROM domain WHERE MATCH(name,description) 
                AGAINST('$search_term') LIMIT $first_pos, $RESULTS_LIMIT"; 
                
                 $result_query = getAll($query, $params=NULL);         

    } 
    else 
    { 
        $query = "SELECT * FROM domain WHERE (name LIKE 
                  '%".addslashes($search_term)."%' 
                  OR description LIKE '%".$search_term."%') "; 
                    
                   $result = getAll($query, $params=NULL); 
    
                   $numRows = sizeof($result); 
                   
                   
                    $sql =  "SELECT * FROM domain WHERE (name LIKE 
                          '%".$search_term."%' OR article LIKE '%".$search_term."%')
                           LIMIT $first_pos, $RESULTS_LIMIT";  
                
                    $result_query = getAll($query, $params=NULL);  
                   
                 
    } 
    $stop_search = getmicrotime(); 
      //calculating the search time 
    $time_search = ($stop_search - $start_search); 

    
 
   
 
 // if records exist
 if($numRows != 0)
 {
   
     // Array function sizeof() is used to find the number of results return
     
    echo '<div class="box">';
    
     //NEW CODE
    echo '<p  class="box-title>Results for<i><b><font  color=#000000> '.$search_term.'</font></b></i>';
    echo '</p>';
    
    echo '<p  class="box-title><b>Results '.($first_pos+1).' - '; 
    
      if(($RESULTS_LIMIT + $first_pos) < $numRows) 
              echo ($RESULTS_LIMIT + $first_pos); 
      else 
         echo $numRows.'</b>' ; 
    
    echo ' out of <b>'.$numRows.'</b> for <b>'.
           sprintf("%01.2f", $time_search).' </b> 
          seconds
          </p>';
    //END OF NEW CODE
    
    echo '<ul>';
  
    for($i=0; $i < $numRows; $i++)
    {
     echo   '<li>';
     
     /* If DomainId  exists in the query string, we're visiting a
       domain */
    if (isset ($_GET['domain_id']))
      $selectedDomain = (int)$_GET['domain_id'];

    if ($selectedDomain == $result[$i]['domain_id'])
     $selected = 'class="selected"';
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomain($result_query[$i]['name'], 
             $result_query[$i]['domain_id']). ">";
     echo $result_query[$i]['name'];
     echo   '</a>';
     echo '</li>';
        
    }
    
    $sites = 0; 
    //NEW CODE
    
    //displaying the number of pages where the results are sittuated  
if($first_pos > 0) 
{ 
  $back=$first_pos-$RESULTS_LIMIT; 
  if($back < 0) 
  { 
    $back = 0; 
  } 
  echo "<a href='search.php?search_term=".stripslashes($search_term).
   "&first_pos=".$back."></a>"; 
} 
if($numRows>$RESULTS_LIMIT) 
{ 
  $sites=intval($numRows/$RESULTS_LIMIT); 
  if($result%$RESULTS_LIMIT) 
  { 
    $sites++; 
  } 
} 
for ($i=1;$i<=$sites;$i++) 
{ 
  $fwd=($i-1)*$RESULTS_LIMIT; 
  if($fwd == $first_pos) 
  { 
      echo '<a href="search.php?search_term='.stripslashes($search_term).
         '&first_pos='.$fwd.'"><b>'.$i.'</b></a> | '; 
  } 
  else 
  { 
      echo '<a href="search.php?search_term='.stripslashes($search_term).
       '&first_pos='.$fwd.'">'.$i.'</a> | ';    
  } 
} 
if(isset($first_pos) && $first_pos < $numRows-$RESULTS_LIMIT) 
{ 
  $fwd=$first_pos+$RESULTS_LIMIT; 
  echo '<a href="search.php?search_term='.stripslashes($search_term).
     '&first_pos='.$fwd.'> >></a>'; 
  $fwd=$numRows-$RESULTS_LIMIT; 
}


    echo '</ul></div>';  

  }
  else{
    echo '<p align="center">No results for <i><b><font 
             color="#000000">'.$search_term.'</font></b></i></p>'; 
    echo '</ul></div>'; 
 }
 

}


else{
    echo '<p align="center">No results for <i><b><font 
             color="#000000">'.$search_term.'</font></b></i></p>'; 
    echo '</ul></div>'; 
}


//END OF display_domains_list_search() Function
}
  




function fixed_html_content_search(){
 ?>  
    </div>
    <div id="ct-main">
            
       
            
<?php
}

function display_domain_image_links_search($search_term){

   $domainId = '';
   $selectedDomain = 0;
   $selected = '';
 
 // number of records to be displayed per page
 $records_per_page = DOMAINS_PER_PAGE;
 
 // look for starting marker
 // if not available, assume 0
 (!isset($_GET['start'])) ? $start = 0 : $start = $_GET['start'];
 
 // look for domain_id to use in domain list foward and back links
 // if not available set domaind_id to empty string 
 
 (!isset($_GET['domain_id'])) ? $domainId='' : $domainId = $_GET['domain_id'];
 
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];  
    

//max number of results on the page 
 $RESULTS_LIMIT=DOMAINS_PER_PAGE; 

if(isset($_GET['search_term']) && (!empty($_GET['search_term'])) && isset($_GET['search_button'])) 
{ 
      $search_term = trim($_GET['search_term']); 
      
    if(!isset($first_pos)) 
    { 
        $first_pos = 0; 
    } 
    
    $start_search = getmicrotime(); 
    
    
    $query = "SELECT * FROM domain WHERE MATCH(name,description) 
                 AGAINST('$search_term')";   
    $result = getAll($query, $params=NULL); 
    
    $numRows = sizeof($result); 
     
     

    //additional check. Insurance method to re-search the database again in case of too 
    //many matches (too many matches cause returning of 0 results) 
    if($numRows != 0) 
    { 
        $sql = "SELECT * FROM domain WHERE MATCH(name,description) 
                AGAINST('$search_term') LIMIT $first_pos, $RESULTS_LIMIT"; 
                
                 $result_query = getAll($query, $params=NULL);         

    } 
    else 
    { 
        $query = "SELECT * FROM domain WHERE (name LIKE 
                  '%".addslashes($search_term)."%' 
                  OR description LIKE '%".$search_term."%') "; 
                    
                   $result = getAll($query, $params=NULL); 
    
                   $numRows = sizeof($result); 
                   
                   
                    $sql =  "SELECT * FROM domain WHERE (name LIKE 
                          '%".$search_term."%' OR article LIKE '%".$search_term."%')
                           LIMIT $first_pos, $RESULTS_LIMIT";  
                
                    $result_query = getAll($query, $params=NULL);  
                   
                 
    } 
    $stop_search = getmicrotime(); 
      //calculating the search time 
    $time_search = ($stop_search - $start_search); 

  // if records exist
 if($numRows != 0)
 {
   
     // Array function sizeof() is used to find the number of results return
     
    echo '<div class="box">';
    
     //NEW CODE
    echo '<p>Results for<i><b><font  color=#000000> '.$search_term.'</font></b></i>';
    echo '</p>';
    
    echo '<p><b>Results '.($first_pos+1).' - '; 
    
      if(($RESULTS_LIMIT + $first_pos) < $numRows) 
              echo ($RESULTS_LIMIT + $first_pos); 
      else 
         echo $numRows.'</b>' ; 
    
    echo ' out of <b>'.$numRows.'</b> for <b>'.
           sprintf("%01.2f", $time_search).' </b> 
          seconds
          </p>';
    //END OF NEW CODE
          
  
    
      /* New code*/
      
       // iterate over domain images 
    // display each image as a link to that domain
    
    echo '<ul class="domain_image_links">';
 
   for($i=0; $i < $numRows; $i++)
   {
       $domain_image = '';
      $domain_image = strtolower(strip_tags($result_query[$i]['image']));

      
   
     echo   '<li>';
     
     /* If DomainId  exists in the query string, we're visiting a
       domain */
    if (isset ($_GET['domain_id']))
      $selectedDomain = (int)$_GET['domain_id'];

    if ($selectedDomain == $result_query[$i]['domain_id'])
     $selected = 'class="selected"';
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomain($result_query[$i]['name'],
                        $result_query[$i]['domain_id']). ">";
     
     // display image link for each domain
      
     echo '<img src="'. Link::Build('images/'.$domain_image). '" alt="domain-image" 
             width="200px" height="140px" />';
     
     echo '<p>'.$result_query[$i]['name'].'</p>';
     echo   '</a>';
     echo '</li>';
  }
  echo '</ul>';
      
      /*End of new code*/
    
       
    
    $sites = 0;
    
    
     
   
    echo '</div>';  

  }
  else{
    echo '<p align="center">No results for <i><b><font 
             color="#000000">'.$search_term.'</font></b></i></p>'; 
    echo '</ul></div>'; 
 }
 
   // set up the previous page link
    // this should appear on all pages except the first page
    // the start point for the previous page will be 
    // the start point for this page 
    // less the number of records per page 
    // htmlentities() function is used to replace <, >, special character
    // to prevent them from being interpreted as HTML by the browers
    
    //use htmlentities() to create <<Backward and Foward>> buttons
    $specialBackward= htmlentities('<<');
    $specialFoward = htmlentities('>>');
    
  if ($first_pos >= $records_per_page)   
  {    
    echo "<a href=" . $_SERVER['PHP_SELF'] . 
    "?start=" . ($first_pos-$records_per_page) ."&domain_id=".$domainId. ">". $specialBackward. "Backward </a>";
  }
    
    // set up the "next page" link
    // this should appear on all pages except the last page
    // the start point for the next page 
    // will be the end point for this page
    if ($first_pos+$records_per_page < $numRows && $first_pos >= 0) 
    {
        echo "<a href=" . $_SERVER['PHP_SELF'] . 
     "?start=" . ($first_pos+$records_per_page) ."&domain_id=".$domainId. ">Foward".$specialFoward."</a>";
    }
  
  
  echo '</center>';
  echo '</div>';
  
 }
  else{
    echo '<p align="center">No results for <i><b><font 
             color="#000000">'.$search_term.'</font></b></i></p>'; 
    echo '</ul></div>'; 
  }

?> 

<?php
  
}

/*End of Search functions*/ 


// Call the home page to display html content on screen
 

 fixed_html_header('CalculTELLER: Search',
                      'Search calculteller', $user_name, $member, $search_term);

//call search functions
fixed_html_sidebar_search();
display_domains_list_search($search_term);
fixed_html_content_search();
display_domain_image_links_search($search_term);


fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>