<?php 

 require_once 'include/config.php';
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
  echo 'rows';
 
 // create and execute SELECT query 
$sql = "SELECT COUNT(*) FROM artists "; 



 $rows = getOne($sql, $params=NULL);
 
   
 echo $rows[0];
 $sql = "SELECT artist_id, artist_name FROM artists";
  $result = getAll($sql, $params=NULL);
  
  for($i=0; $i < $rows[0]; $i++)
      echo $result[$i]['artist_name'] ; 
      
// INSERT query and obtain the lastInsertId
$sql =  "INSERT INTO artists (artist_name, artist_country) VALUES
       ('Drake', 'JC')";
    $id = executeQuery($sql, $params=NULL); 
    echo "$id";

    
unset($database_handler); 
 
/*
// attempt a connection 
try { 
   $pdo = new PDO('mysql:dbname=music;host=localhost', 'jay.v', 'Sikehjaphetberyuf12'); 
} catch (PDOException $e) { 
   die("ERROR: Could not connect: " . $e->getMessage()); 
} 
 
// create and execute SELECT query 
$sql = "SELECT artist_id, artist_name FROM artists"; 
if ($result = $pdo->query($sql)) { 
  while($row = $result->fetch()) { 
    echo $row[0] . ":" . $row[1] . "\n"; 
  } 
} else { 
  echo "ERROR: Could not execute $sql. " . print_r($pdo->errorInfo()); 
} 
 
// close connection 
unset($pdo); 
*/

?>