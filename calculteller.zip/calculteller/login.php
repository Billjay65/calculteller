<?php

// Start session and read username from session variable if it is set
 session_start();  

// include config file containing directory paths
 require_once 'include/config.php';
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';


 // Get web browser language of User 
// get first value(Primary Language) from language array
 $browserLanguage = $_SERVER['HTTP_ACCEPT_LANGUAGE'][0] 
                      . $_SERVER['HTTP_ACCEPT_LANGUAGE'][1];
                      
  // Get selected language of page default is en
  // include language configuration file based on selected language
	$language = "en";
                      
  // Create session variable to store selected language
  if(isset($_SESSION['language'])){
     $userLanguage = $_SESSION['language'];
     $language     = $userLanguage; 
  }
  else{
     $userLanguage = ''; 
  }
 
 

  
  // read browser language Only when user language SESSION variable
  // is NOT SET(equals ''), if userLanguage is set, do not use browser language
  if((!empty($browserLanguage)) && ($browserLanguage == 'en' ||
       $browserLanguage == 'fr' || $browserLanguage == 'es'
       || $browserLanguage == 'zh')
      && ($userLanguage =='')){
    $language = $browserLanguage;
      
  }
  
	if(isset($_GET['lang'])){ 
		$language = $_GET['lang'];
    $_SESSION['language'] = $language;
     
	} 
 
   
  // get language file based on user's language
	require_once(SITE_ROOT."/values/".$language.".php");


 // read cookie and assign cookie values 
// to PHP variables
 $username = ''; 
 $user_name_cookie = isset($_COOKIE['username']) ? $_COOKIE['username'] : '';
  
 
 if($user_name_cookie!='')
 {
    $username = $user_name_cookie;
 
 }


    // display input validation error 
    function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        return "<div class=\"error\">ERROR: Invalid data for field '$key'</div>"; 
      } else { 
        return false; 
      } 
    } 
    
    
   $editMode = 0;
   $errorFlag = 0;
   //$errorHeader = 'ERROR: Form filled incorrectly, Please correct error';
   $errorHeader = '';
   //$successHeader, displayed if registration or login is successful
   $successHeader = false;
 /* 
  $nameError = 0;
  $emailAlreadyTaken = 0;
  $emailError = 0;
  $passwordError = 0;
  $passwordConfirmError = 0;
  $passwordMatchError = 0;
  */
  $linkToAccountDetails;
  $linkToCancelPage = Link::Build('index.php');

 
    $inputErrors = array(); 
    $submitted = false; 
    
    
 
 
    // if form submitted 
    // validate form input 
if (isset($_POST['submit'])) 
{ 
  
      $submitted = true; 
      $valid = array(); 
      $_username = '';
      $_password = '';
      $_email = '';
      
   
       // validate username atmost 14 characters 
      if (!empty($_POST['username']) && preg_match('/^([a-zA-Z]){2,20}$/', $_POST['username'])) { 
        $_username = htmlentities(trim($_POST['username'])); 
       
         // Check if username is unique
         // create and execute SELECT query 
        $sql = "SELECT COUNT(*) FROM user
                WHERE username = '$_username'"; 

        $row1 = getOne($sql, $params=NULL);
 
   
         if($row1[0]== 1)
         {
            $valid['username'] = htmlentities(trim($_POST['username']));
            $_username = $valid['username'];
         }
         else
         {
           $inputErrors[] = 'Username';
           $errorFlag = 1; 
         }
                
      } 
      else { 
        $inputErrors[] = 'Username';
        $errorFlag = 1; 
      } 
      
      
 
      // validate user password Must start with Capital letter atleast 4 characters long
      
      if (!empty($_POST['password']) && preg_match('/^([A-Z])+([a-zA-Z0-9]){3,16}$/',
           $_POST['password']))  { 
      
        $_password = htmlentities(trim($_POST['password']));
        $_hpassword = PasswordHasher::Hash($_password, true); 
        
        // Check if hashed password matches with username and if it Exist in database
          $sql = "SELECT COUNT(*) FROM user
                WHERE username = '$_username'
                AND   password = '$_hpassword'"; 

          $row1 = getOne($sql, $params=NULL);
          
          if($row1[0]== 1)
          {
            $valid['password'] = htmlentities(trim($_password));
          }
          else { 
          
           $inputErrors[] = 'Password';
           $errorFlag = 3; 
         }                              
      } 
      else { 
        
        $inputErrors[] = 'Password';
        $errorFlag = 3; 
      } 
     
      
        $valid['date'] = date("Y-m-d H:i:s", time());
      
      if($errorFlag > 0)
      $errorHeader = 'ERROR: Form filled incorrectly, Please correct errors';
      
/*      
 if(($errorFlag == 0) || count($inputErrors) == 0)
 {    
  // sanitize data and insert into database including date
  $name = addslashes($valid['name']);
  $username = addslashes($valid['username']);
  $password = addslashes($valid['password']);
  $email = addslashes($valid['email']);
  $address = addslashes($valid['address']);
  $city = addslashes($valid['city']);
  $region = addslashes($valid['region']);
  $country = addslashes($valid['country']);
  $phone = addslashes($valid['phone']);
  $date = addslashes($valid['date']);
  //print_r($valid);
 } 
 */  
               
} 


 // if form is submitted with no errors 
  // write the input to the database 

if(($submitted == true && count($inputErrors) <= 0)) 
{ 
   
  // sanitize data and insert into database including date
  $date = addslashes($valid['date']);
  $username = addslashes($valid['username']);
  
  // Update lvisit column of user table
  // Insert data into database 
  
    $sql = "UPDATE user SET lvisit = '$date'
            WHERE username = '$username'";

    // Execute the query
     $lastInsertId = executeQuery($sql, $params = null);
    
   
   // Get User name from database
   
    // get domain units
   
    
   $query = "SELECT    name
               FROM    user
               WHERE   username = '$username'";
                 
   $result = getRow($query, $params = null); 
    $name = strip_tags($result['name']);
  
    $firstName = explode(' ', $name);
 
  
   // register session variables
  $_SESSION['name'] = $firstName[0];
 $_SESSION['username'] = $username;

 
 // SET cookies
 $app_name = 'CalculTELLER';
 $ret1 = (isset($username)) ? setcookie('username', $username, 
           time() + 172800, '/') : null;
 $ret2 = (isset($app_name)) ? setcookie('app_name', $app_name, 
           time() + 172800, '/') : null;

/*
// read cookie and assign cookie values 
// to PHP variables 
$username = isset($_COOKIE['username']) ? $_COOKIE['username'] : ''; 
$app_name = isset($_COOKIE['$app_name']) ? $_COOKIE['$app_name'] : '';

*/
 echo count($inputErrors);
 
 $successHeader = true;
 
 
  // Redirect user to index if login is successful
 header('Location:'.$linkToCancelPage);
 exit();
  
  
 }
 
    // if form not submitted  Only
    // or if validation errors exist 
    // (re)display form 
elseif (($submitted == true && count($inputErrors) > 0) || $submitted == false) 
{ 

  do_html_header($lang['login_title'], $lang['login_heading'], 
                  $errorHeader, $successHeader); 
  if(isset($_SESSION['name']) && ($_SESSION['name']!='' ) && ($successHeader==true))
  {
     echo '<h2>'.'Registration Successful!' .'</h2>';
     echo '<span style="font-size: 170%;">'.'Hi '.'</span>'.'<span class="success">'.$_SESSION['name']. '<br />'.
          'Click '.'<a href="'. $linkToCancelPage.'">'.' HERE to START'.'</a>'.'</span>' ;
  } 
  
  
 ?>
 
 
 <form id="login_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"> 
  <h3><?php if(isset($lang['login_form_title']))
               echo $lang['login_form_title'];
           else 
              echo 'CalculTELLER Log in'; ?> </h3>
      <label>
       <?php if(isset($lang['username']))
               echo $lang['username'];
           else 
              echo 'Username:'; ?>   
      </label> <br /> 
      <input type="text" name="username"  
        value="<?php echo isset($_POST['username']) ? $_POST['username'] : $username;?>" 
        size="36" maxlength="14" />
        <?php echo getInputError('Username', $inputErrors); ?> 
        
      <br /><br />
      <label>
        <?php if(isset($lang['password']))
               echo $lang['password'];
           else 
              echo 'Password:'; ?>   
      </label> <br /> 
      <input type="password" name="password" size="36" maxlength="36"
         value="<?php echo isset($_POST['password']) ? $_POST['password'] : '';?>" />
        <?php echo getInputError('Password', $inputErrors); ?> 
       
       <br /><br />
      <input type="submit" name="submit" 
         value="<?php if(isset($lang['login_btn']))
                         echo $lang['login_btn'];
                      else 
                          echo 'Log In'; ?> " /> 
      <p>
      <a href="reset_password.php" title="Sign up if you are a new member">
         <?php if(isset($lang['forgot_passwd']))
                         echo $lang['forgot_passwd'];
                      else 
                          echo 'Forgot Password'; ?>  </a>&nbsp;
       <a href="register_user.php" title="Sign up if you are a new member"> 
         <?php if(isset($lang['register']))
                         echo $lang['register'];
                      else 
                          echo 'Register'; ?></a>
      </p>
    </form>                   

<?php 

 
  
} 

 
 
 
 unset($database_handler);

do_html_footer($lang);
?>