<?php

 // start session, authenticate user....
 session_start();
 
 // Start output buffer
 ob_start();
 
 // include config file containing directory paths
 require_once 'include/config.php';
 
 // include error handling class php file
 require_once 'error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
  // display input validation error 
    function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        return "<div class=\"error\">ERROR: Invalid data for field '$key'</div>"; 
      } else { 
        return false; 
      } 
    }
   
  //  form error variables   
  $editMode = 0;
  $errorFlag = 0;
  $inputErrors = array();  
    
  // variable to determine of form has been submitted
  $submitted = false; 
  
  // initial donation type initiation
  $donationType = '';  
  
// if form submitted 
// validate form input 
if (isset($_POST['submit'])) 
{ 
      
      $submitted = true; 
      $valid = array(); 
      $_username = '';
      $_email = '';  
      
      // define headers only if form is submitted
      // test if headers are set before displaying
      // their content above form
      $errorHeader = ''; 
      $successHeader = ''; 
      
      // get donation type
      $donationType = (!isset($_POST['donation_type']))? '': 
                        $_POST['donation_type'];    
      
      // validate user name 
      if (!empty($_POST['name']) && (strlen($_POST['name']) >= 2  && strlen($_POST['name']) < 100)) { 
        $valid['name'] = htmlentities(trim($_POST['name']));  
      } else { 
        $inputErrors[] = 'name'; 
        $errorFlag = 1; 
      } 
      
      // validate user email don't check for
      // email in database, user must not be registered to donate 
      if (!empty($_POST['email']) && preg_match('/^([a-z0-9_-])+([\.a-z0-9_-])*@([a-z0-9-])+(\ 
       .[a-z0-9-]+)*\.([a-z]{2,6})$/', $_POST['email'])) { 
       
        $valid['email'] = htmlentities(trim($_POST['email']));
       
      } else { 
        $inputErrors[] = 'email';
        $errorFlag = 2; 
      }
      
      // validate telephone number
      // first replace any space, or _- with empty string use str_replace()
      // from phone number before testing
      if(!empty($_POST['phone'])){
           
           // first initialize $phoneCleaned to empty variable before
           // cleaning the string
            $phoneCleaned = '';
            $phoneCleanedInt = '';
            
            $phoneCleaned = (string)($_POST['phone']);
            $phoneCleaned = str_replace('+', '', $phoneCleaned);
            $phoneCleaned = str_replace(' ', '', $phoneCleaned);
            $phoneCleaned = str_replace('-', '', $phoneCleaned);
    
            $phoneCleanedInt = $phoneCleaned;
            $phoneCleaned = '';
            
          
      }
                
                 
      // save cleaned phone number into database not the number posted by user
      if (!empty($phoneCleanedInt) 
                    && is_numeric($phoneCleanedInt) 
                     && preg_match('/^([0-9]){4,16}$/', ($phoneCleanedInt))) 
      { 
        $valid['phone'] = htmlentities(trim($phoneCleanedInt)); 
        
        //echo $valid['phone'];
      } else { 
        $inputErrors[] = 'Telephone';
        $errorFlag = 3; 
      }   
      
      // set valid date and time to email to support
      $valid['date'] = date("Y-m-d H:i:s", time());
      
      
      // if form contains errors, prepare error header message to display
      // if form submitted with no errors
      // send email to admin - calculteller@yahoo.com 
      // or support@calculteller.com add constant to config
      if($errorFlag > 0 && count($inputErrors) > 0)
      {
        $errorHeader = '<p class="error">ERROR: Form filled incorrectly, 
                        Please correct errors!
                        </p>';
      }
      else
      {
        
                        
        // prepare data to send by email
        $donationType = $donationType; 
        $name = $valid['name'];
        $email = $valid['email']; 
        $phone = $valid['phone'];
        $date =  $valid['date']; 
        
        // send email to admin or support
        $to = ADMIN_DONATE_MAIL;
        $subject = 'Donation Request';
        $email = $email;
        
        $mailBody = 'Calculteller Donations' . "\n"
                    .'From: ' . $email . "\n"
                    .'Subject: ' . $subject . "\n\r"
                    .'Message:' . "\n"
                    .'New donation request from ' . "\n"
                    ."\t" . $name . "\n"
                    ."\t" . $email . "\n"
                    ."\t" . $phone . "\n"
                    ."\t" . $date . "\n"
                    ."\t" . $donationType . "\n";
        
        
        // for testing purposes to display success or
        // error messages delete in production            
        $sent = true;            
       
        // Uncomment line below in production to send donation mail            
        if($sent /*mail($to, $subject, $mailBody)*/)
        {
           $successHeader = '<p class="success">
                         Successfull! We will send you an email
                         in a moment containing details on how to complete
                         your donation. 
                         We greatly appreciate your gesture!
                        </p>'; 
        }
        else
        {
          $errorHeader = '<p class="error">
                          ERROR: We encountered difficulties accepting
                          your donation at this moment.
                          Please try again later or
                          contact us through our contact us page.
                          </p>';
                          
          
                        
        }
        
      }
      
      // for testing purposes only delete in production
      // echo $donationType; 
       
            
}      
 
 
 // Call the home page functions to display html content on screen
 
 fixed_html_header('Donate to Calculteller',
                      '', $user_name, $member);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

?>

  <div class="extra_page_content">
    
    <form method="post" action="<?php echo $_SERVER['PHP_SELF'] . '#donate_form'; ?>"
       id="donate_form">
      <br /><br />
      
      <?php
        // display success or error messages depending
        // on whether email was sent or not 
        if (isset($errorHeader) &&  $errorHeader != '')
        {
          echo $errorHeader;
        } 
        elseif (isset($successHeader) &&  $successHeader != '')
        {
          echo $successHeader;
        } 
      ?>
      
      <h2>Thank you for your donation! <br />
          We use your funds to make calculteller better.</h2>
         
      <p>Please select a donation type:</p>
      
      <p>
      <input type="radio" name="donation_type" value="Credit Cards Paypal"
        <?php if ($donationType==''||$donationType=='Credit Cards Paypal')
                {echo 'checked';} 
             else 
               {echo '';} ?>  />
      PAYPAL, VISA, MASTERCARD, and Others
      </p>
      <img src="<?php echo LINK::Build('images/cards_pp.png'); ?>"  
          alt="paypal credit cards"   title="paypal credit cards" />
       <br />
     
      <p> 
      <input type="radio" name="donation_type" value="Cryptocurrency" 
        <?php if ($donationType=='Cryptocurrency') echo 'checked'; 
          else echo '';  ?>
      />
      Bitcoin, Dogdecoin, BNB and Others
      </p>
      <img src="<?php echo LINK::Build('images/cryptocurrency.png'); ?>"  
          alt="paypal credit cards"   title="paypal credit cards" />
      <br />
    
      <p> 
      <input type="radio" name="donation_type" value="Mobile Payment"
        <?php if ($donationType=='Mobile Payment') echo 'checked'; 
          else echo '';  ?>
       />
      MTN Momo, Orange Money and Other Mobile payments
      </p>
      <img src="<?php echo LINK::Build('images/mobile_payment.png'); ?>"  
          alt="paypal credit cards"   title="paypal credit cards" />
      <br /><br />
         
      <label>Full Name</label><br />
      <input type="text" name="name"  
        value="<?php echo isset($_POST['name']) ? htmlentities($_POST['name']) : '';?>" 
        size="40" maxlength="100"/>
        <?php echo getInputError('name', $inputErrors); ?> 
        <br />
        
      <label>Email</label><br />
      <input type="text" name="email"  maxlength="150"
        value="<?php echo isset($_POST['email']) ? htmlentities($_POST['email']) : '';?>" 
        size="40"?> 
      <?php echo getInputError('email', $inputErrors); ?> 
      <br />
        
      <label>Telephone <small>*please start with country code</small></label> <br />
      <input type="text" name="phone"  
        value="<?php echo isset($_POST['phone']) ? htmlentities($_POST['phone']) : '';?>"
        size="32" maxlength="50" />
      <?php echo getInputError('Telephone', $inputErrors); ?>
      <br />
        
      <input type="submit" name="submit" 
        value="<?php if(isset($lang['donate_btn']))
                        echo $lang['donate_btn'];
                     else 
                        echo 'Donate'; ?> "  />  
  </form>
      
    
    <!--End of extra-page-content div-->
  </div>
<?php

fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();
?>