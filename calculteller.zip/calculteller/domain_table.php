<html>
<head>
</head>
<body>
<div>
<table width="100%" border="0">
<form> 
  <tr> 
    <td colspan="3" bgcolor="#b5dcb3"> 
      <h1>This is Web Page Main title</h1> 
    </td> 
  </tr> 

  <tr valign="top"> 
    <td bgcolor="#aaa" rowspan="2"> 
      <b>Main Menu</b><br /> 
      HTML<br /> 
      PHP<br /> 
      PERL... 
    </td> 
    <td bgcolor="#eee" > 
        Technical and Managerial Tutorials 
    </td> 
    <td bgcolor="#eee"> 
        Technical and Managerial Tutorials 
    </td> 
  </tr> 

  <tr valign="top" > 
    
    <td bgcolor="#eee" > 
        Technical and Managerial Tutorials 
    </td> 
    <td bgcolor="#eee"> 
        Technical and Managerial Tutorials 
    </td> 
  </tr> 


  <tr> 
    <td colspan="3" bgcolor="#b5dcb3"> 
      <center> 
      Copyright � 2007 Tutorialspoint.com 
      </center> 
    </td> 
  </tr> 
</form>
</table> 
</div>
</body> 
</html> 


