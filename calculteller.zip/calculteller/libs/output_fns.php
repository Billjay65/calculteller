
<?php


function do_html_header($title, $heading, $errorHeader, $successHeader, 
                $rootDir=null, $lang=null)
{

  // Prepare all temporary variables holding lang disply strings
   $_loginTitle      = (isset($lang) && ($lang!=NULL))?
                        $lang['login_title'] : $title;
   $_loginHeading    = (isset($lang) && ($lang!=NULL))?
                        $lang['login_heading']: $heading;
                        
     // prepare language strings for ads bottom section
   $_langInvite  = (isset($lang) && ($lang!=NULL))? $lang['language_invite']:
                                                'Language';
   $_english     = (isset($lang) && ($lang!=NULL))? $lang['english'] :
                                                'English';
   $_french      = (isset($lang) && ($lang!=NULL))? $lang['french'] :
                                                'Français';
   $_spanish     = (isset($lang) && ($lang!=NULL))? $lang['spanish'] :
                                                'Espagnol';
   $_chinese     = (isset($lang) && ($lang!=NULL))? $lang['chinese'] :
                                                '??';
   

 // $rootDir is either root or VIRTUAL location of app i.e '/calculteller/' 
?>  
 <!DOCTYPE html>
<html>

 <head>
   
 <title> <?php echo $_loginTitle;?></title>
 
 
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
 <meta name="description" 
           content="Calculteller can defined as a calculator that speaks.
                    Calculteller(Ct) calculates the Past, the Present and 
                    predicts the Future in a few clicks. With calculteller,
                    you do not need a pen, paper or calculator.
                     Calculteller is all of the above and more." />

 <meta name="keywords" content="calculteller, calculate, calculator, 
                                domains, balance, bet, proportion, time, 
                                business, school, measurement,
                                math, age, how to calculate" /> 
 
 <meta charset="UTF-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />

 
  <link rel="icon" type="image/png" href=<?php echo Link::Build('images/favicon-robot.png'); ?> />
  
  
  
<script src=<?php echo Link::Build('scripts/css3-mediaqueries.min.js'); ?>></script>



  
<link rel="stylesheet" media="screen and (max-width: 600px)" href=<?php echo Link::Build('styles/login_styles_mobile.css'); ?> />
<link rel="stylesheet" media="screen and (min-width: 600px)" href=<?php echo Link::Build('styles/login_styles.css'); ?> />
 
   

  
   <style>
     
      
    </style>
  
  
  </head>
  
                    
<body> 

<a href=<?php echo  Link::Build('index.php'); ?> style="text-decoration: none;">
 <img id="logo_login" src=<?php echo Link::Build('images/favicon-robot.png'); ?> alt='Logo calculteller'/>
</a>

<span id="app" title="Calculteller">CalculTELLER</span> 

 <span class="login_lang"> 
          
              <a  href="login.php?lang=en">
                         <?php echo ' | '.$_english; ?> </a>
        
              <a  href="login.php?lang=fr">
                         <?php echo '| '.$_french; ?> </a>
            
              <a  href="login.php?lang=es">
                         <?php echo '| '.$_spanish; ?> </a>
              
              <a  href="login.php?lang=zh">
                         <?php echo '| '.$_chinese.' | '; ?> </a>
  </span> <br />
  
         
<hr style="clear:both"/>

<?php
  if($heading)
    do_html_heading($_loginHeading, $errorHeader);  
 // if($heading && $errorHeader)
}


function do_html_header2($title, $heading, $errorHeader, $successHeader, 
                $rootDir=null, $lang=null)
{

  // Prepare all temporary variables holding lang disply strings
   $_registerTitle      = (isset($lang) && ($lang!=NULL))?
                        $lang['register_title'] : $title;
   $_registerHeading    = (isset($lang) && ($lang!=NULL))?
                        $lang['register_heading']: $heading;
                        
     // prepare language strings for ads bottom section
   $_langInvite  = (isset($lang) && ($lang!=NULL))? $lang['language_invite']:
                                                'Language';
   $_english     = (isset($lang) && ($lang!=NULL))? $lang['english'] :
                                                'English';
   $_french      = (isset($lang) && ($lang!=NULL))? $lang['french'] :
                                                'Français';
   $_spanish     = (isset($lang) && ($lang!=NULL))? $lang['spanish'] :
                                                'Espagnol';
   $_chinese     = (isset($lang) && ($lang!=NULL))? $lang['chinese'] :
                                                '??';
   

 // $rootDir is either root or VIRTUAL location of app i.e '/calculteller/' 
?>  
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

 <head>
   
 <title> <?php echo $_registerTitle; ?> </title>
 
 
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
 <meta name="description" 
           content="Calculteller can defined as a calculator that speaks.
                    Calculteller(Ct) calculates the Past, the Present and 
                    predicts the Future in a few clicks. With calculteller,
                    you do not need a pen, paper or calculator.
                     Calculteller is all of the above and more." />

 <meta name="keywords" content="calculteller, calculate, calculator, 
                                domains, balance, bet, proportion, time, 
                                business, school, measurement,
                                math, age, how to calculate" /> 
 
 <meta charset="UTF-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />

 
  <link rel="icon" type="image/png" href=<?php echo Link::Build('images/favicon-robot.png'); ?> />
  
  
  
<script src=<?php echo Link::Build('scripts/css3-mediaqueries.min.js'); ?>></script>



  
<link rel="stylesheet" media="screen and (max-width: 600px)" href=<?php echo Link::Build('styles/login_styles_mobile.css'); ?> />
<link rel="stylesheet" media="screen and (min-width: 600px)" href=<?php echo Link::Build('styles/login_styles.css'); ?> />
 
   

  
   <style>
     
      
    </style>
  
  
  </head>
  
                    
<body> 

<a href=<?php echo  Link::Build('index.php'); ?> style="text-decoration: none;">
 <img id="logo_login" src=<?php echo Link::Build('images/favicon-robot.png'); ?> alt='Logo calculteller'/>
</a>

<span id="app" title="Calculteller">CalculTELLER</span> 

 <span class="login_lang"> 
          
              <a  href="register_user.php?lang=en">
                         <?php echo ' | '.$_english; ?> </a>
        
              <a  href="register_user.php?lang=fr">
                         <?php echo '| '.$_french; ?> </a>
            
              <a  href="register_user.php?lang=es">
                         <?php echo '| '.$_spanish; ?> </a>
              
              <a  href="register_user.php?lang=zh">
                         <?php echo '| '.$_chinese.' | '; ?> </a>
  </span> <br />
  
         
<hr style="clear:both"/>

<?php
  if($heading)
    do_html_heading($_registerHeading, $errorHeader);  
 // if($heading && $errorHeader)
}

function do_html_heading($heading, $errorHeader)
{
 // print an HTML heading similar to the title
 ?>
 <h2> <?php echo $heading?></h2>
 <span class="error_header" style=<?php  if(empty($errorHeader)) echo '"display:none"'; ?> >
     <?php echo $errorHeader;?></span>
 
 <?php
}

function display_site_info()
{
 // print HTML site info above login form
 ?>
 
 <h2>CalculTELLER Calculates the Past, Present and Future.
 <span style="font-size:smaller">It gives direction and meaning to your life</span> </h2>

  
 <?php
}

 function display_login_form()
 {
   // prints HTML login form
   ?>
  
   <form id="login_form" method="post" action=<?php echo Link::Build('index.php'); ?>> 
      <label>Username:</label> <br /> 
      <input type="text" name="username" /> 
      <br /><br />
      <label>Password:</label> <br /> 
      <input type="password" name="password" /> 
       <br /><br />
      <input type="submit" name="submit" value="Log In" /> 
      <p>
      <a href="register_user.php" title="Sign up if you are a new member">Register</a>
      </p>
    </form> 
   
   
   <?php
  
 }

 function do_html_footer($lang=null)
 {
 
   // Prepare all temporary variables holding lang disply strings
   $_termsConditions = (isset($lang) && ($lang!=NULL))?
                        $lang['terms_conditions'] : 'Terms and Conditions';
   $_privacyPolicy   = (isset($lang) && ($lang!=NULL))?
                        $lang['privacy_policy']: 'Privacy Policy';
   $_aboutus         = (isset($lang) && ($lang!=NULL))?
                         $lang['aboutus'] : 'About Us';
   $_sitemap         = (isset($lang) && ($lang!=NULL))?
                         $lang['sitemap'] : 'Sitemap'; 
   $_news            = (isset($lang) && ($lang!=NULL))?
                         $lang['news'] : 'News';
   $_tel             = (isset($lang) && ($lang!=NULL))?
                         $lang['tel'] : '+1 123 4550';
   $_helpFt          = (isset($lang) && ($lang!=NULL))?
                         $lang['help_ft']: 'Help';
  // prints HTML footer 
  ?>

   <div id="formft">
     <hr />
   
   
   <p class="terms_privacy">
     | <a href="terms-conditions.php" target="_blank">
         <?php echo $_termsConditions; ?> </a> 
       
     | <a href="privacy-policy.php" target="_blank">
         <?php echo $_privacyPolicy; ?></a> 
        
     | <a href="aboutus.php" target="_blank">
         <?php echo $_aboutus; ?></a>  
        
     | <a href="sitemap.xml" target="_blank">
         <?php echo $_sitemap; ?></a> 
        
     | <a href="mlm/index.php" target="_blank">
         <?php echo $_news; ?></a>| <br />
        
     | <a href="tel://+1 123 4550" target="_blank">
         <?php echo $_tel; ?> </a> 
        
     | <a href="forum.php" target="_blank">
         <?php echo $_helpFt; ?> </a>| 
    
    </p>
    
     <p> Copyright © 2017, CalculTELLER, wwww.calculteller.com</p>
     
   </div>
   
   </body>
</html>
   
  <?php
 }
 


 
function fixed_html_header($title, $heading, $user_name, $member=false, 
                      $search_term=null, $lang=null, $language=null)
{
   // Prepare all temporary variables holding lang disply strings
   $_appName = (isset($lang) && ($lang!=NULL))? $lang['app_name_caps'] :
                                             'CalculTELLER'; 
   $_home    = (isset($lang) && ($lang!=NULL))? $lang['home'] :
                                             'Home';
                                                                                          
   $_logout  = (isset($lang) && ($lang!=NULL))? $lang['logout'] :
                                              'Logout';
                                               
   $_login   = (isset($lang) && ($lang!=NULL))?  $lang['login'] :
                                               'Login';
                                                 
   $_signup  = (isset($lang) && ($lang!=NULL))? $lang['signup'] :
   
                                                'Signup';
   $_langInvite  = (isset($lang) && ($lang!=NULL))? $lang['language_invite']:
                                                'Language';
   $_english  = (isset($lang) && ($lang!=NULL))? $lang['english'] :
                                                'English';
   $_french  = (isset($lang) && ($lang!=NULL))? $lang['french'] :
                                                'Français';
   $_spanish  = (isset($lang) && ($lang!=NULL))? $lang['spanish'] :
                                                'Espagnol';
   $_chinese  = (isset($lang) && ($lang!=NULL))? $lang['chinese'] :
                                                '??';
   $_more     = (isset($lang) && ($lang!=NULL))? $lang['more_langs'] :
                                                'More >>'; 
                                                
   $_domains     = (isset($lang) && ($lang!=NULL))? $lang['domains'] :
                                                'Domains'; 
   $_myaccount   = (isset($lang) && ($lang!=NULL))? $lang['my_account'] :
                                                'My Account';                                               
   $_calculator  = (isset($lang) && ($lang!=NULL))? $lang['calculator'] :
                                                'Calculator';
   $_news        = (isset($lang) && ($lang!=NULL))? $lang['news'] :
                                                'News'; 
   $_help        = (isset($lang) && ($lang!=NULL))? $lang['help'] :
                                                'HELP';
   $_search      = (isset($lang) && ($lang!=NULL))? (string)$lang['search'] :
                                                'Search'; 
   
   $_facebook    = (isset($lang) && ($lang!=NULL))? $lang['facebook'] :
                                          'Share on Facebook (f)';
   $_instagram   = (isset($lang) && ($lang!=NULL))? $lang['instagram'] :
                                          'Share on Instagram (I)';
   $_twitter     = (isset($lang) && ($lang!=NULL))? $lang['twitter'] :
                                          'Share on Twitter (T)';
   $_googlep     = (isset($lang) && ($lang!=NULL))? $lang['googlep'] :
                                          'Share on Googleplus (G+)'; 
  // selected language
  $_language     = (isset($language) && ($language!=NULL))? $language :
                                          'en';                                         
                                                   
                                                                                       
?>

  <!DOCTYPE html>
  <html lang="<?php echo $_language; ?>" >
 
 <head>
   
 <title><?php echo $title; ?></title>
   
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
 <meta name="description" 
           content="Calculteller can defined as a calculator that speaks.
                    Calculteller(Ct) calculates the Past, the Present and 
                    predicts the Future in a few clicks. With calculteller,
                    you do not need a pen, paper or calculator.
                     Calculteller is all of the above and more." />

 <meta name="keywords" content="calculteller, calculate, calculator, 
                                domains, balance, bet, proportion, time, 
                                business, school, measurement,
                                math, age, how to calculate" /> 
 
 <meta charset="UTF-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />

 
  <link rel="icon" type="image/png" href="<?php echo Link::Build('images/favicon.png'); ?>" />
  
  
  
<script src=<?php echo Link::Build('scripts/css3-mediaqueries.min.js'); ?>></script>


  
<link rel="stylesheet" media="screen and (max-width: 650px)" href=<?php echo Link::Build('styles/calculteller_mobile.css'); ?> />
<link rel="stylesheet" media="screen and (min-width: 650px)" href=<?php echo Link::Build('styles/calculteller.css'); ?> />


<script type="text/javascript" src=<?php echo 
                 Link::Build('scripts/sidemenu.js'); ?>></script>
<script type="text/javascript" src=<?php echo 
                 Link::Build('scripts/language.js'); ?>></script>                 
  
  </head>
  
  
<body onload="loaderFunction()">

<!-- CSS Loader div -->
<div id="loader"></div>

   
<div id="doc" class="calcult">

<!-- CSS loader javascript CODE -->
<script type="text/javascript">
var myVar;

function loaderFunction() {
  myVar = setTimeout(showPage, 50);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("doc").style.display = "block";
  document.getElementById("ads").style.display = "block";
  document.getElementById("ft").style.display = "block";
}
</script>
    
    <div id="header">
    
       <span>
          <a href=<?php echo  Link::Build('index.php'); ?> >
           <img id="logo" src=<?php echo Link::Build('images/logo.png'); ?>  alt="Logo calculteller" title="Home page"/>
          </a>
       </span>
      
       <span id="app-name" title="Calculteller">
         <?php echo $_appName; ?> </span>
    
    <?php  
      if($member==true)
      {
    ?> 
       
       <p class="loggings">
         <a title="Logout" href=<?php echo  Link::Build('logout.php'); ?> >
           <?php echo $_logout; ?>
         </a>
        </p>
      <?php
       }
       else
       {
       ?>
        <p class="loggings">
        
         <a title="login" href=<?php echo  Link::Build('login.php?lang='.$_language); ?> >
           <?php echo $_login; ?>
         </a>  &nbsp;
       
         <a title="register" href=<?php echo  Link::Build('register_user.php?lang='.$_language); ?> >
          <?php echo $_signup; ?>
         </a>
       </p> 
      <?php
       }   
      ?>   
  
      
        <span id="language">
              <span style="color: gold;">
                 <?php echo $_langInvite; ?> :</span> 
            
              <a  href="index.php?lang=en"> 
                 <?php echo $_english; ?> : </a>
        
              |<a  href="index.php?lang=fr"> 
                 <?php echo $_french; ?> : </a>
              
              |<a  href="index.php?lang=zh"> 
                 <?php echo $_chinese; ?> : </a>
              
              |<a  href="index.php#lang_p_content">
                 <?php echo $_more; ?> </a>
              
         </span> <br /><br />
         
         
      
       
       <span class="social_media">
         <a href="http://www.facebook.com/calculteller" target="_blank">
           <img id="facebook" src=<?php echo Link::Build('images/facebook.png');?>  alt="facebook" />
         </a>&nbsp;
      
         <a href="http://www.instagram.com/calculteller" target="_blank">
           <img id="instagram" src=<?php echo Link::Build('images/instagram.png');?>  alt="instagram" />
         </a>&nbsp;
    
         <a href="http://www.twitter.com/calculteller" target="_blank">
          <img id="twitter" src=<?php echo Link::Build('images/twitter.png');?>  alt="twitter" />
         </a>
       </span>
       
      
      <span id="float_right_links">  
      
      <form method="get" action="" style="display:none;"> 
        <input type="text" name="search_term" title="Search…" value="Search..."> 
        <input type="submit" name="search" title="Search calculteller"
          value="Search" class="searchbutton" /> 
      </form> 
      
       
         
       <span id="domains_link">
         <a href=<?php echo  Link::Build('index.php'); ?> target="_blank" >
           <?php echo $_domains; ?> 
         </a>
      </span>  
      
       <span id="my_account">
       <a href=<?php echo  Link::Build('myaccount.php'); ?> >
         <?php echo $_myaccount; ?> 
       </a>
       </span>&nbsp;&nbsp;
       
       <span id="calculator">
       <a href=<?php echo  Link::Build('calculator.html'); ?> target="_blank" >
         <?php echo $_calculator; ?> 
       </a>
       </span>&nbsp;&nbsp; 
       
       <span id="newsletter">
       <a href=<?php echo  Link::Build('mlm/index.php'); ?> target="_blank" >
         <?php echo $_news; ?> 
       </a>
       </span>&nbsp;&nbsp;
       
        
       
       <span class="user_name">
       <?php 
       echo '<span>'.$user_name.' '.'</span>';
       
       if(!empty($user_name))
       { 
         echo '<a href="'.Link::Build('myaccount.php').'">';
         echo '<img id="user_image" src="'.Link::Build('images/user_image.png').'" alt="user_image" />';
         echo '</a>';
       }
       ?>
       </span>
       
       <span id="help">
            <a href=<?php echo  Link::Build('forum.php'); ?> >
              <?php echo $_help; ?>
            </a>
        </span>&nbsp;&nbsp; 
      </span> 
      
      <!-- Search form for big screen -->
      <span class="search_domains">
        <form method="get" class="search_form" action=<?php echo  Link::Build('search.php'); ?> > 
           <input name="search_term" id="searchInput" type="text"   
                   style="background-image: url(<?php echo  Link::Build('images/search.png'); ?>); 
                          background-repeat: no-repeat; 
                          background-position: left center; " 
                   
              <?php echo ' placeholder="'.$_search.'"'; ?>
                   title="Search"  value=<?php echo  '"'.$search_term.'"'; ?>>&nbsp; 
                            
                            
            <input name="search_button"  type="hidden" class="search" value="Search" title="Search"> 
        </form>
         
        
              
    </span> 
      
       <span id="side_menu_btn">
               
            <span class="menu_button"  onclick="openNav()">
              <img src="<?php echo  Link::Build('images/ic_menu_white_36dp.png');?>" alt="menu button" /> 
            </span> 
            
      </span> 
      
       <!-- Side navigation menu links --> 
      <div id="main_mySidenav">  
      
        <div  id="mySidenav">
    
          <a  href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
          
          <a  href="<?php echo LINK::Build('index.php');?>"> 
             <?php echo $_home; ?></a>
      
            
          <a  href="<?php echo LINK::Build('index.php#lang_p_content'); ?>">
            <?php echo $_langInvite; ?> </a>
            
            
          <a  href="<?php echo LINK::Build('myaccount.php'); ?>">
            <?php echo $_myaccount; ?></a>
        
          <a  href="<?php echo LINK::Build('calculator.html'); ?>"
                   target="_blank" >
            <?php echo $_calculator; ?> </a>
            
          <a  href="<?php echo LINK::Build('mlm/index.php'); ?>">
            <?php echo $_news; ?> </a>
            
          <a  href="<?php echo FACEBOOK_LINK; ?>" target="_blank">
            <?php echo $_facebook; ?> </a>
            
          <a  href="<?php echo INSTAGRAM_LINK; ?>" target="_blank">
            <?php echo $_instagram; ?>  </a>
            
          <a  href="<?php echo TWITTER_LINK; ?>" target="_blank">
            <?php echo $_twitter; ?>  </a>
            
          <a  href="<?php echo GOOGLEPLUS_LINK; ?>" target="_blank">
            <?php echo $_googlep; ?> </a>
            
          <a  href="<?php echo LINK::Build('forum.php'); ?>">
           <?php echo $_help; ?> </a>
          
         
         
   
         </div>   
      
          
    </div>
  
  </div>
 
 <?php
 
 }
 
 
function fixed_html_sidebar()
{
 ?>
 
    <div id="sidebar">
      <!--side bar: contains SEARCH BOX at the top and CalcuTeller functions.. -->
    
 <?php
 }
 
function fixed_html_content()
{
 ?>  
    </div>
    <div id="ct-main">
            
       
            
<?php
}

function fixed_html_ads()
{
 ?>  
     </div>  
    <div id="ads">
      Advertisement
   
 <?php
 }
 
 function fixed_html_footer($lang=null)
 {
 
   // Prepare all temporary variables holding lang disply strings
   $_termsConditions = (isset($lang) && ($lang!=NULL))?
                        $lang['terms_conditions'] : 'Terms and Conditions';
   $_privacyPolicy   = (isset($lang) && ($lang!=NULL))?
                        $lang['privacy_policy']: 'Privacy Policy';
   $_aboutus         = (isset($lang) && ($lang!=NULL))?
                         $lang['aboutus'] : 'About Us';
   $_sitemap         = (isset($lang) && ($lang!=NULL))?
                         $lang['sitemap'] : 'Sitemap'; 
   $_news            = (isset($lang) && ($lang!=NULL))?
                         $lang['news'] : 'News';
   $_tel             = (isset($lang) && ($lang!=NULL))?
                         $lang['tel'] : '+1 123 4550';
   $_helpFt          = (isset($lang) && ($lang!=NULL))?
                         $lang['help_ft']: 'Help';
   $_cookies         = (isset($lang) && ($lang!=NULL))?
                         $lang['cookies']: 'Cookies';
  
   
  ?>  
     </div>   
    <div id="ft">
   
    <p class="terms_privacy">
     | <a href=<?php echo  Link::Build('terms-conditions.php'); ?> target="_blank">
         <?php echo $_termsConditions; ?> </a> 
       
     | <a href=<?php echo  Link::Build('privacy-policy.php'); ?> target="_blank">
         <?php echo $_privacyPolicy; ?></a> 
        
     | <a href=<?php echo  Link::Build('aboutus.php'); ?> target="_blank">
         <?php echo $_aboutus; ?></a>  
        
     | <a href=<?php echo  Link::Build('sitemap.xml'); ?> target="_blank">
         <?php echo $_sitemap; ?></a> <br />
        
     | <a href=<?php echo  Link::Build('mlm/index.php'); ?> target="_blank">
         <?php echo $_news; ?></a>| 
        
     | <a href=<?php echo  Link::Build('forum.php'); ?> target="_blank">
         <?php echo $_helpFt; ?> </a> 
         
     | <a href=<?php echo  Link::Build('cookies.php'); ?> target="_blank">
         <?php echo $_cookies; ?> </a>|
    
    </p>
    
     <p> Copyright © 2017, wwww.calculteller.com</p>
     
     </div>
     
  </div>
  
  
 </body>
</html>
<?php
}   

function display_domains_list($lang=NULL)
{
 ?>
 
 <?php
 
   $domainId = '';
   $selectedDomain = 0;
   $selected = '';
 
 // number of records to be displayed per page
 $records_per_page = DOMAINS_PER_PAGE;
 
 // look for starting marker from hidden form input or query string
 // if not available, assume 0
 (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
 
 // look for domain_id to use in domain list foward and back links
 // if not available set domaind_id to ''
 
 (!isset($_REQUEST['domain_id'])) ? $domainId='' : $domainId = $_REQUEST['domain_id'];
 
 if(isset($_REQUEST['domain']))
    $domainId = $_REQUEST['domain'];
 // open connection to MySQL server and execute queries
 // Get number of records

  $sql = "SELECT COUNT(*) FROM domain "; 
 
   $rows = getRow($sql, $params=NULL);
  
   // get total number of records
   $total_records = $rows['COUNT(*)'];
  

   
 
 // if records exist
  if (($total_records > 0) && ($start < $total_records))
  {
    // create and execute query to get batch of records
    $query = "SELECT * FROM domain 
              LIMIT $start, $records_per_page";   
    
    $result = getAll($query, $params=NULL);
     
     // Array function sizeof() is used to find the number of results return
     
    echo '<div class="box">';
    echo '<p class="box-title">Choose a Domain<br />'.'<small>'. sizeof($result) 
          .' out of '. $total_records. ' domains</small></p>';
    echo  '<ul>';
    
    
     /*  Get selected domain from query string or from form */
    if (isset($_REQUEST['domain_id']))
      $selectedDomain = (int)$_REQUEST['domain_id'];
    elseif(isset($_REQUEST['domain']))
      $selectedDomain = (int)$_REQUEST['domain'];

   
   
    for($i=0; $i < sizeof($result); $i++)
    {
     echo   '<li>';
     
      /* If DomainId  exists in the query string, we're visiting a
       domain */
      if ($selectedDomain == $result[$i]['domain_id'])
         $selected = 'class="selected"';
      else 
        $selected = '';
        
       $domainName = (isset($lang) && ($lang!=NULL))? $lang['domains_arr'][$start + $i] :
                                               $result[$i]['name'];
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomain($result[$i]['name'], $result[$i]['domain_id']). ">";
     echo $domainName;
     echo   '</a>';
     echo '</li>';
        
    }
    echo '</ul>';  
  } 
  
      
     // set up the previous page link
    // this should appear on all pages except the first page
    // the start point for the previous page will be 
    // the start point for this page 
    // less the number of records per page 
    // htmlentities() function is used to replace <, >, special character
    // to prevent them from being interpreted as HTML by the browers
    
    //use htmlentities() to create <<Backward and Foward>> buttons
    //$specialBackward= htmlentities('<<');
    //$specialFoward = htmlentities('>>');
    
    echo '<p class="nxt_btn">';
    
  if ($start >= $records_per_page)   
  {    
    echo "<a href=" . $_SERVER['PHP_SELF'] . 
    "?start=" . ($start-$records_per_page) ."&domain_id=".$domainId. 
       ' '. 'class="nxt_btn_left_sidebar"'.'>'. 
     '<< Back </a>';
  }
    
    // set up the "next page" link
    // this should appear on all pages except the last page
    // the start point for the next page 
    // will be the end point for this page
    if ($start+$records_per_page < $total_records && $start >= 0) 
    {
        echo '<a href=' . $_SERVER['PHP_SELF'] . 
             '?start=' . ($start+$records_per_page) .'&domain_id=' .$domainId.
             ' '. 'class="nxt_btn_left_sidebar"'.'>'.
         'Next >>' . '</a>';
    }
   echo '</p></div>';     
 
 ?>

<?php
}


function display_domain_image_links()
{
?>
   
<?php 

// get domains' info from database
  $domainId = '';
   $selectedDomain = 0;
   $selected = '';
   
  // number of records to be displayed per page
 $records_per_page = DOMAINS_PER_PAGE;
 
 // look for starting marker
 // if not available, assume 0
 (!isset($_GET['start'])) ? $start = 0 : $start = $_GET['start'];
   
 
 // look for domain_id to use in domain list foward and back links
 // if not available set domaind_id to empty string 
 
 (!isset($_GET['domain_id'])) ? $domainId='' : $domainId = $_GET['domain_id'];
 
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    
 // open connection to MySQL server and execute queries
 // Get number of records

  $sql = "SELECT COUNT(*) FROM domain "; 
  
 
  $rows = getRow($sql, $params=NULL);
  
   // get total number of records
   $total_records = $rows['COUNT(*)'];
 
 
  // if records exist
  if (($total_records > 0) && ($start < $total_records))
  {
    // create and execute query to get batch of records
    $query = "SELECT * FROM domain 
              LIMIT $start, $records_per_page";  
    
    $result = getAll($query, $params=NULL);
  }

     
   echo '<div class="box">';
   echo '<center>';
   echo '<ul class="domain_image_links">' ;
   
 
    // iterate over domain images 
    // display each image as a link to that domain
 
   for($i=0; $i < sizeof($result); $i++)
   {
       $domain_image = '';
      $domain_image = strtolower(strip_tags($result[$i]['image']));

      
   
     echo   '<li>';
     
     /* If DomainId  exists in the query string, we're visiting a
       domain */
    if (isset ($_GET['domain_id']))
      $selectedDomain = (int)$_GET['domain_id'];

    if ($selectedDomain == $result[$i]['domain_id'])
     $selected = 'class="selected"';
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomain($result[$i]['name'], $result[$i]['domain_id']). ">";
     
     // display image link for each domain
      
     echo '<img src="'. Link::Build('images/'.$domain_image). '" alt="domain-image" width="200px" height="140px" />';
     
     echo '<p>'.$result[$i]['name'].'</p>';
     echo   '</a>';
     echo '</li>';
  }
  echo '</ul>';
  
  
   // set up the previous page link
    // this should appear on all pages except the first page
    // the start point for the previous page will be 
    // the start point for this page 
    // less the number of records per page 
    // htmlentities() function is used to replace <, >, special character
    // to prevent them from being interpreted as HTML by the browers
    
    //use htmlentities() to create <<Backward and Foward>> buttons
    $specialBackward= htmlentities('<<');
    $specialFoward = htmlentities('>>');
    
  if ($start >= $records_per_page)   
  {    
    echo "<a href=" . $_SERVER['PHP_SELF'] . 
    "?start=" . ($start-$records_per_page) ."&domain_id=".$domainId. ">". $specialBackward. "Back </a>";
  }
    
    // set up the "next page" link
    // this should appear on all pages except the last page
    // the start point for the next page 
    // will be the end point for this page
    if ($start+$records_per_page < $total_records && $start >= 0) 
    {
        echo "<a href=" . $_SERVER['PHP_SELF'] . 
     "?start=" . ($start+$records_per_page) ."&domain_id=".$domainId. ">Next".$specialFoward."</a>";
    }
  
  
  echo '</center>';
  echo '</div>';

?> 
<?php
}
       
      

function display_ads($lang=null)
{
?>
   
<?php 

    // prepare language strings for ads bottom section
   $_langInvite  = (isset($lang) && ($lang!=NULL))? $lang['language_invite']:
                                                'Language';
   $_english  = (isset($lang) && ($lang!=NULL))? $lang['english'] :
                                                'English';
   $_french  = (isset($lang) && ($lang!=NULL))? $lang['french'] :
                                                'Français';
   $_spanish  = (isset($lang) && ($lang!=NULL))? $lang['spanish'] :
                                                'Espagnol';
   $_chinese  = (isset($lang) && ($lang!=NULL))? $lang['chinese'] :
                                                '??';
   $_more     = (isset($lang) && ($lang!=NULL))? $lang['more_langs'] :
                                                'More >>';
  
  /* 
   echo '<div class="advertisement">';
   echo '<center>';
   echo '<p style="font-size:90%;  text-align: center; padding: 10px; 
             margin-right: 30px;">';
   
  //Generate a link for each result     
  echo "<a href=".'"http://top10greatcars.blogspot.com"'.  ' target="_blank"'.">";
     
  // display advertisement image link for ad banner
      
     echo '<img src="'. Link::Build('images/ads_banner1.png'). '" alt="top10greatcars.blogspot.com" 
            title="top10greatcars.blogspot.com" style="max-width:100%" />';
     
     echo '</a>';
  
  echo '</p>';
  
  */
  
     
     echo '<h2>&nbsp;How CalculTELLER works?</h2>
           <p style="font-size:90%;  text-align: justify; padding: 10px;
               margin-right: 30px;">
              Calculteller is simply <em>a calculator which speaks.</em> 
             It is pen, paper, calculator and more. With calculteller, you
             do not need a pen, paper or calculator to do simple daily
             calculations.<br /><br />
             <em><b>"Calculteller calculates the Past, the Present and 
              predicts the Future"</b></em>
             in a few clicks. <b>Start today</b> 
           </p>';
    echo '<p id="lang_p_content" style="font-size:small; padding: 10px 0; text-align: left;
               border-top: 1px solid #a9a9a9;">
          <em><b>'. $_langInvite .':</b></em>
           <span id="language_footer"> 
          
              <a  href="index.php?lang=en">'. $_english .'</a>
        
              <a  href="index.php?lang=fr">'. $_french .'</a>
            
              <a  href="index.php?lang=es">'. $_spanish .'</a>
              
              <a  href="index.php?lang=zh">'. $_chinese .'</a>
         </span> </p>';
  
  echo '</center>';
  echo '</div>';

?> 

<?php
}


/*
// Build correct indexes to be used in for loop below
   if($total_records < $records_per_page)
          $records_per_page = $total_records;


/* LINK functions and constants 

<head> 
<title>Hyperlink Example</title> 
<base href="http://www.tutorialspoint.com/"> 
</head> 

<body>
<p>Click any of the following links</p> 
<a href="/html/index.htm" target="_blank">Opens in New</a> | 
<a href="/html/index.htm" target="_self">Opens in Self</a> | 
<a href="/html/index.htm" target="_parent">Opens in Parent</a> | 
<a href="/html/index.htm" target="_top">Opens in Body</a> 
</body>
*/
/*
//FIXED output fns names
fixed_html_header($title, $heading)
fixed_html_sidebar()
fixed_html_content()
fixed_html_ads()
fixed_html_footer()

*/