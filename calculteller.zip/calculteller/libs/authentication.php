<?php

function authenticate_user($user_name)
{
	// Authenticate user 
	if (!isset($_SESSION['username']) || $_SESSION['username']=='')
 	{
 
		fixed_html_header('CalculTELLER: Balance domain calculates 
                    	your change in less than a second',
                      	'Balance (Change) Functions', $user_name);
		fixed_html_sidebar();
		display_domains_list();
		fixed_html_content();

		// display login advice to user
 		echo  '<center><h2>Please Login to gain FULL ACCESS to all 
 		       domains</h2></center>';
 		echo '<p class="login_advice">';
 		echo  'After you log in, you can  SAVE your answers and information
        	   and retrieve them anywhere in the world and at any time 
        	   of the day. Thank You!';
 		echo '</p>';
 		echo '<center>';
 		echo '<span style="float:center;">'.'<b>'.'<a href="'.
        	  Link::Build('login.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
		echo '</center>';
		
		//display_domain_image_links();
		fixed_html_ads();
		fixed_html_footer();
 
		// Output content from the buffer and clean buffer
		// before exiting script
  		flush();
  		ob_flush();
  		ob_end_clean();
 
 
 		exit();
 	}	
	
}

?>


