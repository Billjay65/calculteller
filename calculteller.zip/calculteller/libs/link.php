<?php

class Link
{
  public static function Build($link, $type = 'http')
  {
    $base = (($type == 'http' || USE_SSL == 'no') ? 'http://' : 'https://') .
            getenv('SERVER_NAME');

    // If HTTP_SERVER_PORT is defined and different than default
    if (defined('HTTP_SERVER_PORT') && HTTP_SERVER_PORT != '80' &&
        strpos($base, 'https') === false)
    {
      // Append server port
      $base .= ':' . HTTP_SERVER_PORT;
    }

    $link = $base . VIRTUAL_LOCATION . $link;

    // Escape html
    return htmlspecialchars($link, ENT_QUOTES);
  }

  public static function ToDepartment($departmentId, $page = 1)
  {
    $link = self::CleanUrlText(Catalog::GetDepartmentName($departmentId)) .
            '-d' . $departmentId . '/';

    if ($page > 1)
      $link .= 'page-' . $page . '/';

    return self::Build($link);
  }
  
  // Create link to domain page
 public static function ToDomain($domainName, $domainId, $start=0)
 {
 
   // look for starting marker
  // if not available, assume 0
  // $_GET['start'] is a GLOBAL variable to all functions in app
  (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
   
  $domainId = (int)$domainId;
  $link = 'domains/'.$domainName.'.php?domain_id='. $domainId.
                                       '&start='.$start.'#top_domain_table';
  return self::Build(strtolower($link));
  }

 public static function ToDomainTab($tab_id, $domain_id, $start=0)
 {
   // look for starting marker
   // if not available, assume 0
   // $_GET['start'] is a GLOBAL variable to all functions in app
   (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
  
   $domainId = (int)$domain_id;
   $tabId = (int)$tab_id;
   $link = $_SERVER['PHP_SELF'] . '?tab_id='. $tabId.'&domain_id='.$domainId.
                                     '&start='.$start.'#top_domain_table';
   
   return strtolower($link);
 }

  // Prepares a string to be included in an URL
  public static function CleanUrlText($string)
  {
    // Remove all characters that aren't a-z, 0-9, dash, underscore or space
    $not_acceptable_characters_regex = '#[^-a-zA-Z0-9_ ]#';
    $string = preg_replace($not_acceptable_characters_regex, '', $string);

    // Remove all leading and trailing spaces
    $string = trim($string);

    // Change all dashes, underscores and spaces to dashes
    $string = preg_replace('#[-_ ]+#', '-', $string);

    // Return the modified string
    return strtolower($string);
  }
  // Create an Add to Cart link
  public static function ToAddProduct($productId)
  {
    return self::Build('index.php?AddProduct=' . $productId);
  }
}

 

?>