<?php

function remove_spaces($input)
{
   // use htmlentities to avoid code scripts from running
   $cleanedInput = htmlentities(str_replace(' ', '', trim($input))); 
   
   //$cleanedInputFloat = (float)$cleanedInput; 
   
   //return $cleanedInputFloat ;
   return $cleanedInput;
}

function validate_items_number($input)
{
   // set maximum size of number of items and
   // make sure value is an integer if not
   // display error message
   if (is_int($input) && ($input > 0 && $input <= 10000))
   {
     return true;
   }
   else
   {
     return false;
   } 
}


 ?>


