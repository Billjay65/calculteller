<?php
 // we include this file in all our files
 // this way, every file will contain all our functions and exceptions

 require_once FUNCTIONS_DIR.'database_fns.php';
 require_once FUNCTIONS_DIR.'output_fns.php';
 require_once FUNCTIONS_DIR.'link.php';
 require_once FUNCTIONS_DIR.'password_hasher.php';
 require_once FUNCTIONS_DIR.'data_valid_fns.php';
 require_once FUNCTIONS_DIR.'authentication.php';

 
?>