<?php



function remove_spaces()
{

  $args = func_get_args(); 
  $count = func_num_args();
 // test that each varible has a value
 foreach ($form_vars as $key => $value)
 {
   if ($value == ''))
       return false;
 } 

  return true;
}

function valid_email($address)
{ 
  // check an email address is possibly valid
  if(ereg('^[a-zA-Z0-9 \._\-]+@([a-zA-Z0-9][a-zA-Z0-9\-]*\.)+
            [a-zA-Z]+$', $address))
    return true;
  else
   return false;
}




 // validate username atmost 14 characters 
      if (!empty($_POST['username']) && ereg('^([a-zA-Z]){2,8}$', $_POST['username'])) { 
        $_username = htmlentities(trim($_POST['username'])); 
       
         // Check if username is unique
         // create and execute SELECT query 
        $sql = "SELECT COUNT(*) FROM user
                WHERE username = '$_username'"; 

        $row1 = getOne($sql, $params=NULL);
 
   
         if($row1[0]== 1)
         {
            $valid['username'] = htmlentities(trim($_POST['username']));
            $_username = $valid['username'];
         }
         else
         {
           $inputErrors[] = 'Invailid Username';
           $errorFlag = 1; 
         }
                
      }
      
    // function definition 
// calculate average of supplied values 
function calcAverage() { 
  $args = func_get_args(); 
  $count = func_num_args(); 
  $sum = array_sum($args); 
  $avg = $sum / $count; 
  return $avg; 
} 
 
// function invocation 
// with 3 arguments 
// output: 6 
echo calcAverage(3,6,9); 
 
// function invocation 
// with 8 arguments 
// output: 150 
echo calcAverage(100,200,100,300,50,150,250,50);  
 ?>


