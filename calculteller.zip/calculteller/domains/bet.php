<?php

// start session
 session_start();
 
 // Start output buffer
 ob_start(); 
 
 
 // Obtaining root directory  from domains folder
 define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT2.'/include/config.php';
 
 
 // include error handling class php file
 require_once SITE_ROOT2.'/error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
   

 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 // authenticate user

 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
/* 
 // Authenticate user 
 if(!isset($_SESSION['username']) || $_SESSION['username']=='')
 {
 
  fixed_html_header('CalculTELLER: Balance domain calculates 
                    your change in less than a second',
                      'Balance (Change) Functions', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please Login to gain FULL ACCESS to all domains</h2></center>';
 echo '<p class="login_advice">';
 echo  'After you log in, you can  SAVE your answers and information
              and retrieve them anywhere in the world and at any time of the day.
              Thank You!';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('login.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
  // Output content from the buffer and clean buffer before exiting script
  flush();
  ob_flush();
  ob_end_clean();

  exit();
 }
 
 */
 
 // Preprocessing: get query, form data string and get database data
 // Define short variables
 
  
  
 
 // create short variable names  
   $tabId   = (!isset($_REQUEST['tab_id']))? 3 : $_REQUEST['tab_id'];
  $domainId = (!isset($_GET['domain_id']))? '' : $_GET['domain_id'];   

$radioUnits = (!isset($_POST['radio_units']))? 'Abbrevation': $_POST['radio_units'];
//$radioUnits = (!isset($_POST['radio_units']))? 'Full': $_POST['radio_units'];
$unitSelected = (!isset($_POST['unitselected']))? 'FRS': $_POST['unitselected'];
   
 
 
 // get domain Id when form is submitted
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    
 // if domain ID is Not set or equals empty string, display error message
 if($domainId=='')
 {
   echo '<h2> Error: Domain Id Not Set</h2>
         <p> Please the domain Id is not set. 
          <a href="../index.php">Choose a domain here.</a>
         </p>';
   
   exit();
 }
 
 
  // look for starting marker
  // if not available, assume 0
  // $_GET['start'] is a GLOBAL variable to all functions in app
  (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
  


 /*** displays different bet domain options and forms based on the tab selected***/  
  switch ( $tabId )
  {
    case 3 :
    { 
    // display form for bet tab 1(tab_id is 3) with all its calculations
 if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
  
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
 
 
 
 
 
 // Variables for bet domain number rows of input data 
 // (Number of games corresponds to number of rows)
 
  $_gameCno = array('');
  
  $gcNo = (!isset($_POST['gcno']))? DOMAIN_ROWS_NO: $_POST['gcno'];
 
  $amountP = (!isset($_POST['amountp']))? 0: $_POST['amountp'];
  
  
  $gcName = (string)(!isset($_POST['gcname']))? array('') : $_POST['gcname'];
  
  $gameCno = (!isset($_POST['gamecno']))? array(DOMAIN_ROWS_NO) : $_POST['gamecno']; 
  
  $code = (!isset($_POST['code']))? array('') : $_POST['code']; 
  
  $codeTotal = (!isset($_POST['codetotal']))? 0: $_POST['codetotal'];
  
  $gcTotal = (!isset($_POST['gcTotal']))? 0: $_POST['gcTotal'];
  
  $amountW = (!isset($_POST['amountw']))? array(''): $_POST['amountw'];
  
  
  // CALL REMOVE SPACES FUNCTION TO ELIMINATE SPACES FROM INPUT NUMERIC
   if(isset($code) || isset($gcNo) || isset($code) || isset($amountP))
   {
     
     // remove spaces from gcNo variable
      $gcNo = remove_spaces($gcNo);
      $gcNo = (int)$gcNo;
      
     // remove spaces from amountP variable
      $amountP = remove_spaces($amountP);
        
     for($i=0; $i<count($code); $i++)
     {
        // remove spaces from code array
        $code[$i] = remove_spaces($code[$i]);
  
     }
   } 
    
 
 
  
  
  // Temporary inner variables used for total calculations
  $_codeTotal = 0.00;
  $_gcTotal = '';
  $_totalAmountW = 0.00;
  
  if(isset($_POST['addgame']))
  {
     $gcNo++;
  
  }
  
  
 
 // Display of row numbers-numbering of games or conditions set initially
 // Do all calculations based on the number of games and values submitted
 
 for($i=0; $i < $gcNo; $i++)
 {
   if(!isset($code[$i]) ||($code[$i]=='') )
   {
     $code[$i] = '';
    }
    $gameCno[$i] = $i + 1;
    
    
    
   $amountW[$i] = (double)$code[$i] * (double)$amountP;
   
   // calculate SUM of code column
   $_codeTotal = $_codeTotal + (double)$code[$i];
   
   $_totalAmountW += $amountW[$i];
   
   
   // Create text to display in first column G/C Name
    if(!isset($gcName[$i]) ||($gcName[$i]==''))
   {
      $gcName[$i] = '';
      
   }
   
   
 } 
 
 
 
 // Code total
 $codeTotal = $_codeTotal;
 $_codeTotal = ''; 
 
 // Total Games/Conditions  calculation
 $_gcTotal = $gcNo;
 $gcTotal = $_gcTotal;
 $_gcTotal = '';
 
 // total Amount won   calculation
 $totalAmountW = $_totalAmountW;
 $_totalAmountW = '';
 // Store answer and description in SESSION variables
 
 $_SESSION['answer']  = 'BET_WIN: '. $totalAmountW.' ' . $unitSelected;
 $_SESSION['description']  = 'If AMOUNT PLACED equals '.$amountP.' ' .$unitSelected.
                             ' and number of GAMES/CONDITIONS equals '.  $gcTotal.
                              ' therefore BET_WIN equals '. $totalAmountW.' '. 
                               $unitSelected.'.';
 
 
 // Flag variable to show if domain table rows have been created or not
 // $domainTableRowsCreated = false; 
 
/* Calculating totals 
 for($i=0; $i < $gcNo; $i++)
   {
     $gcTotal += 1;
     
     $_codeTotal = +$code[$i];
     $amountW[$i] = $code[$i] * $amountP[$i];  
     $_totalAmountW += $amountW[$i];
    
   }
  $codeTotal = $_codeTotal;
  $_codeTotal = 0;
  $totalAmountW = $_totalAmountW;
  $_totalAmountW = 0;
 */ 
   
   
   

 
    
 // display html conponents of web page
fixed_html_header('CalculTELLER: Bet domain, Calculates bet wins and losses',
                      'Bet Functions', $user_name, $member);  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();




if(!isset($_POST['me']))
{
?>


<div id="domain_content">
 <div id="answer_div" class="ans_display">
  <b>
  <?php echo 'ANS-'. $_SESSION['answer']; ?> 
  </b>
  </div> 

<table width="100%" border="0" class="domain_table1">
<form action="<?php echo $_SERVER['PHP_SELF'].'#add_game'; ?>" method="post">

 <input type="hidden" name="domain" value="<?php echo $domainId; ?>"> 
 
 <input type="hidden" name="start" value="<?php echo $start; ?>">

  <tr> 
    <td id="top_domain_table" colspan="4" bgcolor="#00a0a0"> 
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td colspan="4" class="tabs_dm_img"> 
     
     <span>
       <img src=<?php echo Link::Build($image_string); ?> alt="domain-image" />
     </span> 
    
     <span>
  
       <ul >
    
    <?php
     // display domain tabs
     
     $selectedtab = 0;
     $selected = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($tabId))
       $selectedtab = (int)$tabId;

     if($selectedtab === (int)$domain_tabs[$i]['tab_id']){
        $selected = 'class="selected"';
      }
      else
      {
        $selected = '';
      }
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '|</a>'.'&nbsp';
     echo '</li>';
     
        
    }
    ?>
     </ul>
     
     </span>
     
    </td>  
  </tr> 



  <tr> 
    <td colspan="4" bgcolor="#00a0a0">
    
    
    
    <p class="inputfields"> 
    
    SELECT TYPE OF UNITS:
    <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($radioUnits==''||$radioUnits=='Abbrevation') echo 'checked'; 
          else echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($radioUnits=='Full') echo 'checked'; 
          else echo '';  ?> > Full
     
      <br />
      <select name="unitselected"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
 
     <input type="submit" name="units" value="SET AS CURRENT" class="unit"> <br /><br />
      
  <span class="donate">
  <a href="<?php echo Link::Build('donate.php'); ?>">
  DONATE
  </a>
  </span>
 
  </p>
  
  
    </td> 
  </tr> 
  
<tr>
 <td colspan="4"><label>NUMBER of GAMES/CONDITIONS</label>
  
  <br />
  
  <input type="text" name="gcno"  class="introalone"
                                 value="<?php echo $gcNo; ?>"> 
  
  <br />
  
  <label>AMOUNT_P/STAKE</label> 
  
  <br />
  
   <input type="text" name="amountp"   class="introalone" 
                                 value="<?php echo $amountP; ?>"> 
   <span class="unit_ans_display"> 
         <?php echo $unitSelected; ?>
    </span>
   
  <input type="submit" name="gamesnumber" value="GO!" class="unit"
       id="games_number"> <br />
  
  </td>
</tr>  
  <tr>
      <td >G/C Name</td>
      <td >G/C No</td>
      <td >CODE/ODD</td>
      <td >AMOUNT_WON</td>
   </tr>   
 
 
 
 <!-- Display the number of rows of data specified for domain-->
<?php
 
 // display the number of rows of data specified by user
  for($j=0; $j < $gcNo ; $j++) 
  {
    if($j%2!==0)
    {
     echo '<tr>';
    }
    elseif($j%2==0)
    {
      echo '<tr class="stripy_row">';
    }
   
    echo  '<td rowspan='.'"1"'.'><input type="text"'.' name="gcname[]" '.
            'value="'.$gcName[$j].'" placeholder="GC Name"></td>';
    echo  '<td style="width:6px">'. $gameCno[$j] .'</td>';
    echo  '<td>'.'<input type="text"'.'name="code[]"'.'value="'.$code[$j] .'">'.'</td>';
    echo  '<td>'.'<input type="text"'.'name="amountw[]"'.'value="'.$amountW[$j].'">'.'</td>';
  
    echo  '</tr>';
    
  }
 

 /*
 // Array variables
  $code =  $_POST['code'];
  $amountW =  $_POST['amountw']; 
 */ 
  // Calculate total values of input elements and empty the temporary variables
  //That is set $_codeTotal = 0; etc...
  


    
 ?> 
 
   <tr>
      <td >TOTAL</td>
      <td ><input type="text" name="gctotal" value="<?php echo $gcTotal  ?>"></td>
      <td ><input type="text" name="codetotal" value="<?php echo $codeTotal  ?>"></td>
      
      <td ><input type="text" name="totalamountw" class="unit_ans_display"
                                          value="<?php echo $totalAmountW  ?>">
         <br />
         <span class="unit_ans_display"> 
            <?php echo $unitSelected; ?>
         </span>
      </td>
   </tr>   
 <tr>
 <td colspan="4">
 <input type="submit" name="gamesnumber" value="AMOUNT_WON"  class="domain_ans">
                             
 
  <span class="ans_save" title="Saves your answers into your account">
  <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>">
  SAVE
  </a>
  </span>
  <input type="submit" name="addgame" value="ADD G/C"  class="addgame"
     id="add_game"> <br />
  <input type="reset" value="Clear" id="clear_btn"  class="clear_input"><br /><br />
   
 </td>
 </tr> 
  
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();
 
      break;
    }
    
    case 4 :
    {
      echo 'Welcome to Bet domain, tab 2 - FAIR_PLAY ';
      echo '<a href="bet.php?tab_id=3&domain_id=2">
                      Go Back to Previous Domain</a>';
      // display form for balance tab 2   
          break;
    }
  
  /***END of Switch Case***/
  } 
 




 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>