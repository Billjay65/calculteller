<?php

 // start session
  session_start();
  
 // Start output buffer
 ob_start();

 // Obtaining root directory  from domains folder
 define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT2.'/include/config.php';
 
 // include error handling class php file
 require_once SITE_ROOT2.'/error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
   

 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
  // check if user is logged in and display store his name and hello message
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
  // Variables to hold answers and description to be displayed
  $_SESSION['answer']  = '';
  $_SESSION['description'] = '';
 
 
 /*
 // Authenticate user
 if(!isset($_SESSION['username']) || $_SESSION['username']=='')
 {
 
  fixed_html_header('CalculTELLER: Bank domain Calculates interest, loans and 
                     dividents.',
                      'Bank Functions', $user_name, $member);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please Login to gain FULL ACCESS to all domains</h2></center>';
 echo '<p class="login_advice">';
 echo  'After you log in, you can  SAVE your answers and information
              and retrieve them anywhere in the world and at any time of the day.
              Thank You!';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('login.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
  // Output content from the buffer and clean buffer before exiting script
  flush();
  ob_flush();
  ob_end_clean();
 
 
 exit();
 }
 
 */
 

 
 
 // create short variable names  
   $tabId   = (!isset($_GET['tab_id']))? 10 : $_GET['tab_id'];
  $domainId = (!isset($_GET['domain_id']))? '' : $_GET['domain_id'];   
$radioUnits = (!isset($_POST['radio_units']))? 'Abbrevation': $_POST['radio_units'];
$unitSelected = (!isset($_POST['unitselected']))? 'FRS': $_POST['unitselected'];


// get domain Id when form is submitted
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    
 // if domain ID is Not set or equals empty string, display error message
 if($domainId=='')
 {
   echo '<h2> Error: Domain Id Not Set</h2>
         <p> Please the domain Id is not set. 
          <a href="../index.php">Choose a domain here.</a>
         </p>';
   
   exit();
 }
 
  // look for starting marker
  // if not available, assume 0
  // $_GET['start'] is a GLOBAL variable to all functions in app
  (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];



 /*** displays different domain options and forms based on the tab selected***/  
  switch ( $tabId )
  {
    case 10 :
    { 

 if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
  
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
   

 // Business domain short variables
 $amount =  (!isset($_POST['amount']))? '': $_POST['amount'];

 $interest =  (!isset($_POST['interest']))? '': $_POST['interest'];

 $loanYears =  (!isset($_POST['loanyears']))? '': $_POST['loanyears'];

 $totalLoan = (!isset($_POST['totalloan']))? '': $_POST['totalloan'];
 
 // Temporary inner variables used for total calculations
  $_totalLoan = '';
   
 // define array to hold the number of years of investment
 // range(1,80) creates and arry with values from 1 to 80
 $arr = range(1, 100);   

  
 // CALL REMOVE SPACES FUNCTION TO ELIMINATE SPACES FROM INPUT NUMERIC
   if(($amount!=='') || ($interest!==''))
   {
     
     // remove spaces from $amount variable
      $amount = remove_spaces($amount);
      
     // remove spaces from $interest variable
      $interest = remove_spaces($interest);
        
   } 

 
// Test if ANSWER submit button has been clicked and execute code  
if(isset($_POST['answer']))
{
?>

<?php
 
 // Temporary inner variables used for total calculations
  $_totalLoan = '';
 
 
 
 // Calculate the total loan, store value in $profit variable and empty $_profit
 $_totalLoan = (double)$amount + (((double)$amount * (double)$interest * $loanYears)/100);
 $totalLoan = $_totalLoan;
 $_totalLoan = '';
 
 // Store answer and description in SESSION variables
 
  $_SESSION['answer']  = 'LOAN: '. $totalLoan.' ' . $unitSelected;
 $_SESSION['description']  = 'If AMOUNT equals '. $amount.' ' .$unitSelected.
                             ' and INTEREST RATE equals '.  $interest.' '.
                             '% PER YEAR/MONTH and LOAN DURATION is '.$loanYears.
                             ' YEAR(S)/MONTH(S)'.
                              ' THEREFORE TOTAL LOAN EQUALS  '. $totalLoan. 
                               $unitSelected.'.';
 
 ?>
 
<?php
}

    
 // display html conponents of web page
 fixed_html_header('CalculTELLER: Bank domain Calculates interest, loans and 
                     dividents.',
                      'Bank Functions', $user_name, $member);  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();




if(!isset($_POST['me']))
{
?>
  <div id="domain_content">
  
   <div id="answer_div" class="ans_display">
     <b>
      <?php echo 'ANSWER- '. $_SESSION['answer']; ?> 
    </b>
  </div> 


<table class="domain_table1">
<form action="<?php echo $_SERVER['PHP_SELF'].'#answer_btn'; ?>" method="post">
<input type="hidden" name="domain" value="<?php echo $domainId; ?>"> 

<input type="hidden" name="start" value="<?php echo $start; ?>">

 <tr> 
    <td id="top_domain_table" colspan="3">
    
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td colspan="4" class="tabs_dm_img"> 
    
    <span>
     <img src=<?php echo Link::Build($image_string); ?> alt="domain-image"  />
    </span> 
   
    <span>
    
       <ul>
    
    <?php
    // display domain tabs
     
     $selectedtab = 0;
     $selected = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($tabId))
       $selectedtab = (int)$tabId;

     if($selectedtab === (int)$domain_tabs[$i]['tab_id']){
        $selected = 'class="selected"';
      }
      else
      {
        $selected = '';
      }
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '|</a>'.'&nbsp';
     echo '</li>';
     
        
    }
    ?>
      </ul>
     
     </span>
     
    </td>  
  </tr> 



  <tr> 
    <td colspan="4" bgcolor="#00a0a0">
    
    
    
    <p class="inputfields"> 
    
    SELECT TYPE OF UNITS:
    <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($radioUnits==''||$radioUnits=='Abbrevation') echo 'checked'; 
          else echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($radioUnits=='Full') echo 'checked'; 
          else echo '';  ?> > Full
     
      <br />
      <select name="unitselected"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
 
     <input type="submit" name="units" value="GO!" class="unit"> <br />
      
      <span>IF AMOUNT EQUALS</span> 
      
      <br />
      
        <input type="text" name="amount" class="introalone" 
                                   value="<?php echo  $amount;?>"> 
       <span class="unit_ans_display"> 
           <?php echo $unitSelected; ?>
       </span>
       
       <br /> <br />
     
    <span>AND INTEREST RATE EQUALS </span>
    
    <br />
     
     <input type="text" name="interest" class="introalone" 
                                    value="<?php echo  $interest;?>">
                                    
      <br />
                                     
     <span>% PER YEAR/MONTH</span>
     
     <br />   <br />
     
    <span>AND LOAN DURATION IS </span> 
         <select name="loanyears"> 
    <?php
    
    // Display select list for number of years of investment
  
    // Number of years/months range from 1 to 80
  
     for($i=0; $i < sizeof($arr); $i++)
     {
       echo   '<option value="'.$arr[$i].'"';
               if($arr[$i] == $loanYears)
                echo 'selected';
       echo   ' >';
      
      
         echo     $arr[$i]; 
       
     
       echo   '</option>' ;
    }
    ?>
    </select> 
    <span>YEAR(S)/MONTH(S)</span>
    
    <br />  <br />
                          
    <span>THEREFORE TOTAL LOAN EQUALS</span>
    
    <br />
    
     <input type="text" name="totalloan"  class="introaloneanswer" 
                                        value="<?php echo $totalLoan;?>"> 
      <span class="unit_ans_display"> 
         <?php echo $unitSelected; ?>
      </span>
      
       <br /> 
   
   
   
     
  <input type="submit" name="answer" value="LOAN" id="answer_btn" class="domain_ans">
  <span class="ans_save" title="Saves your answers into your account">
  <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>">
  SAVE
  </a>
  </span> <br /><br />
  
  <input type="reset" value="Clear" id="clear_btn"  class="clear_input">
  
  <span class="donate">
  <a href="<?php echo Link::Build('donate.php'); ?>">
  DONATE
  </a>
  </span>
 
  </p>
  
  
    </td> 
  </tr> 
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();
 
    break;
    
    }
    /*CHANGE tab_id to proportion tab 2 - COMPOUND*/
    case 11 :
    {
      echo 'Welcome to Proportion domain, tab 2 - SAVINGS';
      echo '<a href="bank.php?tab_id=10&domain_id=6">
                      Go Back to Previous Domain</a>';
      // display form for balance tab 2   
          break;
    }
  
  /***END of Switch Case***/
  }
 
 


 unset($database_handler);
 
  // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>