<?php
/*
 * Electricity model class
 * Contains all methods to retrieve data from database SQL
*/
// Declare name space for domain models
namespace domains\domain_models;

class ElectricityModel
{
    // Retrieve domain details
    public static function GetDomainDetails($domainId)
    {
        // get domain id, name and other properties
        $query1 = "SELECT * FROM domain 
                   WHERE domain_id = $domainId"; 
                         
        return getRow($query1, $params=NULL);    
    }
    
    // Retrieve domain tabs
    public static function GetDomainTabs($domainId)
    {
	    $query2 = "SELECT tab_id, tab_name from domain_tab
                   WHERE  domain_id = $domainId";
              
    	return getAll($query2, $params = null);
	}
	
	// Retrieve domain units
	public static function GetDomainUnits($domainId)
	{
		$query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
               
    	return getAll($query3, $params = null);
	}
} 

?>