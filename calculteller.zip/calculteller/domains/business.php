<?php

 // start session
  session_start();
  
 // Start output buffer
 ob_start();

 // Obtaining root directory  from domains folder
 define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT2.'/include/config.php';
 
 // include error handling class php file
 require_once SITE_ROOT2.'/error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
   

 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 // Preprocessing: get query, form data string and get database data
 // Define short variables
 

 // check if user is logged in and display store his name and hello message
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 
 // Variables to hold answers and description to be displayed
  $_SESSION['answer']  = '';
  $_SESSION['description'] = '';
 
 /*
 // authenticate user (not required) 
 if(!isset($_SESSION['username']) || $_SESSION['username']=='')
 {
 
  fixed_html_header('CalculTELLER: Business domain calculates profits and 
                         losses to investment in business',
                      'Business Functions', $user_name, $member);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please Login to gain FULL ACCESS to all domains</h2></center>';
 echo '<p class="login_advice">';
 echo  'After you log in, you can  SAVE your answers and information
              and retrieve them anywhere in the world and at any time of the day.
              Thank You!';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('login.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
 }
 
 */
 
 // create short variable names  
   $tabId   = (!isset($_GET['tab_id']))? 8 : $_GET['tab_id'];
  $domainId = (!isset($_GET['domain_id']))? '' : $_GET['domain_id'];   
$radioUnits = (!isset($_POST['radio_units']))? 'Abbrevation': $_POST['radio_units'];
$unitSelected = (!isset($_POST['unitselected']))? 'FRS': $_POST['unitselected'];

 // Business domain short variables
 $investment =  (!isset($_POST['investment']))? '': $_POST['investment'];

 $income =  (!isset($_POST['income']))? '': $_POST['income'];

 $noYears =  (!isset($_POST['noyears']))? '': $_POST['noyears'];

 $profit = (!isset($_POST['profit']))? '': $_POST['profit'];
 
 // Temporary inner variables used for total calculations
  $_profit = '';
   
 // define array to hold the number of years of investment
 // range(1,80) creates and arry with values from 1 to 80
 $arr = range(1, 100);
 
   
  // CALL REMOVE SPACES FUNCTION TO ELIMINATE SPACES FROM INPUT NUMERIC
   if(($investment!=='') || ($income!==''))
   {
     
     // remove spaces from $investment variable
      $investment = remove_spaces($investment);
      
     // remove spaces from $income variable
      $income = remove_spaces($income);
        
   } 
 
  // get domain Id when form is submitted
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    
 // if domain ID is Not set or equals empty string, display error message
 if($domainId=='')
 {
   echo '<h2> Error: Domain Id Not Set</h2>
         <p> Please the domain Id is not set. 
          <a href="../index.php">Choose a domain here.</a>
         </p>';
   
   exit();
 }
 
 
  // look for starting marker
  // if not available, assume 0
  // $_GET['start'] is a GLOBAL variable to all functions in app
  (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
 
 
    

/*** displays different domain options and forms based on the tab selected***/  
  switch ( $tabId )
  {
    case 8 :
    {
      // display form for business tab 1  
 
 if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
  
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
 
  

 
// Test if ANSWER submit button has been clicked and execute code  
if(isset($_POST['answer']))
{
?>

<?php

  // CALL REMOVE SPACES FUNCTION TO ELIMINATE SPACES FROM INPUT NUMERIC
  if($income!=='')
        $income = remove_spaces($income);
  if($noYears!=='')
        $noYears = remove_spaces($noYears);
   if($investment!=='')
        $investment = remove_spaces($investment);
  
 
 // Temporary inner variables used for profit calculations
  $_profit = '';
 
 
 // Calculate profit, store value in $profit variable and empty $_profit
 $_profit = ((double)$income * (double)$noYears) - (double)$investment;
 $profit = $_profit;
 $_profit = '';
 
 
 // Store answer and description in SESSION variables
 
 $_SESSION['answer']  = 'PROFIT: '. $profit.' ' . $unitSelected;
 $_SESSION['description']  = 'If  INVESTMENT equals '.$investment.' ' .$unitSelected.
                             ' And INCOME  equals '.  $income.' '. $unitSelected.
                             ' PER month/year '.
                              ' therefore  PROFIT in '.$noYears.' months/years'.
                              ' equals '. $profit.' '. $unitSelected.'.';
 
 ?>
 
<?php
}

    
 // display html conponents of web page
fixed_html_header('CalculTELLER: Business domain calculates profits and 
                         losses to investment in business',
                      'Business Functions', $user_name, $member); 


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();




if(!isset($_POST['me']))
{
?>

 <div id="domain_content">
 
  <div id="answer_div" class="ans_display">
   <b>
    <?php echo 'ANS- '. $_SESSION['answer']; ?> 
  </b>
  </div> 


<table class="domain_table1">
<form action="<?php echo $_SERVER['PHP_SELF'].'#answer_btn'; ?>" method="post">
<input type="hidden" name="domain" value="<?php echo $domainId; ?>"> 

<input type="hidden" name="start" value="<?php echo $start; ?>">


   <tr> 
    <td id="top_domain_table" colspan="3">
     
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
      
    </td> 
  </tr> 

   <tr valign="top"> 
    <td colspan="4" class="tabs_dm_img">
    
     <span>
       <img src=<?php echo Link::Build($image_string); ?> alt="domain-image"  />
     </span> 
    
    <span>
  
       <ul >
    
    <?php
    // display domain tabs
     
     $selectedtab = 0;
     $selected = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($tabId))
       $selectedtab = (int)$tabId;

     if($selectedtab === (int)$domain_tabs[$i]['tab_id']){
        $selected = 'class="selected"';
      }
      else
      {
        $selected = '';
      }
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '|</a>'.'&nbsp';
     echo '</li>';
     
        
    }
    ?>
     </ul>
     
     </span>
     
    </td>  
  </tr> 


 <tr> 
    <td colspan="4" bgcolor="#00a0a0">
       
    
    <p class="inputfields"> 
    
    SELECT TYPE OF UNITS:
    <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($radioUnits==''||$radioUnits=='Abbrevation') echo 'checked'; 
          else echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($radioUnits=='Full') echo 'checked'; 
          else echo '';  ?> > Full
     
      <br />
      <select name="unitselected"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
 
     <input type="submit" name="units" value="GO!" class="unit" id="go_btn"> 
     
     <br />
      
      <span>IF INVESTMENT  EQUALS</span> 
      
      <br />
      
       <input type="text" name="investment"  class="introalone"
                                  value="<?php echo  $investment;?>"> 
        <span class="unit_ans_display"> 
          <?php echo $unitSelected; ?>
        </span>
        
        <br /> <br />
     
    <span>AND INCOME EQUALS</span> 
    
    <br />
    
     <input type="text" name="income"   class="introalone"
                                       value="<?php echo  $income;?>"> 
       <span class="unit_ans_display"> 
          <?php echo $unitSelected; ?>
       </span>
       
       <br />
       
    <span>PER month/year</span>
    
    
      <br /> <br />
    
    
    <span>THEREFOR PROFIT IN</span>
    
      <br />
     
         <select name="noyears"> 
    <?php
    
    // Display select list for number of years of investment
  
    // Number of years/months range from 1 to 80
  
     for($i=0; $i < sizeof($arr); $i++)
     {
       echo   '<option value="'.$arr[$i].'"';
               if($arr[$i] == $noYears)
                echo 'selected';
       echo   ' >';
      
      
         echo     $arr[$i]; 
       
     
       echo   '</option>' ;
    }
    ?>
    </select> 
                          
    <span>MONTHS/YEARS EQUALS</span>
    
    <br />
    
     <input type="text" name="profit"  class="introaloneanswer"
                                            value="<?php echo $profit;?>"> 
     <span class="unit_ans_display"> 
         <?php echo $unitSelected; ?>
     </span> 
     
     <br /> 
   
   
   
     
  <input type="submit" name="answer" value="PROFIT" 
                                class="domain_ans" id="answer_btn">
                                

  
  <span class="ans_save" title="Saves your answers into your account">
  <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>">
  SAVE
  </a>
  </span> <br /><br />
  
  <input type="reset" value="Clear" id="clear_btn"  class="clear_input">
  <span class="donate">
  <a href="<?php echo Link::Build('donate.php'); ?>">
  DONATE
  </a>
  </span>
 
  </p>
  
    </td> 
  </tr> 
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();


    break;
    }
    
    case 9 :
    {
      echo 'Welcome to Business domain, tab 2';
      echo '<a href="business.php?tab_id=8&domain_id=5">
                      Go Back to Previous Domain</a>';
      // display form for balance tab 2   
          break;
    }
  
  /***END of Switch Case***/
  }
 
 
 




 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>