<?php

// start session
  session_start();
  
 // Start output buffer
 ob_start();

 // Obtaining root directory  from domains folder
 define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT2.'/include/config.php';
 
 // include error handling class php file
 require_once SITE_ROOT2.'/error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
   

 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
  // check if user is logged in and display store his name and hello message
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 
 // Variables to hold answers and description to be displayed
  $_SESSION['answer']  = '';
  $_SESSION['description'] = '';


 /*
  // Authenticate user  
 if(!isset($_SESSION['username']) || $_SESSION['username']=='')
 {
 
  fixed_html_header('CalculTELLER: Proportion domain, 
                      Calculates simple proportion and predicts the future',
                      'Proportion Functions', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please Login to gain FULL ACCESS to all domains</h2></center>';
 echo '<p class="login_advice">';
 echo  'After you log in, you can  SAVE your answers and information
              and retrieve them anywhere in the world and at any time of the day.
              Thank You!';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('login.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
  // Output content from the buffer and clean buffer before exiting script
  flush();
  ob_flush();
  ob_end_clean();

  exit();
 }
 
 */
 
 
 // Preprocessing: get query, form data string and get database data
 // Define short variables
 
  
 
 
 // create short variable names  
   $tabId   = (!isset($_GET['tab_id']))? 7 : $_GET['tab_id'];
  $domainId = (!isset($_GET['domain_id']))? '' : $_GET['domain_id'];   
$radioUnits = (!isset($_POST['radio_units']))? 'Abbrevation': $_POST['radio_units'];

$unitSelected1 = (!isset($_POST['unitselected1']))? 'unit(s)': $_POST['unitselected1'];
$unitSelected2 = (!isset($_POST['unitselected2']))? 'unit(s)': $_POST['unitselected2'];


 
  
  // Proportion short variables
   $value1 =  (!isset($_POST['value1']))? '': $_POST['value1'];
   $value2 =  (!isset($_POST['value2']))? '': $_POST['value2'];
   
   $valueX =  (!isset($_POST['valuex']))? '': $_POST['valuex'];
   $answerX  = (!isset($_POST['answerx']))? '': $_POST['answerx'];
   
   
    // CALL REMOVE SPACES FUNCTION TO ELIMINATE SPACES FROM INPUT NUMERIC
   if(isset($value1) || isset($value2) || isset($valueX))
   {
     
     // remove spaces from $value1 variable
     if($value1!=='')
         $value1 = remove_spaces($value1);
      
     // remove spaces from $value2 variable
     if($value2!=='')
         $value2 = remove_spaces($value2);
      
      // remove spaces from $valueX variable
      if($valueX!=='')
          $valueX = remove_spaces($valueX);
        
   } 
 
   

 
 // get domain Id when form is submitted
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    
 // if domain ID is Not set or equals empty string, display error message
 if($domainId=='')
 {
   echo '<h2> Error: Domain Id Not Set</h2>
         <p> Please the domain Id is not set. 
          <a href="../index.php">Choose a domain here.</a>
         </p>';
   
   exit();
 }
 
 
  // look for starting marker
  // if not available, assume 0
  // $_GET['start'] is a GLOBAL variable to all functions in app
  (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
 
 
 
 /*** displays different domain options and forms based on the tab selected***/  
  switch ( $tabId )
  {
    case 7 :
    { 
    
 // display form for proportion tab 1 - SIMPLE   
 if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
  
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
   
   

   

 
// Test if ANSWER submit button has been clicked and execute code  
if(isset($_POST['answer']))
{
?>

<?php
 // calculate the unknown value using simple proportions
 // store answers to answer variables
 

 // handle division by zero error: $value1 Must be greater than zero (0) 
 if((double)$value1 > 0){ 
   $answerX = ((double)$valueX/(double)$value1)*((double)$value2);
 }
 
  
  // Store answer and description in SESSION variables
 
 $_SESSION['answer']  = 'PROPORTION: '. $answerX.' ' . $unitSelected2;
 $_SESSION['description']  = 'If '.$value1.' ' .$unitSelected1.
                             '  equals '.  $value2.' '. $unitSelected2.
                              ' therefore '. $valueX .' '. $unitSelected1.
                              ' equals '. $answerX.' '. 
                               $unitSelected2.'.';
  

 ?>
 
<?php
}

    
 // display html conponents of web page
 fixed_html_header('CalculTELLER: Proportion domain, 
                      Calculates simple proportion and predicts the future',
                      'Proportion Functions', $user_name, $member);  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();




if(!isset($_POST['me']))
{
?>


<div id="domain_content">

  <div id="answer_div" class="ans_display">
   <b>
    <?php echo 'ANS- '. $_SESSION['answer']; ?> 
   </b>
  </div> 


<table class="domain_table1"> 
<form action="<?php echo $_SERVER['PHP_SELF'].'#answer_btn'; ?>" method="post">
<input type="hidden" name="domain" value="<?php echo $domainId; ?>"> 

<input type="hidden" name="start" value="<?php echo $start; ?>">

  <tr> 
    <td id="top_domain_table" colspan="3"> 
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td colspan="4" class="tabs_dm_img"> 
    
    <span> 
      <img src=<?php echo Link::Build($image_string); ?> alt="domain-image"  />
    </span> 
    
    <span>
    
       <ul>
    
    <?php
     // display domain tabs
     
     $selectedtab = 0;
     $selected = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($tabId))
       $selectedtab = (int)$tabId;

     if($selectedtab === (int)$domain_tabs[$i]['tab_id']){
        $selected = 'class="selected"';
      }
      else
      {
        $selected = '';
      }
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '|</a>'.'&nbsp';
     echo '</li>';
     
        
    }
    ?>
     </ul>
     
     </span>
     
    </td>  
  </tr> 



  <tr> 
    <td colspan="4" bgcolor="#00a0a0">
    
    
    
    <p class="inputfields"> 
    
    SELECT TYPE OF UNITS:
   <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($radioUnits==''||$radioUnits=='Abbrevation') echo 'checked'; 
          else echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($radioUnits=='Full') echo 'checked'; 
          else echo '';  ?> > Full
     
      <br />
    
     Unit_1: <select name="unitselected1"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected1)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected1)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
    
    Unit_2:<select name="unitselected2"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected2)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected2)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
    <input type="submit" name="units" value="GO!" 
       id="go_btn" class="unit"> <br /><br />
     
      
      IF <input type="text" name="value1"  class="introalone"
                                   value="<?php echo  $value1;?>">
       <span class="unit_ans_display"> 
         <?php echo $unitSelected1; ?>
      </span>
      
      <br />
      
       
       
      EQUALS <input type="text" name="value2"  class="introalone" 
                                       value="<?php echo  $value2;?>">
       <span class="unit_ans_display"> 
         <?php echo $unitSelected2; ?>
      </span>
      
      <br /><br />
      
      THEREFORE <input type="text" name="valuex"  class="introalone"
                                        value="<?php echo  $valueX;?>">
       <span class="unit_ans_display"> 
         <?php echo $unitSelected1; ?>
      </span>
      
      <br />
       
      EQUALS <input type="text" name="answerx" class="introaloneanswer"
                                             value="<?php echo  $answerX;?>">
       <span class="unit_ans_display"> 
         <?php echo $unitSelected2; ?>
      </span>
      
      <br /> 
    
     
  <input type="submit" name="answer" value="ANSWER" id="answer_btn" class="domain_ans">
  
  <span class="ans_save" title="Saves your answers into your account">
  <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>">
  SAVE
  </a>
  </span> <br /><br />
  
  <input type="reset" value="Clear" id="clear_btn"  class="clear_input">
  <span class="donate">
   <a href="<?php echo Link::Build('donate.php'); ?>">
    DONATE
   </a>
  </span>
  </p>
  
  
    </td> 
  </tr> 
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();
 
    break;
    
    }
    /*CHANGE tab_id to proportion tab 2 - COMPOUND*/
    case 8 :
    {
      echo 'Welcome to Proportion domain, tab 2 - COMPOUND';
      echo '<a href="proportion.php?tab_id=7&domain_id=3">
                      Go Back to Previous Domain</a>';
      // display form for balance tab 2   
          break;
    }
  
  /***END of Switch Case***/
  }
 




 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>