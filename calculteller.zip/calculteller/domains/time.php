<?php

 /// start session
  session_start();
  
 // Start output buffer
 ob_start();

 // Obtaining root directory  from domains folder
 define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT2.'/include/config.php';
 
 // include error handling class php file
 require_once SITE_ROOT2.'/error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
   

 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 // check if user is logged in and display store his name and hello message
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 // Preprocessing: get query, form data string and get database data
 // Define short variables
 

 // create short variable names  
   $tabId   = (!isset($_GET['tab_id']))? 1 : $_GET['tab_id'];
  $domainId = (!isset($_GET['domain_id']))? '' : $_GET['domain_id']; 
  
   // get domain Id when form is submitted
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    
 // if domain ID is Not set or equals empty string, display error message
 if($domainId=='')
 {
   echo '<h2> Error: Domain Id Not Set</h2>
         <p> Please the domain Id is not set. 
          <a href="../index.php">Choose a domain here.</a>
         </p>';
   
   exit();
 }
 
 
 
  // look for starting marker
  // if not available, assume 0
  // $_GET['start'] is a GLOBAL variable to all functions in app
  (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
 

  // define variabls to hold timezone, date and time to be displayed
  $stimeZone = (!isset($_POST['stimezone']))? 1 : $_POST['stimezone'];
  $timeZone  = '';
  $timeDate  = '';
  $_timeDate = ''; 
  
// Get selected timezone, calculate and store time and date for that zone

if(isset($_POST['time']))
{
  $timeZone = trim($stimeZone);
  
  // Display Africa/lagos Time and Date
   date_default_timezone_set("$timeZone");
   date_default_timezone_get(); 
   
 
   // output: 'It is now 19:26 on 12-Oct-2007' for example 
    $_timeDate =  'It is now '.date('H:i', time()) 
                  .' on '.date('d/M/Y', time()).' in '. $timeZone;
    $timeDate = $_timeDate;
    $_timeDate = '';

}  


  
 
 if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
  
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
   




    
 // display html conponents of web page

fixed_html_header('CalculTELLER: Time domain -  Calculates 
                    time and date of different time zones of the globe',
                      'World Time/Date and timezones Functions', 
                        $user_name, $member);  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();




if(!isset($_POST['me']))
{
?>
 <div id="domain_content">
 
<table class="domain_table1">
<form action="<?php echo $_SERVER['PHP_SELF'].'#answer_btn'; ?>" method="post">

<input type="hidden" name="domain" value="<?php echo $domainId; ?>"> 

<input type="hidden" name="start" value="<?php echo $start; ?>">

 <tr> 
    <td id="top_domain_table" colspan="3">
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td colspan="4" class="tabs_dm_img"> 
    
    <span>
      <img src=<?php echo Link::Build($image_string); ?> alt="domain-image" />
    </span> 
    
    <span>
  
       <ul >
    
    <?php
     // display domain tabs
     
     $selectedtab = 0;
     $selectedt = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($_GET['tab_id']))
       $selectedtab = (int)$_GET['tab_id'];

     if ($selectedtab == $domain_tabs[$i]['tab_id'])
        $selectedt = 'class="selectedt"';
     
     //Generate a link for each result     
     echo "<a ".$selectedt." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '</a>'.'&nbsp';
     echo '</li>';
        
    }
    ?>
     |</ul>
     
     </span> 
     
    </td>  
  </tr> 


  <tr> 
    <td colspan="4" bgcolor="#00a0a0">
    
    
    
    <p class="inputfields"> 
    
   
      
     
  <span>If your time zone is not found on the list, scroll down and 
        select your timezone to view time and date in your 
        area in 24 Hours Format<br />
      <b>Refresh Page to see Current Time and Date!</b>      
  </span>
     
 
   <br /><br />
   
   <span class="donate">
   <a href="<?php echo Link::Build('donate.php'); ?>">
   DONATE
   </a>
  </span>
 
  </p>
  
  
    </td> 
  </tr> 
  
  <tr>
  <td colspan="4"><label>GMT Time and Date:</label>
  <?php
  // Get  GMT time
  // Formats a GMT/UTC date and time
  //returns GMT time relative to 'now' 

  echo 'It is now <b>'.gmdate('H:i', time()).'</b>'; 
  echo ' on <b>'.gmdate('d/M/Y', time()).'</b>';
  echo ' GMT'.'<br />';
  ?>
  </td>
  </tr>  
    
   <tr>
   <td  colspan="4">
  
   <?php
   // Display Africa/lagos Time and Date
   date_default_timezone_set("Africa/Lagos");
   
   echo ' <img src="'.Link::Build('ct-flags/ng.png'). 
                  '" alt="ng" style="max-width: 100%; 
                                vertical-align: middle;" />';
                                
   echo ' '.date_default_timezone_get(); 
   echo ': ';

   // get current date and time format and display the values  
   // output: 'It is now 19:26 on 12-Oct-2007' 
   echo 'It is now <b>'.date('H:i', time()).'</b>'; 
   echo ' on <b>'.date('d/M/Y', time()).'</b> in Africa/Lagos';
   ?>
   
   </td>
   </tr>
   
   <tr>
   <td  colspan="4">
   <?php
   // Display Africa/lagos Time and Date
   date_default_timezone_set("America/New_York");
   
   echo ' <img src="'.Link::Build('ct-flags/us.png'). 
                  '" alt="us" style="max-width: 100%; 
                                vertical-align: middle;" />';
   
   echo ' '.date_default_timezone_get(); 
   echo ': ';

   // get current date and time format and display the values  
   // output: 'It is now 19:26 on 12-Oct-2007' 
   echo 'It is now <b>'.date('H:i', time()).'</b>'; 
   echo ' on <b>'.date('d/M/Y', time()).'</b> in America/New_York';  
   ?>
   </td>
   </tr>
   
   <tr>
   <td  colspan="4">
   <?php
   // Display Europe/Paris Time and Date
   date_default_timezone_set("Europe/Paris");
   
    echo ' <img src="'.Link::Build('ct-flags/fr.png'). 
                  '" alt="fr" style="max-width: 100%; 
                                vertical-align: middle;" />';
   
   echo ' '.date_default_timezone_get(); 
   echo ': ';

   // get current date and time format and display the values  
   // output: 'It is now 19:26 on 12-Oct-2007' 
   echo 'It is now <b>'.date('H:i', time()).'</b>'; 
   echo ' on <b>'.date('d/M/Y', time()).'</b> in Europe/Paris';  
   ?>
   </td>
   </tr>
   
   <tr>
   <td  colspan="4">
   <?php
   // Display America/Argentina/San_Juan Time and Date
   date_default_timezone_set("America/Argentina/San_Juan");
   
   echo ' <img src="'.Link::Build('ct-flags/ar.png'). 
                  '" alt="ar" style="max-width: 100%; 
                                vertical-align: middle;" />';
   
   echo ' '.date_default_timezone_get(); 
   echo ': ';

   // get current date and time format and display the values  
   // output: 'It is now 19:26 on 12-Oct-2007' 
   echo 'It is now <b>'.date('H:i', time()).'</b>'; 
   echo ' on <b>'.date('d/M/Y', time()).'</b> in America/Argentina/San_Juan';  
   ?>
   </td>
   </tr>
   
   <tr>
   <td  colspan="4">
   <?php
   // Display Asia/Bangkok Time and Date
   date_default_timezone_set("Asia/Bangkok");
   
    echo ' <img src="'.Link::Build('ct-flags/th.png'). 
                  '" alt="th" style="max-width: 100%; 
                                vertical-align: middle;" />';
   
   echo ' '.date_default_timezone_get(); 
   echo ': ';

   // get current date and time format and display the values  
   // output: 'It is now 19:26 on 12-Oct-2007' 
   echo 'It is now <b>'.date('H:i', time()).'</b>'; 
   echo ' on <b>'.date('d/M/Y', time()).'</b> in Asia/Bangkok';  
   ?>
   </td>
   </tr>
   
   <tr>
   <td  colspan="4">
   <?php
   // Display Canada/Central Time and Date
   date_default_timezone_set("Canada/Central");
   
    echo ' <img src="'.Link::Build('ct-flags/ca.png'). 
                  '" alt="ca" style="max-width: 100%; 
                                vertical-align: middle;" />';
   
   echo ' '.date_default_timezone_get(); 
   echo ': ';

   // get current date and time format and display the values  
   // output: 'It is now 19:26 on 12-Oct-2007' 
   echo 'It is now <b>'.date('H:i', time()).'</b>'; 
   echo ' on <b>'.date('d/M/Y', time()).'</b> in Canada/Central';  
   ?>
   </td>
   </tr>
   
   <tr>
   <td  colspan="4">
    <?php
   // Display Australia/Melbourne Time and Date
   date_default_timezone_set("Australia/Melbourne");
   
    echo ' <img src="'.Link::Build('ct-flags/au.png'). 
                  '" alt="au" style="max-width: 100%; 
                                vertical-align: middle;" />';
   
   echo ' '.date_default_timezone_get(); 
   echo ': ';

  // get current date and time format and display the values  
   // output: 'It is now 19:26 on 12-Oct-2007' 
   echo 'It is now <b>'.date('H:i', time()).'</b>'; 
   echo ' on <b>'.date('d/M/Y', time()).'</b> in Australia/Melbourne';  
   ?>
   </td>
   </tr>
   
   <tr>
   <td  colspan="4">
   <?php
   // Display Atlantic/Cape_Verde Time and Date
   date_default_timezone_set("Atlantic/Cape_Verde");
   
   echo ' <img src="'.Link::Build('ct-flags/cv.png'). 
                  '" alt="cv" style="max-width: 100%; 
                                vertical-align: middle;" />';
   
   echo ' '.date_default_timezone_get(); 
   echo ': ';

   // get current date and time format and display the values  
   // output: 'It is now 19:26 on 12-Oct-2007' 
   echo 'It is now <b>'.date('H:i', time()).'</b>'; 
   echo ' on <b>'.date('d/M/Y', time()).'</b> in Atlantic/Cape_Verde';  
   ?>
   </td>
   </tr>
   
   <tr>
   <td  colspan="4">
   <?php
   // Display Europe/London Time and Date
   date_default_timezone_set("Europe/London");
   
    echo ' <img src="'.Link::Build('ct-flags/gb.png'). 
                  '" alt="gb" style="max-width: 100%; 
                                vertical-align: middle;" />';
   
   echo ' '.date_default_timezone_get(); 
   echo ': ';

   // get current date and time format and display the values  
   // output: 'It is now 19:26 on 12-Oct-2007' 
   echo 'It is now <b>'.date('H:i', time()).'</b>'; 
   echo ' on <b>'.date('d/M/Y', time()).'</b> in Europe/London';  
   ?>
   </td>
   </tr>
  
  
   <tr>
      <td  colspan="4">
      <label>Please select Timezone(Continent/City):
        <select name="stimezone"> 
    <?php
    
    // Get built in PHP timezones identifiers 
    // Returns an indexed array with all timezone identifiers
    $timeZoneIdentifiers = timezone_identifiers_list();
    
    
    // Display a timezone select element with different timezones as options
  
     for($i=0; $i < sizeof($timeZoneIdentifiers ); $i++)
     {
       echo   '<option value="'.$timeZoneIdentifiers[$i].'"';
               if($timeZoneIdentifiers[$i] == $stimeZone)
                echo 'selected';
       echo   ' >';
      
      
         echo     $timeZoneIdentifiers[$i]; 
       
     
       echo   '</option>' ;
    }
    ?>
    </select>
    
      <input type="text" name="timezone" value="<?php echo $timeZone  ?>">
      <input type="text" name="timedate" size="60"  class="unit_ans_display" 
                                  value="<?php echo $timeDate; ?>">
      
      </td>
      
   </tr> 
  
 <tr>
 <td colspan="4">
 <input type="submit" name="time" value="TIME/DATE" class="domain_ans" id="answer_btn">
 
 <br /><br />
 </td>
 </tr> 
  
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();
 
 
 




 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>