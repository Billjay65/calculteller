<?php

 // start session
  session_start();
  
 // Start output buffer
 ob_start();

 // Obtaining root directory  from domains folder
 define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT2.'/include/config.php';
 
 // include error handling class php file
 require_once SITE_ROOT2.'/error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
   

 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 // Preprocessing: get query, form data string and get database data
 // Define short variables
 

 // check if user is logged in and display store his name and hello message
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 
 // Authenticate user 
 if(!isset($_SESSION['username']) || $_SESSION['username']=='')
 {
 
  fixed_html_header('CalculTELLER: Balance domain calculates 
                    your change in less than a second',
                      'Balance (Change) Functions', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please Login to gain FULL ACCESS to all domains</h2></center>';
 echo '<p class="login_advice">';
 echo  'After you log in, you can  SAVE your answers and information
              and retrieve them anywhere in the world and at any time of the day.
              Thank You!';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('login.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
  // Output content from the buffer and clean buffer before exiting script
  flush();
  ob_flush();
  ob_end_clean();
 
 
 exit();
 }
 
 
 
  $_SESSION['answer']  = '';
 $_SESSION['description'] = '';
 
  
 
 
 // create short variable names  
   $tabId   = (!isset($_REQUEST['tab_id']))? 15 : $_REQUEST['tab_id'];
  $domainId = (!isset($_GET['domain_id']))? '' : $_GET['domain_id'];   
$radioUnits = (!isset($_POST['radio_units']))? 'Abbrevation': $_POST['radio_units'];
$unitSelected = (!isset($_POST['unitselected']))? 'm': $_POST['unitselected'];

   // Radius of circle
   $radius =  (!isset($_POST['radius']))? '': $_POST['radius'];
  
   
   // Perimeter of circle
   $perimeter =  (!isset($_POST['perimeter']))? '': $_POST['perimeter'];
   
   $button  = (!isset($_POST['answer']))? '': $_POST['answer'];
   

   // CALL REMOVE SPACES FUNCTION TO ELIMINATE SPACES FROM INPUT NUMERIC
   if($radius!=='')
   {
     
     // remove spaces from $radius variable
      $radius = remove_spaces($radius);

   } 
 
 // get domain Id when form is submitted
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    
 // if domain ID is Not set or equals empty string, display error message
 if($domainId=='')
 {
   echo '<h2> Error: Domain Id Not Set</h2>
         <p> Please the domain Id is not set. 
          <a href="../index.php">Choose a domain here.</a>
         </p>';
   
   exit();
 }
 
 
  // look for starting marker
  // if not available, assume 0
  // $_GET['start'] is a GLOBAL variable to all functions in app
  (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
 
 
    


 /*** displays different domain options and forms based on the tab selected***/  
  switch ( $tabId )
  {
    case 15 :
    {
    
      // display form for measurements tab 1 - CIRCLE  
 
 if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
  
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
   
//$radioUnits = (!isset($_POST['radio_units']))? 'Full': $_POST['radio_units'];   

   
/* // Set domain Units to FULL or Abbrevation depending 
 if(isset($_POST['units'))
 {
   for($i=0; $i < sizeof($domain_units); $i++)
    {
      echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
              if($domain_units[$i]['unit_id'] == 1)
                echo 'selected';
      echo   ' >';
      
      if($radioUnits=='' || $radioUnits=='Abbrevation')
         echo     $domain_units[$i]['abbrevation']; 
      else if($radioUnits == 'Full')
         echo     $domain_units[$i]['unit_name'];
     
      echo   '</option>' ;
    }
     
 
 }
*/   
   
   
// Test if GO submit button has been clicked then set units   
/*if(isset($_POST['units']))
 {
    $units   =  $_POST['units'];
 }
 */  
 
// Test if ANSWER submit button has been clicked and execute code  
if(isset($_POST['answer']))
{
?>

<?php
 // sanitize input submitted (trim, test if numeric, test, length, html entities...)
 // use addslashes(), htmlspecialchar(), trim ...to clean and then store data in DB
 
 
 
 $perimeter = $radius*3.141592653589*2;
 
  
 
 // Store answer and description in SESSION variables
 
 $_SESSION['perimeter'] = $perimeter;
 
 $_SESSION['answer'] = 'PERIMETER: '. $perimeter.' ' . $unitSelected;
 $_SESSION['description'] = 'If RADIUS of CIRCLE equals '.$radius.' ' .$unitSelected.
                              ' therefore PERIMETER of CIRCLE equals '. $perimeter.' '. 
                               $unitSelected.'.';
 
 
 
  
  // Balance formula: subtract total amount from cost amount
  

 ?>
 
<?php
}

    
 // display html conponents of web page
fixed_html_header('CalculTELLER: Measurements domain calculates dimensions and 
                  quantities of objects like the circumference and area of a circle',
                      'Measurements Functions', $user_name, $member);  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();




if(!isset($_POST['me']))
{
?>

 <div id="answer_div" class="ans_display">
  <b>
  <?php echo 'ANSWER- '. $_SESSION['answer']; ?> 
  </b>
  </div> 
     
 <div>
<table width="100%" border="0">
<form action="<?php echo $_SERVER['PHP_SELF'].'#answer_btn'; ?>" method="post">
<input type="hidden" name="domain" value="<?php echo $domainId; ?>"> 

<input type="hidden" name="start" value="<?php echo $start; ?>">

  <tr> 
    <td id="top_domain_table" colspan="3" bgcolor="#00a0a0">
      
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td  rowspan="2"> 
     <img src=<?php echo Link::Build($image_string); ?> alt="domain-image" width="150px" height="70px" />
    </td> 
    
    <td  colspan="2"> 
  
       <ul >
    
    <?php
     // display domain tabs
     
     $selectedtab = 0;
     $selectedt = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($_GET['tab_id']))
       $selectedtab = (int)$_GET['tab_id'];

     if ($selectedtab == $domain_tabs[$i]['tab_id'])
        $selectedt = 'class="selectedt"';
     
     //Generate a link for each result     
     echo "<a ".$selectedt." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '</a>'.'&nbsp';
     echo '</li>';
        
    }
    ?>
     |</ul>
    </td>  
  </tr> 

  <tr valign="top" colspan="2"> 
    
    <td  > 
        Technical and Managerial Tutorials 
    </td> 
    
  </tr> 


  <tr> 
    <td colspan="3" bgcolor="#00a0a0">
    
    
    
    <p class="inputfields"> 
    
    SELECT TYPE OF UNITS:
    <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($radioUnits==''||$radioUnits=='Abbrevation') echo 'checked'; 
          else echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($radioUnits=='Full') echo 'checked'; 
          else echo '';  ?> > Full
     
      <br />
      
     
     
      
      IF RADIUS OF CIRCLE EQUALS <input type="text" name="radius" 
            value="<?php if(isset($radius)) 
                          echo $radius; ?>" />
      
      <select name="unitselected"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
    
      <br />
      
    THEREFORE <b>PERIMETER OF A CIRCLE</b>   EQUALS
  <input type="text" name="perimeter" 
              value="<?php if(isset($_SESSION['perimeter'])) 
                          echo $_SESSION['perimeter'].' '.$unitSelected; ?>">
               
     <br />  
     
  <input type="submit" name="answer" value="PERIMETER"  id="answer_btn" class="domain_ans">
  
  <span class="ans_save" title="Saves your answers into your account">
  <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>">
  SAVE
  </a>
  </span> <br /><br />
  
  <span class="donate">
  <a href="<?php echo Link::Build('donate.php'); ?>">
  DONATE
  </a>
  </span>
 
 
  </p>
  
  
    </td> 
  </tr> 
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();

     break;
    }
    
    case 16 :
    {
      echo 'Welcome to Measurements domain, tab 2 - RECTANGLE';
      echo '<a href="measurements.php?tab_id=15&domain_id=8">
                      Go Back to Previous Domain</a>';
      // display form for balance tab 2   
          break;
    }
  
  /***END of Switch Case***/
  }
 
 
 
 




 unset($database_handler);
 
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>