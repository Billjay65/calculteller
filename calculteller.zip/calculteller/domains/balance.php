<?php

 // start session
  session_start();
  
 // Start output buffer
 ob_start();

 // Obtaining root directory  from domains folder
 define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

 // include config file containing directory paths
 require_once SITE_ROOT2.'/include/config.php';
 
 // include error handling class php file
 require_once SITE_ROOT2.'/error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
   

 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 // Preprocessing: get query, form data string and get database data
 // Define short variables
 

 // check if user is logged in and display store his name and hello message
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;

 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ; 
  
 
 
 // Variables to hold answers and description to be displayed
  $_SESSION['answer']  = '';
  $_SESSION['description'] = '';
  
  // create short variable names  from input submitted in http request
   $tabId   = (!isset($_REQUEST['tab_id']))? 1 : $_REQUEST['tab_id'];
  $domainId = (!isset($_GET['domain_id']))? '' : $_GET['domain_id']; 
    
$radioUnits = (!isset($_POST['radio_units']))? 'Abbrevation': $_POST['radio_units'];
//$radioUnits = (!isset($_POST['radio_units']))? 'Full': $_POST['radio_units'];
$unitSelected = (!isset($_POST['unitselected']))? 'XAF': $_POST['unitselected'];

 
 // get domain Id when form is submitted
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    
 // if domain ID is Not set or equals empty string, display error message
 if($domainId=='')
 {
   echo '<h2> Error: Domain Id Not Set</h2>
         <p> Please the domain Id is not set. 
          <a href="../index.php">Choose a domain here.</a>
         </p>';
   
   exit();
 }
 
  // look for starting marker
  // if not available, assume 0
  // $_GET['start'] is a GLOBAL variable to all functions in app
  (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
 
  
  
 /*** displays different domain options and forms based on the tab selected***/  
  switch ( $tabId )
  {
  
    // Single Item tab selected
    case 1 :
    {
      // display form for balance tab 1 
      if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
  
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
   
   // get values submitted in form
   $amount1 =  (!isset($_REQUEST['amount1']))? '': $_POST['amount1'];
   $amount2 =  (!isset($_REQUEST['amount2']))? '': $_REQUEST['amount2'];
   
   
   // amount 3 is the balance
   $amount3 =  (!isset($_REQUEST['amount3']))? '': $_REQUEST['amount3'];
   $button  = (!isset($_POST['answer']))? '': $_POST['answer'];
   
   // CALL REMOVE SPACES FUNCTION TO ELIMINATE SPACES FROM INPUT NUMERIC
  if($amount1!=='')
        $amount1 = remove_spaces($amount1);
  if($amount2!=='')
        $amount2 = remove_spaces($amount2);
   if($amount3!=='')
        $amount = remove_spaces($amount3);
 
 
// Calculate ANSWER by  executing  code below  
 
 $amount3 = (double)$amount1 - (double)$amount2;
 
  
 
 // Store answer and description in SESSION variables
 
 $_SESSION['answer']  = 'BALANCE: '. $amount3.' ' . $unitSelected;
 $_SESSION['description']  = 'If AMOUNT equals '.$amount1.' ' .$unitSelected.
                             ' and item COST equals '.  $amount2.' '. $unitSelected.
                              ' therefore BALANCE equals '. $amount3.' '. 
                               $unitSelected.'.';
 
 
 
  
  // Balance formula: subtract total amount from cost amount
  

 ?>
 
<?php


    
 // display html conponents of web page
fixed_html_header('CalculTELLER: Balance domain calculates 
                    your change in less than a second',
                      'Balance (Change) Functions', $user_name, $member);  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();

 

if(!isset($_POST['me']))
{

// add jQuery and Ajax functions
?>


<script type="text/javascript" 
        src=<?php echo Link::Build('js/jquery-3.3.1.min.js'); ?>></script>
<!-- Place jquery code in scripts/domain_scripts folder-->
<script type="text/javascript" 
        src=<?php echo Link::Build('scripts/domain_scripts/balance_jquery.js'); ?>></script>

     
 <div id="domain_content">
 
  <div id="answer_div" class="ans_display">
   <b>
    <?php echo 'ANSWER- '. $_SESSION['answer']; ?> 
    </b>
  </div> 

<!-- add ajax feature later and update answer div too -->
<table class="domain_table1">
 
<form action="<?php echo $_SERVER['PHP_SELF'].'#answer_btn'; ?>" 
      method="post" id="balanceFormTab1" onsubmit="return true;"> 
      <!-- onsubmit="return findBalanceSimple(this);" --> > 
 

<input type="hidden" name="domain" value="<?php echo $domainId; ?>"> 

<input type="hidden" name="start" value="<?php echo $start; ?>">

<input type="hidden" name="tab_id" value="<?php echo $tabId; ?>">

  <tr> 
    <td id="top_domain_table" colspan="3">
      
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td colspan="4" class="tabs_dm_img"> 
    
    <span>
     <img src=<?php echo Link::Build($image_string); ?> alt="domain-image"  />
    </span>
  
     <span>
     
       <ul>
    
    <?php
     // display domain tabs
     
     $selectedtab = 0;
     $selected = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($tabId))
       $selectedtab = (int)$tabId;

     if($selectedtab === (int)$domain_tabs[$i]['tab_id']){
        $selected = 'class="selected"';
      }
      else
      {
        $selected = '';
      }
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '|</a>'.'&nbsp';
     echo '</li>';
     
        
    }
    ?>
     </ul>
     
    </span>
    
   </td>  
  </tr> 


  <tr> 
    <td colspan="4" bgcolor="#00a0a0">
    
    
    
    <p class="inputfields"> 
    
    SELECT TYPE OF UNITS:
    <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($radioUnits==''||$radioUnits=='Abbrevation') echo 'checked'; 
          else echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($radioUnits=='Full') echo 'checked'; 
          else echo '';  ?> > Full
     
      <br />
      <select name="unitselected"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
 
     <input type="submit" name="units" value="GO!" class="unit"> <br />
      
      IF AMOUNT EQUALS <input type="text" name="amount1" class="introalone"
                            value="<?php echo  $amount1;?>" id="amount1"> 
      <span class="unit_ans_display"> 
         <?php echo $unitSelected; ?>
      </span>
      
     
      <br />
     
      
    AND ITEM COST EQUALS
   <input type="text" name="amount2" class="introalone" 
                    value="<?php echo $amount2;?>" id="amount2">
    
      <span class="unit_ans_display"> 
         <?php echo $unitSelected; ?>
     </span>
     
     
     <br />   
     
      
      HENCE BALANCE EQUALS
  <input type="text" name="amount3"  class="introaloneanswer"  
                    value="<?php echo $amount3; ?>" id="amount3"> 
  
    <span class="unit_ans_display"> 
         <?php echo $unitSelected; ?>
      </span>
      
      
      
     <br />  
     
  <input type="submit" name="answer" value="BALANCE" id="answer_btn" class="domain_ans">
  
  <input type="reset" value="Clear" id="clear_btn" class="clear_input">
  
  <span class="ans_save" title="Saves your answers into your account">
  <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>" target="_blank">
  SAVE
  </a>
  </span> 
  
  <div id="updating" style="visibility: hidden; 
   position: absolute; z-index: 3">Updating ...</div>
  
  <span class="donate">
  <a href="<?php echo Link::Build('donate.php'); ?>">
  DONATE
  </a>
  </span>
 
 
  </p>
  
  
    </td> 
  </tr> 
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();
     
          break;
    }
    
    
     case 2 :
    {
        // Shopping List tab selected 
 
 if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
   // set default units to percentage (%) for tab 2 - Score
   $unitSelected = (!isset($_POST['unitselected']))? 'XAF': $_POST['unitselected'];
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
   
   

 // Variables for school domain number rows of input data for average calculation
 // (Number of subjects corresponds to number of rows) for tab 1
 
  // item checkbox: used to confirm bought or selected items
  // get array of checked items
  $box = (!isset($_POST['box']))? array('') : $_POST['box'];
 
  //subject_number used in loop to generate number of records to display
  $itemNumber = (!isset($_POST['item_number']))? DOMAIN_ROWS_NO : (int)$_POST['item_number'];
  
  // subjectNo array to hold numbers and names subjects: number and name (STRING) for each subject
  $itemName =  (!isset($_POST['itemname']))? array('') : $_POST['itemname'];
  
  $quantity = (!isset($_POST['quantity']))? array('') : $_POST['quantity'];
  
  $unitPrice = (!isset($_POST['unitprice']))? array('') : $_POST['unitprice']; 
 
 $productQtyUnitPrice = (!isset($_POST['productqtyuprice']))? array('') : $_POST['productqtyuprice']; 
 
 // Shopping List totals variables and calculations

   $totalItems        =  (!isset($_POST['totalitems']))? 0: $_POST['totalitems'];
   $totalQuantity     = (!isset($_POST['totalquantity']))? 0: $_POST['totalquantity'];
   $totalUnitPrice    = (!isset($_POST['totalunitprice']))? 0: $_POST['totalunitprice'];
   $totalQtyUnitPrice =  (!isset($_POST['totalqtyuprice']))? 0: $_POST['totalqtyuprice'];
   
    
   // amount submitted by user from shopping list form
   $amount  = (!isset($_REQUEST['amount']))? 0: $_REQUEST['amount'];

 
  // Temporary balance variables 
  $_balance = '';
  

  // Temporary inner variables used for total calculations
  $_totalItems = '';
  $_totalQuantity = 0.00;
  $_totalUnitPrice = 0.00;
  $_totalqtyuprice = 0.00;
  $totalQtyUnitPrice = 0.00;
 
 // Balance variable
 $balance  = (!isset($_POST['balance']))? '' : $_POST['balance']; 
 
  
  
  // handle load file button
  // get uploaded file from form 
  if(isset($_POST['load']))
  {
    
    
    /*
    echo 'Load File button clicked';
    
    // for testing purposes delete later
    echo '<pre>';  
    print_r($_FILES);
    echo '</pre>'; 
    */
    
    try
    {
    
      if ((isset($_FILES['uploadedfile']) && 
              $_FILES['uploadedfile']['error'] === UPLOAD_ERR_OK))
      {
      
        // get details of the uploaded file
        $fileTmpPath = $_FILES['uploadedfile']['tmp_name'];
        $fileName = $_FILES['uploadedfile']['name'];
        $fileSize = $_FILES['uploadedfile']['size'];
        $fileType = $_FILES['uploadedfile']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));
        
        // sanitize file-name - not necessary here, for future use
        $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
        
        // check if file has correct extension .csv 
        $allowedFileExtensions = array('csv');
        
        if (in_array($fileExtension, $allowedFileExtensions))
        {
           // directory in which the uploaded file will be moved
           // use $newFileName to make all files unique in directory
           // get full directory (on server)
           $dirPath = realpath(dirname(__FILE__));
           $uploadFileDir = $dirPath . '/uploaded_files/';
           $destPath = $uploadFileDir . $newFileName;
           
           // move file to new location
           if (move_uploaded_file($fileTmpPath, $destPath))
           {
             // for testing delete later
             //echo 'File moved successfully';
             
             // define array to hold file contents
             $wholeFile = array();
             $tableData = array();
             // $data holds only values without table headers
             $data = array();
             $totalsAnswers = array();
             
             // open file and read its content
             $handle = fopen($destPath, "r");
             
             if(!$handle){
               throw new Exception('Error: File open failed.');
             }
      
             // read and store output of the entire contents of csv file
             // reading each row at a time
             while (($result = fgetcsv($handle)) !== false)
             {
               array_push($wholeFile, $result);  
             }
             
             fclose($handle);
             
             // for testing delete later
             //print_r($wholeFile);
             
             
             // test to make sure $wholeFile is an array
             if (is_array($wholeFile)){
               // store total number of rows in file
               $fileTotalRows = count($wholeFile);
              }
               
              // explode the wholefile array into data and totals 
              // we know totals and answers are the last two
              // rows so use -2 as index
              $tableData = array_slice($wholeFile, 0, 
                                         ($fileTotalRows - 2));
              // for testing delete later                            
              //print_r($tableData);
              
              // slice $tableData and remove table headers
              if (is_array($tableData)){
               // store number of records of $tableData
               $tableDataTotalRows = count($tableData);
              }
              $data = array_slice($tableData, 1,
              
                                  $tableDataTotalRows - 1);
              // for testing delete later
              //print_r($data);
              
              
              // slice whole file to get table ending rows
              // totals and answers 
              $totalsAnswers = array_slice($wholeFile, -2, 2);
              
              // for testing delete later
              //print_r($totalsAnswers);
              
              
              // set table variables to new values gotten 
              // from csv file which will be displayed in table
              // subject_number used in loop to generate number
              // of records to display
              
              // here $itemNumber is set to number of data records
              $itemNumber = count($data);
  
              // use a single loop knowing each
              // data record has four values corresponding to 
              // four indexes 0, 1, 2, 3
              for ($i = 0; $i < $itemNumber; $i++)
              {
                  // subjectNo array to hold numbers and names subjects: number and name (STRING) for each subject
                  $itemName[$i] = $data[$i][0] ;  
                  
                  $quantity[$i] = $data[$i][1] ;
                  
                  $unitPrice[$i] = $data[$i][2] ;
                  
                  $productQtyUnitPrice[$i] = $data[$i][3] ;
                
               }
               
                 // Shopping List totals variables and calculations
                 $totalItems = $totalsAnswers[0][0];
                 $totalQuantity = $totalsAnswers[0][1];
                 $totalUnitPrice = $totalsAnswers[0][2];
                 $totalQtyUnitPrice = $totalsAnswers[0][3];
    
                 // amount submitted by user from shopping list form
                 // explode $totalsAnswers[1][0] array to get amount
                 $amountArray = explode(' ', $totalsAnswers[1][0]);
                 $amount  = (float)$amountArray[1];
                 
                 // for testing delete later
                 //echo $amount . 'I AM AMOUNT';
 
                 // Balance variable
                 // explode $totalsAnswers[1][1] array to get balance
                 $balanceArray = explode(' ', $totalsAnswers[1][1]);
                 $balance  = $balanceArray[1];
                 
                 // for testing delete later
                 // echo $balance; 
  
  
              }
              
              else
              {
                throw new Exception('Error: There was an error moving the 
                                  file to upload directory.'); 
               }    
                   
           }
           else
           {
             throw new Exception('Error: Upload failed. File extension 
                                 not allowed.');   
           }
           
            
        
        }
        
        else
        {
      
          // if file is not set or upload error  
          // simply skip load file code and continue script
          // execution. break out of else block
          // DO NOTHING for now
          // TODO: prepare error message to display on page
        
          /*
          // if file is not set or upload error redirect user 
          // back to initial http page. if the user does not 
          // select a file, he is redirected to same page
          // Error: This does not work when answer btn is hit
          // because domain id is sent through hiddern form fields
          $linkToCancelPage = (!isset($_SERVER['HTTP_REFERER']))? '' : 
                                                $_SERVER['HTTP_REFERER'];
        
          header('Location:'.$linkToCancelPage);
        
        
          throw new Exception('There is some error in the file upload. Please
                               check the following error in 
                               $_FILES["uploadedfile"]["error"]');
          */
        
       }
        
        
     }
     catch(Exception $e)
     {
       // if debugging is set to true in error_handler, the error
       // message will traceback will be displayed, else user 
       // friendly error message will be displayed
       // trigger_error is a php built-in function used with error handlers
       trigger_error($e->getMessage(), E_USER_ERROR);
       
      }
       
       
  }
    
     
  
  
  // handle addsubject button
  if(isset($_POST['additem']))
  {
     $itemNumber++;
  
  } 

 // CALL REMOVE SPACES FUNCTION TO ELIMINATE SPACES FROM INPUT NUMERIC
   if(isset($itemNumber) || isset($quantity) || isset($unitPrice) || 
        isset($amount) )
   {
     
     // remove spaces from $subjectNumber variable
     $itemNumber = remove_spaces($itemNumber);
     $itemNumber = (int)$itemNumber;
      
     // remove spaces from $amount variable
      $amount = remove_spaces($amount);
      
        
     for($i=0; $i < $itemNumber; $i++)
     {
       // try to set $quantity array to avoid errors 
       if(!isset($quantity[$i]) ||($quantity[$i]=='') )
        {
          $quantity[$i] = '';
        }
        if(!isset($unitPrice[$i]) ||($unitPrice[$i]=='') )
        {
          $unitPrice[$i] = '';
        }   
        
       
        // remove spaces from $quantity array 
        $quantity[$i] = remove_spaces($quantity[$i]);
        
        // remove spaces from $unitPrice array
        $unitPrice[$i] = remove_spaces($unitPrice[$i]);
  
     }
     
     
     /*** For testing and debugging purposes - delete later
       echo  'Value: ' . $i . '<br />';
        if(is_int($itemNumber)){
          echo 'True';
        }
        echo  'Quantitiy ' . count($quantity);
        
    ***/
        
  
     
   }
   
  
 // Display of row numbers set initially
 for($i=0; $i < $itemNumber; $i++)
 {
    // Initially, if any form input array is not set or is Empty, initialize it 
    // with an empty string to avoid Error Notices
    if(!isset($quantity[$i]) ||($quantity[$i]=='') )
    {
    
      // set default quantity to 1 for all rows or records 
      $quantity[$i] = 1;
    }
    
    if(!isset($unitPrice[$i]) ||($unitPrice[$i]=='') )
    {
      $unitPrice[$i] = '';
    }
    
    
     $itemNo[$i] = $i + 1;
      
   // Create text to display in first column Item
   if(!isset($itemName[$i]) ||($itemName[$i]==''))
   {
      $itemName[$i] = '';
      $itemName[$i] = '('.$itemNo[$i].')';
      $itemName[$i] = (string)$itemName[$i]; 
      
   }
     
    
     $productQtyUnitPrice[$i] = floatval($quantity[$i]) * floatval($unitPrice[$i]);
     
     
   
    // calculate SUM of quantity column
    $_totalQuantity += floatval($quantity[$i]);
   
    // calculate SUM of unitPrice column
    $_totalUnitPrice += floatval($unitPrice[$i]);
   
   
    // SUM of QtyUnitPrice column
    $_totalqtyuprice += $productQtyUnitPrice[$i];
   
   
 } 
 
 
 
 // Quantity total
 $totalQuantity = $_totalQuantity;
 $_totalQuantity = ''; 
 
 // Total unitPrice calculation
 $_totalItems = $itemNumber;
 $totalItems = $_totalItems;
 $_totalItems = '';
 
 // total coeff   calculation
 $totalUnitPrice = $_totalUnitPrice;
 $_totalUnitPrice = '';
 
 // total QuantityUnitPrice calculation
 $totalQtyUnitPrice = $_totalqtyuprice;
 $_totalqtyuprice = '';
 
 
 
 // BALANCE CALCULATIONS
 // calculate balance: no fraction hence no division by zero
 // test required
    $_balance = $amount - $totalQtyUnitPrice;
  
    $balance =  $_balance;
    
    
    // Store answer and description in SESSION variables
 
 $_SESSION['answer']  = 'BALANCE: '. $balance.' ' . $unitSelected;
 $_SESSION['description']  = 'If AMOUNT equals '.$amount.' ' .$unitSelected.
                             ' and item(s) COST equals '.  $totalQtyUnitPrice.
                              ' '. $unitSelected.
                              ' therefore BALANCE equals '. $balance.' '. 
                               $unitSelected.'.';
                               
  // handle save as file button
  // save file after all calculations have been executed
  // place this code close to form display
  if(isset($_POST['save']))
  {
    // create a csv file in user_files directory inside current
    // working directory using 
    
    // create data array of arrays
    // create headers of table file first
    $table = array( 
               array('ITEM(S)', 'QUANTITY', 'Unit Price', 
                     'TOTAL(Q x uP)')
             );
    // loop over table and add rows to array
    for($i=0; $i < $itemNumber ; $i++) 
    {
      // convert $itemName to positive if numeric
      if(is_numeric($itemName[$i]))
      {
        $itemName[$i] = abs($itemName[$i]);
      } 
      
      // for testing purposes delete 
      //echo $itemName[$i];
      
      array_push($table, array($itemName[$i], $quantity[$i], $unitPrice[$i],  
                               $productQtyUnitPrice[$i]));
       
    }
    // add totals, amount and balance to table array
    array_push($table, array('No_Items: ' .$totalItems, 
                             'Total_Qty: '. $totalQuantity,
                             'Total_Uprice: ' . $totalUnitPrice,  
                             'Total_QuP: ' .$totalQtyUnitPrice .' '. $unitSelected)); 
    array_push($table, array('Amount: ' . $amount .' '. $unitSelected, 
                             'Balance: '. $balance .' ' . $unitSelected ,
                             '',  
                             ''));
                             
    // filename in user_files directory
    // the filename is the current date and time with 
    // prefix SHPX_LST that is SHPX_LST_20230109_195400
    $filename = 'user_files/SHPX_LST_' . date("Ymd_His", time()) . '.csv';
    
    try
    {
      $fp = fopen($filename, 'w');
      
      if(!$fp){
        throw new Exception('Error: File open failed.');
      }
      
      // for testing purposes delete after tests
      // echo $filename;
      // print_r($table);
      for ($j=0; $j < count($table); $j++)
      {
        fputcsv($fp, $table[$j]);
      }
      
      fclose($fp);
    }
    catch(Exception $e)
    {
      // if debugging is set to true in error_handler, the error
      // message will traceback will be displayed, else user 
      // friendly error message will be displayed
      // trigger_error is a php built-in function used with error handlers
      trigger_error($e->getMessage(), E_USER_ERROR);
       
    }
    
    // for testing purposes delete after test
    // echo 'Save as File button clicked';
    // exit();
    
    // clean output buffer before downloading file
    ob_clean();
    
    // download file
    header('Content-type: text/csv');
    header('Content-disposition:attachment; filename="'.$filename.'"');
    readfile($filename);
    
    // very important if not the whole html page is written
    // to file KEY
    // delete all echo statements and output to screen
    exit(); 
  }
   
  
     
 // display html conponents of web page
fixed_html_header('CalculTELLER: Balance domain calculates 
                    your change in less than a second',
                      'Balance (Change) Functions', $user_name, $member);  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();

 

if(!isset($_POST['me']))
{
?>

<script type="text/javascript">
function clearFields(){        
  document.getElementById("balanceFormTab2").reset();
  document.getElementById("quantity").value = ''; 
  document.getElementById("unitprice").value = '';
  document.getElementById("productmxc").value = '';
}
</script>

<div id="domain_content">
 
 <div id="answer_div" class="ans_display">
    <b>
    <?php echo 'ANSWER- '. $_SESSION['answer']; ?> 
   </b>
  </div> 
 
<table width="100%" class="domain_table1">

<form enctype="multipart/form-data" method="post" 
        action="<?php echo $_SERVER['PHP_SELF'].'#answer_btn'; ?>" 
        id="balanceFormTab2" >

 <input type="hidden" name="domain" value="<?php echo $domainId; ?>"> 

 <input type="hidden" name="tab_id" value="<?php echo $tabId; ?>"> 


  <tr> 
    <td id="top_domain_table" colspan="5"> 
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td colspan="5" class="tabs_dm_img"> 
     
      <span>
       <img src=<?php echo Link::Build($image_string); ?> alt="domain-image"/>
     </span>
  
     <span>
     
       <ul>
    
    <?php
     // display domain tabs
     
     $selectedtab = 0;
     $selected = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset($tabId))
       $selectedtab = (int)$tabId;

      if($selectedtab === (int)$domain_tabs[$i]['tab_id']){
        $selected = 'class="selected"';
      }
      else
      {
        $selected = '';
      }
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '|</a>'.'&nbsp';
     echo '</li>';
     
        
    }
    ?>
     </ul>
     
    </span>
     
     
    </td>  
  </tr> 



  <tr> 
    <td colspan="5" bgcolor="#00a0a0">
    
    
    
    <p class="inputfields"> 
    
    SELECT TYPE OF UNITS:
    <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($radioUnits==''||$radioUnits=='Abbrevation') echo 'checked'; 
          else echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($radioUnits=='Full') echo 'checked'; 
          else echo '';  ?> > Full
     
      <br />
      <select name="unitselected"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
 
  <input type="submit" name="units" value="SET AS CURRENT" class="unit"><br /><br />
    
   <span class="donate">
     <a href="<?php echo Link::Build('donate.php'); ?>">
      DONATE
    </a>
  </span>
 
  </p>
  
  
    </td> 
  </tr> 
  

  
  <tr>
  <td colspan="5"><label>NUMBER of ITEMS</label>
    <input type="text" name="item_number" value="<?php echo $itemNumber; ?>"> 
    
    <br />
    
    <label>AMOUNT</label> 
    <input type="text" name="amount" value="<?php echo $amount; ?>"> 
    
      <span class="unit_ans_display"> 
         <?php echo $unitSelected; ?>
      </span>
   
     <input type="submit" name="gamesnumber" value="GO!" class="unit"
       id="games_number"> <br />
  
  </td>
  </tr>  
  <tr>
      <td><!--check_list for items -->&nbsp;</td>
      <td style="min-width: 8em;">ITEM(S)</td>
      <td >QUANTITY</td>
      <td >Unit Price</td>
      <td >TOTAL(Q x uP)</td>
   </tr>   
 
 
 
 <!-- Display the number of rows of data specified for domain-->
<?php

 
  for($j=0; $j < $itemNumber ; $j++) 
  {
    if($j%2!==0)
    {
     echo '<tr>';
    }
    elseif($j%2==0)
    {
      echo '<tr class="stripy_row">';
    }
    
    echo  '<td style="width:6px">'.
            '<input type="checkbox" name="box[]" value="'. $j . '" ';
             for($k=0; $k < count($box); $k++){
               if($box[$k] == $j)
                 echo 'checked'; 
             }
    echo  ' /> </td>';
    echo  '<td rowspan='.'"1"'.'>'.'<input type="text"'.'name="itemname[]"'.
              'value="'.$itemName[$j].'">'. ' </td>';
    echo  '<td>'.'<input type="text" id="quantity"'.'name="quantity[]"'.'value="'.$quantity[$j] .'">'.'</td>';
    echo  '<td>'.'<input type="text" id="unitprice"'.'name="unitprice[]"'.'value="'.$unitPrice[$j] .'">'.'</td>';
    echo  '<td>'.'<input type="text" id="productmxc"'.'name="productmxc[]"'.'value="'. $productQtyUnitPrice[$j].'">'.'</td>';
  
    echo  '</tr>';
    
  }

    
 ?> 
 
 

   <tr>
      <td><!--check box list --></td>
      <td ><input type="text" name="totalitems" value="<?php echo 'No_Items: '. $totalItems ?>"></td>
      <td ><small>Total_Qty</small><input type="text" name="totalqtyuprice" value="<?php echo $totalQuantity; ?>"></td>
     
      <td ><small>Total_Uprice</small><input type="text" name="totalunitprice" value="<?php echo $totalUnitPrice  ?>"></td>
      <td ><small>Total_QuP</small><input type="text" name="totalqtyuprice" value="<?php echo $totalQtyUnitPrice  ?>">
       <br />
       <span class="unit_ans_display"> 
          <?php echo $unitSelected; ?>
       </span>
      </td>
   </tr>  
  <tr>
   <td colspan="5">
    <label>BALANCE</label>
    <input type="text" name="balance" class="unit_ans_display"
                                   value="<?php echo $balance; ?>"> 
     <span class="unit_ans_display"> 
         <?php echo $unitSelected; ?>
      </span>
   
   </td>
 </tr>  
 <tr>
   <td colspan="5">
     <input type="submit" name="answer" value="BALANCE" id="answer_btn" class="domain_ans"> 
      <span class="ans_save" title="Saves your answers into your account">
        <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>">
          SAVE
        </a>
      </span>
      <input type="submit" name="additem" value="ADD ITEM"  class="addgame" id="add_game"> <br /> 
      <input type="reset" value="Clear" id="clear_btn"  onclick="clearFields()" 
        class="clear_input">
      <input type="submit" name="save" value="Save As File"  class="addgame" id="save"><br /> 
      
      
        <!-- inputs for load file functionality -->
        <input size="50" type="file" name="uploadedfile">
        <input type="submit" name="load" value="Load File"  class="addgame" id="load"> <br />
      </form>
      <br /><br />
    </td>
 </tr> 
  

 </table> 


</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();
 
 
  break;
    }
  
  
  /***END of Switch Case***/
  }
 
 



 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>