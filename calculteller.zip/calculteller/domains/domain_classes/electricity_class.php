<?php

/* Electricity class
 * included in electricity domain
 * @file electricity.php
 * Coding style, four spaces indent, camel casing methods
 * underscore for private properties, camel case properties
 */
// Declare name space for domain classes
namespace domains\domain_classes;
// Use namespace domains\domain_models
// This is the location of the class electricity_model.php
use domains\domain_models as DM;
 
class Electricity{
	// Constant definitios for
	// Electricity actions
	const INITIAL = 0;
	const ANSWER = 1;
    const ADD_RECORD = 2;
    const SAVE_RECORD = 3; 
    const EDIT_RECORD = 4;
    const UPDATE_RECORD = 5;
    const DELETE_RECORD = 6;
    const DISPLAY_RECORDS = 7;
    
	// Public properties
	// Short property names  from input submitted in http request
    public $tabId;
    public $domainId;
    public $radioUnits;
    public $unitSelected;
    public $start;
    public $postToken;
    
    // Properties to hold data retrieved from database
    // Domain details, tabs etc
    public $domainDetails;
    public $domainTabs;
    public $domainUnits;
    // Properties to hold sanitized data
    public $domainName;
    public $description;
    public $domainImage;
    public $imageString; 
    
    // Properties to hold continue browsing or cancel page link
    public $linkToCancelPage;
    
    // Properties to hold calculated values
    // Get values submitted in form for calculation
    public $userDate;     
   	public $currentReadx;
   	public $previousReadx; 
    public $unitCost;
	public $units;
	public $bill;
	
	// private properties
	private $_recordId;
	private $_electricityAction;
	
     
	// class constructor
	public function __construct()
	{
		// Variables to hold answers and description to be displayed
		$_SESSION['answer']  = '';
		$_SESSION['description'] = '';
		
		// Initialize initial short properties 
		// from input submitted in http request set initial domain_id to 12
        $this->tabId   = (!isset($_REQUEST['tab_id']))? 18 : $_REQUEST['tab_id'];
        $this->domainId = (!isset($_REQUEST['domain_id']))? 12 : $_REQUEST['domain_id'];
        
        if (!empty($_REQUEST['domain_id']))
        {
        	$this->domainId =  $_REQUEST['domain_id'];
    	}   
        $this->radioUnits = (!isset($_POST['radio_units']))? 
                          'Abbrevation': $_POST['radio_units'];
        $this->unitSelected = (!isset($_POST['unitselected']))? 
                             'XAF': $_POST['unitselected'];
        
        // look for starting marker
        // if not available, assume 0
        (!isset($_REQUEST['start'])) ? 
            $this->start = 0 : $this->start = $_REQUEST['start'];
        
        // Get previous http link clicked to get here    
        $this->linkToCancelPage = (!isset($_SERVER['HTTP_HOST']))? '' : $_SERVER['HTTP_HOST'] . '/calculteller/index.php';
         						      
        // Delete this later 						      
        // echo $this->linkToCancelPage;
        
        
        
        // Get values submitted in form
   		$this->userDate     =  (!isset($_REQUEST['userdate']))? '': 
   		                          $_REQUEST['userdate'];
   		$this->currentReadx =  (!isset($_REQUEST['currentreadx']))? '': 
   			htmlentities(str_replace(' ', '', trim($_REQUEST['currentreadx'])));;
   		$this->previousReadx =  (!isset($_REQUEST['previousreadx']))? '': 
   			htmlentities(str_replace(' ', '', trim($_REQUEST['previousreadx'])));;
   		$this->unitCost      =  (!isset($_REQUEST['unitcost']))? '': 
   			htmlentities(str_replace(' ', '', trim($_REQUEST['unitcost'])));;
   							
   		// Calculate units and bill					
   		$this->units      =  (!isset($_REQUEST['units']))? '': 
   							$_REQUEST['units'];
   		$this->bill       =  (!isset($_REQUEST['answer']))? '': 
   							$_REQUEST['answer'];
   							
         						      
        
         // Get initial form action from domain tab 18
         // either answer, save or records 
         if (isset($_REQUEST['submit_btn']) && 
                 ($_REQUEST['submit_btn'] == 'Answer'))
	     {
		    $this->_electricityAction = (int)self::ANSWER;
		    
		    // Delete later for testing purposes
	        // echo 'Bill button clicked';
	        
	        
	        //exit();    
		 }
		 else if (isset($_REQUEST['submit_btn']) && 
                 ($_REQUEST['submit_btn'] == 'Save'))
	     {
		    $this->_electricityAction = (int)self::SAVE_RECORD;
		    
		    // Delete later for testing purposes
	        // echo 'SAVE button clicked';
	         
	        
	        //exit();    
		 }
		 else if (isset($_REQUEST['submit_btn']) && 
                 ($_REQUEST['submit_btn'] == 'View Records'))
	     {
		    $this->_electricityAction = (int)self::DISPLAY_RECORDS;
		    
		    // Delete later for testing purposes
	        // echo 'DISPLAY_RECORDS button clicked'; 
	        
	        //exit();   
		 }
		 else if (isset($_REQUEST['submit_btn']) && 
                 ($_REQUEST['submit_btn'] == 'Add Bill'))
	     {
		    $this->_electricityAction = (int)self::DISPLAY_RECORDS;
		    
		    // Delete later for testing purposes
	        // echo 'ADD_RECORD button clicked'; 
	        
	        //exit();    
		 }
		 else if (!isset($_REQUEST['submit_btn']) ||
                     !($_REQUEST['submit_btn'] == 'Answer')) 
		 {
		     $this->_electricityAction = (int)self::INITIAL;
		     
		     // Delete later for testing purposes
		     // echo 'INITIAL no  button clicked';
	         
	         
	         //exit();	 
		 }
		
		 
		 
	     // Delete later for testing purposes
	     /*
		 echo '<br />';
		 echo $_SESSION['token'];
		 
		 if(isset($_POST['csrf_token'])){
		     echo $_POST['csrf_token'] . '<br />';
	     }	
	     */
	     
	     // Get and store value of postToken 
	     $this->postToken = (!isset($_POST['csrf_token']))?
			                          '' : $_POST['csrf_token'];
	   
        						      	
	}
	
	public function init()
	{
		// Displays different domain tab options and 
		// forms based on the tab selected  
		switch ($this->tabId)
  		{
  
    		// Bill Tenant tab selected
			case 18 :
			{
        		// Display form for electricity tab 1 
				if(isset($this->domainId) )
				{
					// Get domain id, name and other properties
					// Call electricity model function
					// Use name space of ElectricityModels
					$this->domainDetails =  
						     DM\ElectricityModel::
						       GetDomainDetails($this->domainId);
						       
					// Get domain tabs
					$this->domainTabs =
							  DM\ElectricityModel::
						       GetDomainTabs($this->domainId);
					
					// Get domain units
					$this->domainUnits =
							  DM\ElectricityModel::
						       GetDomainUnits($this->domainId);
						       
				    $this->domainName = strip_tags
				                            ($this->domainDetails['name']);
                    $this->description = strip_tags
                                             ($this->domainDetails['description']);
                    $this->domainImage = strip_tags
                                             ($this->domainDetails['image']);
                    $this->imageString = 'images/'. $this->domainImage;
                    
                    
	                
	                // Switch block for domain tab  form actions
	                // check if a particular btn was clicked
	                // check to make sure csrf token was set and is correct
	                switch ($this->_electricityAction)
	                { 
		                // const SAVE_RECORD = 3; 
		            	case self::INITIAL:
		            	{
			               // Delete later for testing purposes
			               // echo 'No btn clicked yet Initial state';
			               
			               break;
			            }  
		                // const ANSWER = 1; 
		            	case self::ANSWER:
		            	{   
			            	// Delete later for testing purposes
			                // echo 'Don\'t redirect me please' . 'Bill is here';
			                
			                if($this->verifyToken($this->postToken,$_SESSION['token']))
			                {
				                
				                // Delete later for testing purposes 
				            	// echo 'TOKEN matches: Great news ';
				            	
				            	// Execute code to calculate electric bill
				            	// Call function to calculate number of units
				            	$this->units = $this->calculateUnits($this->currentReadx, 
				            	                $this->previousReadx); 
				            	
				            	// Call function to calculate bill 
				            	$this->bill = $this->calculateBill($this->userDate,
				            	      $this->currentReadx, $this->previousReadx, 
				            	      $this->unitCost);
				            	
				            	// Store answer and description in SESSION variables
 
                                $_SESSION['answer']  = 'ELECTRIC BILL: '. $this->bill .
                                                       ' ' . $this->unitSelected;
                                                       
                                $_SESSION['description']  = 'If Date: ' .
                                           $this->userDate . '  ' . 
                                           ' Current Reading: ' . 
                                           $this->currentReadx . '  ' .
                                           ' Previous Reading: '.
                                           $this->previousReadx . '  '. 
                                           ' Unit Cost: ' . 
                                           $this->unitCost . '  '.
                                           'Hence Units Equals: ' .
                                            $this->units . '  ' .
                                           'Hence ELECTRIC BILL equals: '.
                                            $this->bill . ' ';     
				            	      
				            	      
                                     
				            }
				            else
				            {
					            
					            // If token is not the same, Redirect use to index
					            header("Location: " . $this->linkToCancelPage);
					                
					        } 

							break; 		
			            }
			            
			            // const SAVE_RECORD = 3; 
		            	case self::SAVE_RECORD:
		            	{
			                // Execute code to calculate electric bill      
			                // echo 'Save Record Button Clicked';
			                break;
			            }  
			             
   
		             }
	                
	                
                    	   
                // END OF Display form for electricity tab 1
				}
				
  	        // END OF Bill Tenant tab selected
			}
			
	    // END OF switch block Displays different domain tab
		}
		
    // END OF public function init()
	}
	
	public function  verifyToken($postToken, $sessionToken)
	{
		if (isset($postToken) && 
		       ($postToken == $sessionToken))
		{
		    return True;	
		}
		else
		{
			return False;
		}	
    
	// End of verifyToken method	
    }
    
    public function calculateBill ($userDate, $currentReadx,
                     $previousReadx, $unitCost)
    {
	    
	    /*
	    // Validate date if any errors, add to $_SESSION['elec_error']
	    // variable and return false. check if there are errors
	    // in electricity.php and display error div
	    
	    // Validate submitted userDate
	    // split date value into components 
        $dateArr = explode('/', $userDate); 
 
        // calculate timestamp corresponding to date value 
        $dateTs = strtotime($userDate); 
 
        // calculate timestamp corresponding to 'today' 
        $now = strtotime('today'); 
        
        // check that the value entered is in the correct format 
        if (sizeof($dateArr) != 3) { 
            $_SESSION['elec_error'] = 'Date Error!';
            return false;
        } 
      
        // check that the value entered is a valid date 
        if (isset($dateArr[0]) && isset($dateArr[1]) && isset($dateArr[2])
               && !checkdate($dateArr[0], $dateArr[1], $dateArr[2])) { 
            $_SESSION['elec_error'] = 'Date Error!';
            return false;
        } 
         
        // check that the date entered is earlier than 'today' 
        if ($dateTs >= $now) { 
            $_SESSION['elec_error'] = 'Date Error!';
            return false;
        } 
        */
	    
	    // If validation is successful return calculated  bill
	    $units = $this->calculateUnits($currentReadx, $previousReadx);
	    
   		$bill  = (double)$units * (double)$unitCost;
   		
   		return $bill;  
	    
	// End of calculateBill method 
	}
	
	public function calculateUnits($currentReadx, $previousReadx)
	{
	    $units = (double)$currentReadx - (double)$previousReadx;
	    return $units;	
    }
	
	
	
// END OF class Electricity	
}









/* for testing purposes test class modifiers
class Electricity{
	//protected $_welcome;
	public $_welcome;
     
	
    // initialize welcome message
     
	public function __contruct(){
		$this->welcome = "Welcome to Electricity";  
	}
	
	// display welcome message to user
	public function welcomeUser(){
    	echo $this->_welcome; 
    	$tabId   = (!isset($_REQUEST['tab_id']))? 1 : $_REQUEST['tab_id'];
    	echo        
	}
	
	// set welcome message to user
	public function setWelcomeUser(){
    	$this->_welcome = 'Water Bill';        
	}

}
*/

?>