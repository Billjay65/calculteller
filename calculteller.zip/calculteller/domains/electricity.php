<?php

// Start session
session_start();

 
// Generate an anti-CSRF token if one doesn't exist
// Token is unique across all pages since it is only
// defined if the token is not set yet 
if (!isset($_SESSION['token']))
{
	$_SESSION['token'] = sha1(uniqid(mt_rand(), TRUE));
}
  
// Start output buffer
ob_start();

// Obtaining root directory  from domains folder
// constant SITE_ROOT2 is used because SITE_ROOT has
// already been defined and used in config.php
define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
require_once SITE_ROOT2.'/include/config.php';
 
// include error handling class php file
require_once SITE_ROOT2.'/error_handler.php';
 
// Set the error handler
ErrorHandler::SetHandler();
   

// include the calculteller functions file containing all fns
require_once FUNCTIONS_DIR. 'calculteller_fns.php';

// include the electricity_class file containing all Electricity class
require_once SITE_ROOT2. '/domains/domain_classes/electricity_class.php';

// include the electricity_model file containing all Electricity models SQL
require_once SITE_ROOT2. '/domains/domain_models/electricity_model.php';
 
// check if user is logged in and display store his name and hello message
$user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;

//Flag to see if user is a member(Registered to Calculteller)
$member = ($user_name!='')? true : false ; 
 
// call authenticate_user function from calculteller
// for testing purposes UMCOMMENT LINE BELOW TO AUTHENTICATE USER after testing 
// authenticate_user($user_name);


// Use namespace domains\domain_models
// This is the location of the class electricity_model.php
use domains\domain_models as DM;




// Create electricity class
// Use the namespace domains\domain_classes\ 
// This is the location of class file electricity_class.php
$electricity = new domains\domain_classes\Electricity();

// Call electricity init method
$electricity->init();

// if domain ID is Not set or equals empty string, display error message
if($electricity->domainId=='')
{
   echo '<h2> Error: Domain Id Not Set</h2>
         <p> Please the domain Id is not set. 
          <a href="../index.php">Choose a domain here.</a>
         </p>';
   
   exit();
}
 
  
// For testing purposes 
// Test electricity class methods and properties
//var_dump($electricity); 


// Displays different domain tab options and 
// forms based on the tab selected  
switch ($electricity->tabId)
{
	// Bill Tenant tab selected
	// Do all the calculations for domain in
	// this file and use data valid functions included here
	case 18 :
	{   
		// Delete later for testing purposes
		// echo 'Tab 18 selected';
	
   							
   		// Answer button: delete later after test
   		$button  = (!isset($_POST['answer']))? '': $_POST['answer'];
   
  

 ?>
 
<?php


    
 // display html conponents of web page
fixed_html_header('CalculTELLER: Electricity domain calculates 
                    electric bills of tenants, landloards and more',
                      'Electricity Bill Functions', $user_name, $member);  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();

 

if(!isset($_POST['me']))
{

// add jQuery and Ajax functions
?>

<script type="text/javascript" 
        src=<?php echo Link::Build('js/jquery-3.3.1.min.js'); ?>></script>
<!-- uncomment and replace with elec_jquery.js later
<script type="text/javascript" 
        src=<?php echo Link::Build('scripts/domain_scripts/balance_jquery.js'); ?>></script>
 -->
    
<div id="domain_content">

	<div id="answer_div" class="ans_display">
    	<b>
    	<?php echo 'ANSWER- '. $_SESSION['answer']; ?> 
    	</b>
  	</div> 
  	
  	<!-- add ajax feature later and update answer div too -->
	<table class="domain_table1">
  	
  		<form action="<?php echo $_SERVER['PHP_SELF'].'#answer_btn'; ?>"
  	 		method="post", id="elecFormTab1" onsubmit="return true;">
  	 		<!--DO LATER onsubmit="return findElecBill(this);" --> 
  	 	
  	 		<!-- implement csrf attack mitigation -->
  	 		<input type="hidden" name="csrf_token" id="csrf_token"   
  	 	    	value="<?php echo $_SESSION['token']; ?>" >
  	 	    	
  	 	    <input type="hidden" name="domain_id" 
  	 	           value="<?php echo $electricity->domainId; ?>"> 

			<input type="hidden" name="start" 
			       value="<?php echo $electricity->start; ?>">

			<input type="hidden" name="tab_id" 
			       value="<?php echo $electricity->tabId; ?>">
			       
		<tr> 
    		<td id="top_domain_table" colspan="3">
      
      			<h1>Calculteller:<?php echo $electricity->domainName; ?> 
      			    Domain </h1> 
      			<span><?php echo $electricity->description; ?></span>
    		</td> 
		</tr> 

		<tr valign="top"> 
    		<td colspan="4" class="tabs_dm_img"> 
    
    		<span>
     			<img src=<?php echo Link::Build($electricity->imageString); ?> 
     				alt="domain-image"  />
    		</span>
  
			<span>
     
       <ul>
    
	<?php
    // display domain tabs
     
	$selectedtab = 0;
	$selected = '';
    
	for($i=0; $i < sizeof($electricity->domainTabs); $i++)
    {
		echo   '<li style="float:left; list-style:none;">';
     
     
    	if (isset($electricity->tabId))
       		$selectedtab = (int)$electricity->tabId;

     	if($selectedtab === (int)$electricity->domainTabs[$i]['tab_id']){
        	$selected = 'class="selected"';
      	}
      	else
      	{
        	$selected = '';
      	}
     
     	//Generate a link for each result     
     	echo "<a ".$selected." href=". 
     	         Link::ToDomainTab($electricity->domainTabs[$i]['tab_id'],
     	         $electricity->domainId). ">";
     	echo '| '. strtoupper($electricity->domainTabs[$i]['tab_name']);
     	echo   '|</a>'.'&nbsp';
     	echo '</li>';
             
	}
    ?>
     </ul>
     
			</span>
    
			</td>  
		</tr> 
  	 	
  	 	
		<tr> 
          <td colspan="4" bgcolor="#00a0a0">
          
          
            <p class="inputfields"> 
            
            
            SELECT TYPE OF UNITS:
    <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($electricity->radioUnits==''||$electricity->radioUnits=='Abbrevation') 
          	echo 'checked'; 
          else 
          	echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($electricity->radioUnits=='Full') 
            echo 'checked'; 
          else 
            echo '';  ?> > Full
     
      <br />
      
      <select name="unitselected"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
     if($electricity->radioUnits == 'Abbrevation') 
     {
     	for($i=0; $i < sizeof($electricity->domainUnits); $i++)
     	{
       		echo   '<option value="'.$electricity->domainUnits[$i]['abbrevation'].'"';
               		if($electricity->domainUnits[$i]['abbrevation'] == $electricity->unitSelected)
                	echo 'selected';
       		echo   ' >';
      
      
         	echo     $electricity->domainUnits[$i]['abbrevation']; 
       
     
       		echo   '</option>' ;
    	}
    }  
    if($electricity->radioUnits == 'Full')
    {
     	for($i=0; $i < sizeof($electricity->domainUnits); $i++)
     	{
      		echo'<option value="'.$electricity->domainUnits[$i]['unit_name'].'"';
             	  if($electricity->domainUnits[$i]['unit_name'] == $electricity->unitSelected)
                 echo 'selected';
       		echo   ' >';
      
      
     
         	echo     $electricity->domainUnits[$i]['unit_name'];
     
       		echo   '</option>' ;
     	}
    } 
    ?>
    
    </select> 
 
     <input type="submit" name="units" value="GO!" class="unit"> <br /><br />
            
            
            
  			<label>DATE</label> 
  			<input type="date" name="userdate"  id="userdate" class="introalone"
  				value="<?php echo $electricity->userDate; ?>" /><br />
  			
  			<label>CURRENT READING </label>	
  	    	<input type="text" name="currentreadx"  id="currentreadx" class="introalone"
  				value="<?php echo $electricity->currentReadx; ?>" /><br /> 
  		
  			<label>PREVIOUS READING</label> 
  			<input type="text" name="previousreadx"  id="previousreadx" class="introalone"
  				value="<?php echo $electricity->previousReadx; ?>" /><br /> 
  				
  		    <label>COST PER UNIT</label> 
  			<input type="text" name="unitcost"  id="unitcost" class="introalone"
  				value="<?php echo $electricity->unitCost; ?>" /><br /> 
  				
  		    <em>HENCE NUMBER OF UNITS</em>
            <input type="text" name="units"  class="introaloneanswer"  
                   value="<?php echo $electricity->units; ?>" id="units"><br /> 
  
  				
  		    <b>HENCE ELECTRIC BILL EQUALS</b> <br />
            <input type="text" name="answer"  class="introaloneanswer"  
                   value="<?php echo $electricity->bill; ?>" id="bill"> 
  
           <span class="unit_ans_display"> 
               <?php echo $electricity->unitSelected; ?>
           </span><br />
  			
  			
  			
  		    <input type="submit" name="submit_btn" value="Answer"  class="addgame" 
  		    	id="answer_btn">
  		    	
  		    <span class="ans_save" title="Saves your answers into your account">
              <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>" target="_blank">
               SAVE
              </a>
            </span> 
  		      
  			<input type="submit" name="submit_btn" value="View Records"  class="addgame" 
  		    	id="records" disabled> <br />
  		    
  			<input type="submit" name="submit_btn" value="Add Bill"  class="addgame" 
  		    	id="add" disabled> 
  		    	
  		    <input type="reset" value="Clear" id="clear_btn" class="clear_input">
  
             <br /><br />
  		    
            <span class="donate">
              <a href="<?php echo Link::Build('donate.php'); ?>">
                DONATE
              </a>
            </span>
  		    	
            
  		      </p>
  		    	
  		      </td> 
        	</tr> 
  		</form>	
	</table>

</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();
     
          break;
    }
    
    
     case 2 :
    {
        
 
 
  break;
    }
  
  
/***END of Switch Case***/
}
 
 



 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>