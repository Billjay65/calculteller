<?php

 // start session
  session_start();
  
 // Start output buffer
 ob_start();

 // Obtaining root directory  from domains folder
 define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT2.'/include/config.php';
 
 // include error handling class php file
 require_once SITE_ROOT2.'/error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
   

 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
  // check if user is logged in and display store his name and hello message
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 /* 
 // Authenticate user 
 if(!isset($_SESSION['username']) || $_SESSION['username']=='')
 {
 
  fixed_html_header('CalculTELLER: Balance domain calculates 
                    your change in less than a second',
                      'Balance (Change) Functions', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please Login to gain FULL ACCESS to all domains</h2></center>';
 echo '<p class="login_advice">';
 echo  'After you log in, you can  SAVE your answers and information
              and retrieve them anywhere in the world and at any time of the day.
              Thank You!';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('login.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 // Output content from the buffer and clean buffer before exiting script
  flush();
  ob_flush();
  ob_end_clean();
 
 
 exit();
 }
 */
 
 
 $_SESSION['answer']  = '';
 
 $_SESSION['description'] = '';
 
  
 
 
 // create short variable names  
   $tabId   = (!isset($_REQUEST['tab_id']))? 13 : $_REQUEST['tab_id'];
  $domainId = (!isset($_GET['domain_id']))? '' : $_GET['domain_id'];   
$radioUnits = (!isset($_POST['radio_units']))? 'Abbrevation': $_POST['radio_units'];
$unitSelected = (!isset($_POST['unitselected']))? 'FRS': $_POST['unitselected'];
   $name =  (!isset($_POST['name']))? '': $_POST['name'];
   $dob =  (!isset($_POST['dob']))? '': $_POST['dob'];
   
   // amount 3 is the balance
   $amount3 =  (!isset($_POST['amount3']))? '': $_POST['amount3'];
   $button  = (!isset($_POST['answer']))? '': $_POST['answer'];
   

 
 // get domain Id when form is submitted
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    
 // if domain ID is Not set or equals empty string, display error message
 if($domainId=='')
 {
   echo '<h2> Error: Domain Id Not Set</h2>
         <p> Please the domain Id is not set. 
          <a href="../index.php">Choose a domain here.</a>
         </p>';
   
   exit();
 }
 
  // look for starting marker
  // if not available, assume 0
  // $_GET['start'] is a GLOBAL variable to all functions in app
  (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
    

 
  /*** displays different domain options and forms based on the tab selected***/  
  switch ( $tabId )
  {
    case 13 :
    {
      // display form for age tab 1 - age 
 
 if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
  
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
   

   // display input validation error 
    function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        return "<div class=\"error\">ERROR: Form filled Incorrectly! <br />
                                Invalid data for field '$key'</div><br />"; 
      } else { 
        return false; 
      } 
    }
    
    // array to hold input errors and errorFlag
    $inputErrors = array();
    
    $errorFlag   = false;
     
   
//$radioUnits = (!isset($_POST['radio_units']))? 'Full': $_POST['radio_units'];   

   
/* // Set domain Units to FULL or Abbrevation depending 
 if(isset($_POST['units'))
 {
   for($i=0; $i < sizeof($domain_units); $i++)
    {
      echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
              if($domain_units[$i]['unit_id'] == 1)
                echo 'selected';
      echo   ' >';
      
      if($radioUnits=='' || $radioUnits=='Abbrevation')
         echo     $domain_units[$i]['abbrevation']; 
      else if($radioUnits == 'Full')
         echo     $domain_units[$i]['unit_name'];
     
      echo   '</option>' ;
    }
     
 
 }
*/   
   
   
// Test if GO submit button has been clicked then set units   
/*if(isset($_POST['units']))
 {
    $units   =  $_POST['units'];
 }
 */  
 
// Test if ANSWER submit button has been clicked and execute code  
if(isset($_POST['answer']))
{
?>

<?php
 // split date value into components 
      $dateArr = explode('/', $_POST['dob']); 
 
      // calculate timestamp corresponding to date value 
      $dateTs = strtotime($_POST['dob']); 
 
      // calculate timestamp corresponding to 'today' 
      $now = strtotime('today'); 
      
      
       // check that the the user has entered a correct name Not greater
       // than 32 characters 
      if (empty($name) || (strlen($name)) > 32){ 
        $inputErrors[] = 'name';
        $errorFlag = True; 
      } 
      
      // check that the value entered is in the correct format 
      if (sizeof($dateArr) != 3) { 
        $inputErrors[] = 'Date of birth';
        $errorFlag = True; 
      } 
      
      // check that the value entered is a valid date 
      if (isset($dateArr[0]) && isset($dateArr[1]) && isset($dateArr[2])
            && !checkdate($dateArr[0], $dateArr[1], $dateArr[2])) { 
        $inputErrors[] = 'Date of birth';
        $errorFlag = True;
      } 
       // check that the date entered is earlier than 'today' 
      if ($dateTs >= $now) { 
        $inputErrors[] = 'Date of birth';
        $errorFlag = True;
      } 
 
 
  if(!$errorFlag){
      // if there are No Errors in input
      // calculate difference between date of birth and today in days 
      // convert to years 
      // convert remaining days to months 
      // save output to be printed output 
      $ageDays = floor(($now - $dateTs) / 86400); 
      $ageYears = floor($ageDays / 365); 
      $ageMonths = floor(($ageDays - ($ageYears * 365)) / 30); 
      $ageDisplay = "You are approximately $ageYears year(s) and $ageMonths month(s) old."; 
 
  
 
    // Store answer and description in SESSION variables
 
   $_SESSION['answer']  = 'AGE: '. $ageYears.'yr(s) '. $ageMonths.'mth(s)' ;
   $_SESSION['description']  =  $name.' '.'is '.$ageYears.'yr(s) '. $ageMonths.'mth(s)'
                               .'old';
                            
  }
  

 ?>
 
<?php
}

    
 // display html conponents of web page
fixed_html_header('CalculTELLER: Age domain calculates and reveals your 
                      age, birthday, how long you have to live and other
                       important information of your lifetime.',
                      'Age(Birth) Functions', $user_name, $member);  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();




if(!isset($_POST['me']))
{
?>

<div id="domain_content">

 <div id="answer_div" class="ans_display">
   <b>
    <?php echo 'ANSWER- '. $_SESSION['answer']; ?> 
  </b>
  </div> 
     

<table class="domain_table1"> 
<form action="<?php echo $_SERVER['PHP_SELF'].'#add_game'; ?>" method="post">
<input type="hidden" name="domain" value="<?php echo $domainId; ?>">

<input type="hidden" name="start" value="<?php echo $start; ?>"> 

 <tr> 
    <td id="top_domain_table" colspan="3">
      
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td colspan="4" class="tabs_dm_img"> 
    
    <span>
      <img src=<?php echo Link::Build($image_string); ?> alt="domain-image" />
    </span> 
    
       <ul >
    
    <?php
     // display domain tabs
     
     $selectedtab = 0;
     $selected = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($tabId))
       $selectedtab = (int)$tabId;

     if($selectedtab === (int)$domain_tabs[$i]['tab_id']){
        $selected = 'class="selected"';
      }
      else
      {
        $selected = '';
      }
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '|</a>'.'&nbsp';
     echo '</li>';
     
        
    }
    ?>
     |</ul>
     
     </span>
     
    </td>  
  </tr> 

  

  <tr> 
    <td colspan="4" bgcolor="#00a0a0"> 
        
      <!-- display only one error message at a time -->
     <?php if(count($inputErrors) !== 0 )
              echo getInputError('name', $inputErrors); ?>
              
     <?php if(count($inputErrors) !== 0)
              echo getInputError('Date of birth', $inputErrors); ?>     
    
     <p> 
      Please Enter your name: <br />
       <input type="text" name="name"  class="introalone" 
                             value="<?php echo $name; ?>" /> <br />
       
       
      Enter your date of birth, in <em>mm/dd/yyyy</em> format: <br /> 
      <input type="text" name="dob"  class="introalone" 
                                value="<?php echo $dob; ?>"/> <br />
      
      <?php
       
        // display answer if it is set
        if(isset($ageDisplay)){
                   echo '<p style="font-size:large;">';
                   echo 'ANSWER:';
                   echo $ageDisplay;
                   echo '</p>';
        }
        
       ?>
      
      <input type="submit" name="answer" value="AGE" class="domain_ans" 
                               id="add_game" />
      
         
  
  <span class="ans_save" title="Saves your answers into your account">
  <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>">
  SAVE
  </a>
  </span> <br /><br />
  
  <span class="donate">
  <a href="<?php echo Link::Build('donate.php'); ?>">
  DONATE: PLEASE CLICK HERE TO DONATE
  </a>
  </span>
 
 
  </p>
  
  
    </td> 
  </tr> 
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();

 break;
    }
    
    case 14 :
    {
      $linkToCancelPage = (!isset($_SERVER['HTTP_REFERER']))? '' : 
                                                $_SERVER['HTTP_REFERER'];
      echo 'Welcome to Age domain, tab 2 - BIRTHDAY ';
      echo '<a href="' . $linkToCancelPage . '">' .
                      'Go Back to Previous Domain</a>';

    }
  
  /***END of Switch Case***/
  }
 
 
 




 unset($database_handler);
 
  // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>