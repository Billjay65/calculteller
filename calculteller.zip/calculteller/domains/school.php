<?php

 // start session
  session_start();
  
 // Start output buffer
 ob_start();

 // Obtaining root directory  from domains folder
 define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT2.'/include/config.php';
 
 // include error handling class php file
 require_once SITE_ROOT2.'/error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
   

 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
  // check if user is logged in and display store his name and hello message
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 
  // Variables to hold answers and description to be displayed
  $_SESSION['answer']  = '';
  $_SESSION['description'] = '';
 
 
 // Preprocessing: get query, form data string and get database data
 // Define short variables
 
  

 // create short variable names  
   $tabId   = (!isset($_REQUEST['tab_id']))? 5 : $_REQUEST['tab_id'];
  $domainId = (!isset($_GET['domain_id']))? '' : $_GET['domain_id'];   

$radioUnits = (!isset($_POST['radio_units']))? 'Abbrevation': $_POST['radio_units'];
//$radioUnits = (!isset($_POST['radio_units']))? 'Full': $_POST['radio_units'];
$unitSelected = (!isset($_POST['unitselected']))? 'unit(s)': $_POST['unitselected'];
   
 //Stores error message to be displayed if the Sum of Test and Exam Percentages 
 // is NOT 100 
 $markPercentageError ='';
 
 // get domain Id when form is submitted
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    
 // if domain ID is Not set or equals empty string, display error message
 if($domainId=='')
 {
   echo '<h2> Error: Domain Id Not Set</h2>
         <p> Please the domain Id is not set. 
          <a href="../index.php">Choose a domain here.</a>
         </p>';
   
   exit();
 }
 
 
 
  // look for starting marker
  // if not available, assume 0
  // $_GET['start'] is a GLOBAL variable to all functions in app
  (!isset($_REQUEST['start'])) ? $start = 0 : $start = $_REQUEST['start'];
 
 

/*** displays different domain options and forms based on the tab selected***/  
  switch ( $tabId )
  {
    case 5 :
    { 
    
    // Average tab selected or clicked  
 
 if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
  
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
   



 // Variables for school domain number rows of input data for average calculation
 // (Number of subjects corresponds to number of rows) for tab 1
 
  //subject_number used in loop to generate number of records to display
  $subjectNumber = (!isset($_POST['subject_number']))? DOMAIN_ROWS_NO : (int)$_POST['subject_number'];
  
  // subjectNo array to hold numbers and names subjects: number and name (STRING) for each subject
  $subjectName =  (!isset($_POST['subjectname']))? array('') : $_POST['subjectname']; 
  
  $mark = (!isset($_POST['mark']))? array('') : $_POST['mark'];
   
  $coeff = (!isset($_POST['coeff']))? array('') : $_POST['coeff']; 
 
 $productMxc = (!isset($_POST['productmxc']))? array('') : $_POST['productmxc']; 
 
 // AVERAGE VARIABLES
 // If mark or coeff is not set or subjectNumber is zero 
 // set averages to empty strings since no values are supplied
 $average20  = (!isset($_POST['average20'])
                || !isset($_POST['mark']) || !isset($_POST['coeff'])
                || $subjectNumber == 0)? 
                '' : $_POST['average20']; 
 $average100  = (!isset($_POST['average100'])
                 || !isset($_POST['mark']) || !isset($_POST['coeff'])
                 || $subjectNumber == 0)?
                  '' : $_POST['average100']; 
 

 // CALL REMOVE SPACES FUNCTION TO ELIMINATE SPACES FROM INPUT NUMERIC
   if(isset($subjectNumber) || isset($mark) || isset($coeff))
   {
     
      // remove spaces from $subjectNumber variable
      // and cast variable to int
      $subjectNumber = remove_spaces($subjectNumber);
      $subjectNumber = (int)$subjectNumber;
      
       
     for($i=0; $i<$subjectNumber; $i++)
     { 
        // try to set $mark and $coeff arrays to avoid errors 
       if(!isset($mark[$i]) ||($mark[$i]=='') )
        {
          $mark[$i] = '';
        }
        if(!isset($coeff[$i]) ||($coeff[$i]=='') )
        {
          $coeff[$i] = '';
        }   
     
        // remove spaces from $mark array 
        $mark[$i] = remove_spaces($mark[$i]);
        
        // remove spaces from $coeff array
        $coeff[$i] = remove_spaces($coeff[$i]);
  
     }
   } 



 // School totals variables and calculations

   $totalSubjects =  (!isset($_POST['totalsubjects']))? 0: $_POST['totalsubjects'];
   $totalMarks = (!isset($_POST['totalmarks']))? 0: $_POST['totalmarks'];
   $totalCoeff = (!isset($_POST['totalcoeff']))? 0: $_POST['totalcoeff'];
   $totalMxc =  (!isset($_POST['totalmxc']))? 0: $_POST['totalmxc'];
 
  // Temporary average variables 
  $_average = '';
  $_average20 = '';
  $_average100 = '';
  
   
  
  // Temporary inner variables used for total calculations
  $_totalSubjects = '';
  $_totalMarks = 0.00;
  $_totalCoeff = 0.00;
  $_totalMxc = 0.00;
  $totalMxc = 0.00;
  
  // handle addsubject button
  if(isset($_POST['addsubject']))
  {
     $subjectNumber++;
  
  }
  
  
  
 // Display of row numbers set initially
 for($i=0; $i < $subjectNumber; $i++)
 {
    // Initially, if any form input array is not set or is Empty, initialize it 
    // with and empty string to avoid Error Notices
    if(!isset($mark[$i]) ||($mark[$i]=='') )
    {
      $mark[$i] = '';
    }
    
    if(!isset($coeff[$i]) ||($coeff[$i]=='') )
    {
      // if coeff is not set, set coeff for all rows to one
      $coeff[$i] = 1;
    }
    
    
    
   
     $subjectNo[$i] = $i + 1;
      
      // Create text to display in first column G/C Name
    if(!isset($subjectName[$i]) ||($subjectName[$i]==''))
   {
      $subjectName[$i] = '';
      $subjectName[$i] = '('.$subjectNo[$i].')'.' SUBJECT ';
      
   }
     
    
     $productMxc[$i] = floatval($mark[$i]) * floatval($coeff[$i]);
   
    // calculate SUM of mark column
    $_totalMarks += floatval($mark[$i]);
   
    // calculate SUM of coeff column
    $_totalCoeff += floatval($coeff[$i]);
   
   
    // SUM of MxC column
    $_totalMxc += $productMxc[$i];
   
   
 } 
 
 
 
 // Marks total
 $totalMarks = $_totalMarks;
 $_totalMarks = ''; 
 
 // Total subjects  calculation
 $_totalSubjects = $subjectNumber;
 $totalSubjects = $_totalSubjects;
 $_totalSubjects = '';
 
 // total coeff   calculation
 $totalCoeff = $_totalCoeff;
 $_totalCoeff = '';
 
 // total M x C calculation
 $totalMxc = $_totalMxc;
 $_totalMxc = '';
 
 // AVERAGE CALCULATIONS
 
 if($totalCoeff != 0)
 {
  // verify that denomintor is greater than zero
  // Average over 100
   $_average = $totalMxc/$totalCoeff;
  
  if($_average <= 20)
  {
    $average20 = $_average;
    $_average100 = ($_average/20)*100;
    $average100 = $_average100;
    $_average100 = '';
  }
 
 // Average over 20
  if($_average > 20)
  {
    $average100 = $_average;
    $_average20 = ($_average/100)*20;
    $average20 = $_average20;
    $_average20 = '';
  }
  
  
  // Store answer and description in SESSION variables
 
  $_SESSION['answer']  = 'AVG: '. $average20 .'/20 , ' . $average100 .'/100 '; 
  $_SESSION['description']  = 'Enter Students Name: '."\n".
                          'Number of Subjects: '.$totalSubjects."\n". 
                          'AVG: '. $average20 .'/20  , '. $average100 .'/100 '."\n"; 
 
 }
  
 else
 {
  // trigger Error message
 }
 
  // handle save as file button
  // save file after all calculations have been executed
  // place this code close to form display
  if(isset($_POST['save']))
  {
    // create a csv file in user_files directory inside current
    // working directory using 
    
    // create data array of arrays
    // create headers of table file first
    $table = array( 
               array('SUBJECT', 'MARK', 'COEFFICIENT', 
                     'TOTAL(MxC)')
             );
             
    // loop over table and add rows to array
    for($i=0; $i < $subjectNumber ; $i++) 
    {
      // convert $subjectName to positive if numeric
      // not necessary here. comment out code
      /*
      if(is_numeric($subjectName[$i]))
      {
        $subjectName[$i] = abs($subjectName[$i]);
      } 
      */
      
      // for testing purposes delete 
      //echo $subjectName[$i];
      
      array_push($table, array($subjectName[$i], $mark[$i], $coeff[$i],  
                               $productMxc[$i]));
       
    }
    // add totals, average20 and average100 to table array
    array_push($table, array('No_Subjects: ' .$totalSubjects, 
                             'Total_Mks: '. $totalMarks,
                             'Total_Coeff: ' . $totalCoeff,  
                             'Total_Mxc: ' .$totalMxc .' '. $unitSelected)); 
    array_push($table, array('Average(/20): ' . $average20 .' /20 '. $unitSelected, 
                             'Average(/100): '. $average100 .' /100 ' . $unitSelected ,
                             '',  
                             ''));
                             
    // filename in user_files directory
    // the filename is the current date and time with 
    // prefix AVG that is AVG_20230109_195400
    $filename = 'user_files/AVG_' . date("Ymd_His", time()) . '.csv';
    
    try
    {
      $fp = fopen($filename, 'w');
      
      if(!$fp){
        throw new Exception('Error: File open failed.');
      }
      
      // for testing purposes delete after tests
      // echo $filename;
      // print_r($table);
      for ($j=0; $j < count($table); $j++)
      {
        fputcsv($fp, $table[$j]);
      }
      
      fclose($fp);
    }
    catch(Exception $e)
    {
      // if debugging is set to true in error_handler, the error
      // message will traceback will be displayed, else user 
      // friendly error message will be displayed
      // trigger_error is a php built-in function used with error handlers
      trigger_error($e->getMessage(), E_USER_ERROR);
       
    }
    
    // for testing purposes delete after test
    // echo 'Save as File button clicked';
    // exit();
    
    // clean output buffer before downloading file
    ob_clean();
    
    // download file
    header('Content-type: text/csv');
    header('Content-disposition:attachment; filename="'.$filename.'"');
    readfile($filename);
    
    // very important if not the whole html page is written
    // to file KEY
    // delete all echo statements and output to screen
    exit(); 
  }
 
 


    
 // display html conponents of web page
fixed_html_header('CalculTELLER: School domain Calculates averages, coefficients 
                    and positions in a few seconds',
                      'School Functions', $user_name, $member);  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();




if(!isset($_POST['me']))
{
?>

<div id="domain_content">

   <div id="answer_div" class="ans_display">
     <b>
      <?php echo 'ANS- '. $_SESSION['answer']; ?> 
    </b>
  </div> 


<table class="domain_table1"> 
<form action="<?php echo $_SERVER['PHP_SELF'].'#answer_btn'; ?>" method="post">
<input type="hidden" name="domain" value="<?php echo $domainId; ?>"> 

<input type="hidden" name="start" value="<?php echo $start; ?>">

  <tr> 
    <td id="top_domain_table" colspan="4">
    
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td colspan="4" class="tabs_dm_img"> 
    
    <span>
     <img src=<?php echo Link::Build($image_string); ?> alt="domain-image" width="150px" height="70px" />
    </span> 
    
    <span>
  
       <ul >
    
    <?php
     // display domain tabs
     
     $selectedtab = 0;
     $selected = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($tabId))
       $selectedtab = (int)$tabId;

     if($selectedtab === (int)$domain_tabs[$i]['tab_id']){
        $selected = 'class="selected"';
      }
      else
      {
        $selected = '';
      }
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '|</a>'.'&nbsp';
     echo '</li>';
     
        
    }
    ?>
     </ul>
     
     </span>
     
    </td>  
  </tr> 



  <tr> 
    <td colspan="4" bgcolor="#00a0a0">
    
    
    
    <p class="inputfields"> 
    
    SELECT TYPE OF UNITS:
    <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($radioUnits==''||$radioUnits=='Abbrevation') echo 'checked'; 
          else echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($radioUnits=='Full') echo 'checked'; 
          else echo '';  ?> > Full
     
      <br />
      <select name="unitselected"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
 
  <input type="submit" name="units" value="SET AS CURRENT" class="unit"><br /><br />
    
   <span class="donate">
  <a href="<?php echo Link::Build('donate.php'); ?>">
  DONATE
  </a>
  </span>
 
  </p>
  
  
    </td> 
  </tr> 
  
  <tr>
    <td colspan="4"><label>NUMBER of SUBJECTS</label>
      <input type="text" name="subject_number"  class="introalone"
                                  value="<?php echo $subjectNumber; ?>"> 
 
   
      <input type="submit" name="answer" value="GO!" class="domain_ans"> 
    
     <br />
  
    </td>
  </tr>  
  <tr>
      <td style="min-width: 8em;">SUBJECT</td>
      <td >MARK</td>
      <td >COEFFICIENT</td>
      <td >TOTAL(MxC)</td>
   </tr>   
 
 
 
 <!-- Display the number of rows of data specified for domain-->
<?php

 
  for($j=0; $j < $subjectNumber ; $j++) 
  {
    if($j%2!==0)
    {
     echo '<tr>';
    }
    elseif($j%2==0)
    {
      echo '<tr class="stripy_row">';
    }
    
    echo  '<td rowspan='.'"1"'.'>'. '<input type="text"'.'name="subjectname[]"'.
              'value="'.$subjectName[$j].'"'. ' </td>';
    echo  '<td>'.'<input type="text"'.'name="mark[]"'.'value="'.$mark[$j] .'">'.'</td>';
    echo  '<td>'.'<input type="text"'.'name="coeff[]"'.'value="'.$coeff[$j] .'">'.'</td>';
    echo  '<td>'.'<input type="text"'.'name="productmxc[]"'.'value="'. $productMxc[$j].'">'.'</td>';
  
    echo  '</tr>';
    
  }

    
 ?> 
 
   <tr>
      <td ><input type="text" name="totalsubjects" value="<?php echo 'No_Subjects: '. $totalSubjects ?>"></td>
      <td ><small>Total_Mks</small><input type="text" name="totalmarks" value="<?php echo $totalMarks; ?>"></td>
     
      <td ><small>Total_Coeff</small><input type="text" name="totalCoeff" value="<?php echo $totalCoeff;  ?>"></td>
      
      <td>
        <small>Total_Mxc</small><input type="text" name="totalMxc" value="<?php echo $totalMxc  ?>">
          <br />
       <span class="unit_ans_display"> 
          <?php echo $unitSelected; ?>
       </span>
      </td>
   </tr>  
  <tr>
 <td colspan="4">
 <label>AVERAGE:</label>
 <input type="text" name="average20" class="introaloneanswer"
                                 value="<?php echo htmlentities($average20); ?>"> /20 
<input type="text" name="average100" class="introaloneanswer" 
                                  value="<?php echo htmlentities($average100); ?>"> /100  
 </td>
 </tr>  
 <tr>
 <td colspan="4">
 <input type="submit" name="answer" value="AVERAGE" class="domain_ans" id="answer_btn"> 
 <span class="ans_save" title="Saves your answers into your account">
  <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>">
  SAVE
  </a>
  </span>
  <input type="submit" name="addsubject" value="ADD SUBJECT"  class="addgame"> <br />
  <input type="reset" value="Clear" id="clear_btn"  class="clear_input">
  <input type="submit" name="save" value="Save As File"  class="addgame" id="save"><br /><br /><br />
 </td>
 </tr> 
  
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();
 
 
  break;
    
    }
    
    /*CHANGE tab_id to School tab 2 - SCORE*/
    case 6 :
    {
      // score tab clicked
    
      if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
   // set default units to percentage (%) for tab 2 - Score
   $unitSelected = (!isset($_POST['unitselected']))? '%': $_POST['unitselected'];
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
   

 // Score tab of School domain short variables
 $testpercentage =  (!isset($_POST['testpercentage']))? '' : $_POST['testpercentage'];

 $exampercentage =  (!isset($_POST['exampercentage']))? '' : $_POST['exampercentage'];

 $testmark =  (!isset($_POST['testmark']))? '': $_POST['testmark'];
 
 $exammark = (!isset($_POST['exammark']))? '': $_POST['exammark'];

 $finalmark100 = (!isset($_POST['finalmark100']))? '': $_POST['finalmark100'];
 
 $finalmark20 = (!isset($_POST['finalmark20']))? '': $_POST['finalmark20'];
 
 
 $testtotal = (!isset($_POST['testtotal']))? '': $_POST['testtotal'];
 
 $examtotal = (!isset($_POST['examtotal']))? '': $_POST['examtotal'];
 
 
 // Temporary inner variables used for total calculations
  
  $_finalmark100 = '';
  $_finalmark20 = '';
  
 // define array to hold the Total Marks or Test or Exam
 // range(1,100) creates and arry with values from 1 to 80
 $arr = range(1, 100);   
    

  // CALL REMOVE SPACES FUNCTION TO ELIMINATE SPACES FROM INPUT NUMERIC
   if(($testmark!=='') || ($exammark!==''))
   {
     
     // remove spaces from $investment variable
      $testmark = remove_spaces($testmark);
      
     // remove spaces from $income variable
      $exammark = remove_spaces($exammark);
        
   }   

 
// Test if ANSWER submit button has been clicked and execute code  
if(isset($_POST['answer']))
{
?>

<?php


  // FINAL MARK CALCULATIONS Sum of Test and Exam percentages must be 100
 
 if(($testpercentage + $exampercentage) == 100)
 {

   // Temporary inner variables used for (final mark) total calculations
   $_finalmark100 = ((($testmark * $testpercentage)/$testtotal) +
                      (($exammark * $exampercentage)/$examtotal));
                      
  
   //final mark over 20 and over 100
    $_finalmark20 = (($_finalmark100/100)*20);
    
    $finalmark20 = $_finalmark20;
    
    $finalmark100 = $_finalmark100;
    
    $_finalmark100 = '';
    
    $_finalmark20 = '';
    
     // Store answer and description in SESSION variables
 
  $_SESSION['answer']  = 'FINAL MK: '. $finalmark20 .'/20 , ' . $finalmark100 .'/100 '; 
  $_SESSION['description']  = 'If TEST(CA) MARK equals '. $testmark . 
                              ' AND EXAM MARK equals '. $exammark .
                          ' therefore FINAL MARK equals '. 
                           $finalmark20 .'/20  , '. $finalmark100 .'/100 '. '.';
 
 }
 else
 {
  // create Error message and store in a variable if sum is Not 100
  $markPercentageError = 'Error: The sum of the Test percentage and Exam percentage
                          Must be equal to 100. Please enter correct values and try again!';
 }

  
  
 ?>
 
<?php
}

    
 fixed_html_header('CalculTELLER: School domain Calculates averages, coefficients 
                    and positions in a few seconds',
                      'School Functions', $user_name ); 


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();






if(!isset($_POST['me']))
{
?>

<div id="domain_content">

   <div id="answer_div" class="ans_display">
     <b>
      <?php echo 'ANSWER- '. $_SESSION['answer']; ?> 
    </b>
  </div> 


<table class="domain_table1">
<form action="<?php echo $_SERVER['PHP_SELF'].'#answer_btn'; ?>" method="post">
<input type="hidden" name="domain" value="<?php echo $domainId; ?>">

<input type="hidden" name="tab_id" value="<?php echo $tabId; ?>">  

   <tr> 
    <td id="top_domain_table" colspan="3">
    
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td colspan="4" class="tabs_dm_img"> 
    
    <span>
      <img src=<?php echo Link::Build($image_string); ?> alt="domain-image" />
    </span> 
    
    <span> 
  
       <ul >
    
    <?php
     // display domain tabs
     
     $selectedtab = 0;
     $selected = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($tabId))
       $selectedtab = (int)$tabId;

     if($selectedtab === (int)$domain_tabs[$i]['tab_id']){
        $selected = 'class="selected"';
      }
      else
      {
        $selected = '';
      }
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '|</a>'.'&nbsp';
     echo '</li>';
     
        
    }
    ?>
     </ul>
     
     </span>
     
    </td>  
  </tr> 



  <tr> 
    <td colspan="4" bgcolor="#00a0a0">
    
    
    
    <p class="inputfields"> 
    
    SELECT TYPE OF UNITS:
    <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($radioUnits==''||$radioUnits=='Abbrevation') echo 'checked'; 
          else echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($radioUnits=='Full') echo 'checked'; 
          else echo '';  ?> > Full
     
      <br />
      <select name="unitselected"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
    
     <!--Error display paragraph for test and exam percentage-->
     <p class="error">
       <?php if($markPercentageError!=='') 
                   echo  $markPercentageError; ?>
     </p>
 
     <input type="submit" name="units" value="GO!" class="unit"> <br />
     
      <span>TEST(CA) Percentage </span> 
         <select name="testpercentage"> 
    <?php
    
    // Display select list for number of years of investment
  
    // Number of years/months range from 1 to 80
  
     for($i=0; $i < sizeof($arr); $i++)
     {
       echo   '<option value="'.$arr[$i].'"';
               if($arr[$i] == $testpercentage)
                echo 'selected';
               elseif($arr[$i] == 30 && $testpercentage=='')
                echo 'selected';
       echo   ' >';
      
      
         echo     $arr[$i]; 
       
     
       echo   '</option>' ;
    }
    ?>
    </select> 
        <span>% </span>
        
      <span>EXAM Percentage </span> 
           <select name="exampercentage"> 
    <?php
    
    // Display select list for number of years of investment
  
    // Number of years/months range from 1 to 80
  
     for($i=0; $i < sizeof($arr); $i++)
     {
       echo   '<option value="'.$arr[$i].'"';
               if($arr[$i] == $exampercentage)
                echo 'selected';
               elseif($arr[$i] == 70 && $exampercentage=='')
                echo 'selected';
       echo   ' >';
      
      
         echo     $arr[$i]; 
       
     
       echo   '</option>' ;
    }
    ?>
          </select>
         
                          
        <span>% </span>
        
        
        <br />
      
      <span>IF TEST(CA) MARK EQUALS</span> 
        <input type="text" name="testmark" value="<?php echo  $testmark;?>"> 
         <span> / </span> 
         <select name="testtotal"> 
    <?php
    
    // Display testtotal range from 1 to 100
  
     for($i=0; $i < sizeof($arr); $i++)
     {
       echo   '<option value="'.$arr[$i].'"';
               if($arr[$i] == $testtotal)
                echo 'selected';
               elseif($arr[$i] == 30 && $testtotal=='')
                echo 'selected';
       echo   ' >';
      
      
         echo     $arr[$i]; 
       
     
       echo   '</option>' ;
    }
    ?>
    </select> 
    
    
    <br />
    
     
    <span>AND EXAM MARK EQUALS</span> 
     <input type="text" name="exammark" value="<?php echo  $exammark;?>"> 
        <span> / </span> 
         <select name="examtotal"> 
    <?php
    
    // Display select list for number of years of investment
  
    // Number of years/months range from 1 to 80
  
     for($i=0; $i < sizeof($arr); $i++)
     {
       echo   '<option value="'.$arr[$i].'"';
               if($arr[$i] == $examtotal)
                echo 'selected';
               elseif($arr[$i] == 70 && $examtotal=='')
                echo 'selected';
       echo   ' >';
      
      
         echo     $arr[$i]; 
       
     
       echo   '</option>' ;
    }
    ?>
    </select> 
    
   
   <br />
    
                          
    <span>THEREFORE FINAL MARK EQUALS</span> 
      <input type="text" name="finalmark100" class="unit_ans_display"
                                  value="<?php echo $finalmark100; ?>"> /100 
      <input type="text" name="finalmark20" class="unit_ans_display" 
                                   value="<?php echo $finalmark20; ?>"> /20  
      
   
     
  <input type="submit" name="answer" value="FINAL MARK" id="answer_btn" class="domain_ans">
  
  <span class="ans_save" title="Saves your answers into your account">
    <a href="<?php echo Link::Build('myaccount.php?page=2'); ?>">
     SAVE
    </a>
  </span> <br /><br />
  
  <input type="reset" value="Clear" id="clear_btn"  class="clear_input">
  <span class="donate">
  <a href="<?php echo Link::Build('donate.php'); ?>">
  DONATE
  </a>
  </span>
 
  </p>
  
  
    </td> 
  </tr> 
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();
 
    break;
    
    /*
      echo 'Welcome to School domain, tab 2 - SCORE';
      echo '<a href="school.php?tab_id=5&domain_id=7">
                      Go Back to Previous Domain</a>';
      // display form for balance tab 2   
          break;
    */
    }
  
  /***END of Switch Case***/
  }
 
 
 




 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();

?>