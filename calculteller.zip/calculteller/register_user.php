
<?php

// Start session and read username from session variable if it is set
 session_start(); 

// include config file containing directory paths
 require_once 'include/config.php';
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
   // Get web browser language of User 
// get first value(Primary Language) from language array
 $browserLanguage = $_SERVER['HTTP_ACCEPT_LANGUAGE'][0] 
                      . $_SERVER['HTTP_ACCEPT_LANGUAGE'][1];
                      
  // Get selected language of page default is en
  // include language configuration file based on selected language
	$language = "en";
                      
  // Create session variable to store selected language
  if(isset($_SESSION['language'])){
     $userLanguage = $_SESSION['language'];
     $language     = $userLanguage; 
  }
  else{
     $userLanguage = ''; 
  }
 
 

  
  // read browser language Only when user language SESSION variable
  // is NOT SET(equals ''), if userLanguage is set, do not use browser language
  if((!empty($browserLanguage)) && ($browserLanguage == 'en' ||
       $browserLanguage == 'fr' || $browserLanguage == 'es'
       || $browserLanguage == 'zh')
      && ($userLanguage =='')){
    $language = $browserLanguage;
      
  }
  
	if(isset($_GET['lang'])){ 
		$language = $_GET['lang'];
    $_SESSION['language'] = $language;
     
	} 
   
  // get language file based on user's language
	require_once(SITE_ROOT."/values/".$language.".php");



    // display input validation error 
    function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        return "<div class=\"error\">ERROR: Invalid data for field '$key'</div>"; 
      } else { 
        return false; 
      } 
    } 
    
    
   $editMode = 0;
   $errorFlag = 0;
   //$errorHeader = 'ERROR: Form filled incorrectly, Please correct error';
   $errorHeader = '';
  
 /* 
  $nameError = 0;
  $emailAlreadyTaken = 0;
  $emailError = 0;
  $passwordError = 0;
  $passwordConfirmError = 0;
  $passwordMatchError = 0;
  */
  $linkToAccountDetails;
  $linkToCancelPage = Link::Build('index.php');
  
  

  // header('Location:'.$mLinkToCancelPage);
 
    $inputErrors = array(); 
    $submitted = false; 
    
    
 
 
    // if form submitted 
    // validate form input 
if (isset($_POST['submit'])) 
{ 
      
      $submitted = true; 
      $valid = array(); 
      $_username = '';
      $_email = '';
      
 
      // validate user name 
      if (!empty($_POST['name']) && (strlen($_POST['name']) >= 2  && strlen($_POST['name']) < 50)) { 
        $valid['name'] = htmlentities(trim($_POST['name']));  
      } else { 
        $inputErrors[] = 'name'; 
        $errorFlag = 1; 
      } 
      
    
  
      
       // validate username atmost 14 characters 
      if (!empty($_POST['username']) && preg_match('/^([a-zA-Z0-9_]){2,20}$/', $_POST['username'])) { 
        $_username = htmlentities(trim($_POST['username'])); 
       
         // Check if username is unique
         // create and execute SELECT query 
        $sql = "SELECT COUNT(*) FROM user
                WHERE username = '$_username'"; 

        $row1 = getOne($sql, $params=NULL);
 
   
         if($row1[0]== 0)
         {
            $valid['username'] = htmlentities(trim($_POST['username']));
         }
         else
         {
          $inputErrors[] = 'Username-Already taken';
          $errorFlag = 2; 
         
         }
        
        
          
      } 
      else { 
        $inputErrors[] = 'Username';
        $errorFlag = 2; 
      } 
      
      // validate user email 
      if (!empty($_POST['email']) && preg_match('/^([a-z0-9_-])+([\.a-z0-9_-])*@([a-z0-9-])+(\ 
       .[a-z0-9-]+)*\.([a-z]{2,6})$/', $_POST['email'])) { 
       
         $_email = htmlentities(trim($_POST['email']));
       
        // Check if email is unique
         // create and execute SELECT query 
        $sql = "SELECT COUNT(*) FROM user
                WHERE email = '$_email'"; 

        $row1 = getOne($sql, $params=NULL);
 
 
         if($row1[0]== 0)
         {
            $valid['email'] = htmlentities(trim($_POST['email']));
            
         }
         else
         {
          $inputErrors[] = 'email-Already used';
          $errorFlag = 3; 
         
         }
       
      } else { 
        $inputErrors[] = 'email';
        $errorFlag = 3; 
      } 
 
      // validate user password Must start with Capital letter atleast 4 characters long
      // passord can accept any character in utf-8 or ansi
      if (!empty($_POST['password']) && preg_match('/^([A-Z])+(.){3,16}$/', $_POST['password']))  { 
        $valid['password'] = htmlentities(trim($_POST['password'])); 
      } else { 
        $inputErrors[] = 'password';
        $errorFlag = 4; 
      } 
      // validate user password Must start with Capital letter atleast 4 characters long
      if (!empty($_POST['passwordconfirm']) && preg_match('/^([A-Z])+(.){3,16}$/', $_POST['passwordconfirm']))  { 
        $valid['passwordconfirm'] = htmlentities(trim($_POST['passwordconfirm'])); 
      } else { 
        $inputErrors[] = 'password confirm'; 
        $errorFlag = 5;
      } 
      
      // validate telephone number
      // first replace any space, or _- with empty string use str_replace()
      // from phone number before testing
      
      if(!empty($_POST['phone'])){
           
           // first initialize $phoneCleaned to empty variable before
           // cleaning the string
            $phoneCleaned = '';
            $phoneCleanedInt = '';
            
            $phoneCleaned = (string)($_POST['phone']);
            $phoneCleaned = str_replace('+', '', $phoneCleaned);
            $phoneCleaned = str_replace(' ', '', $phoneCleaned);
            $phoneCleaned = str_replace('-', '', $phoneCleaned);
    
            $phoneCleanedInt = $phoneCleaned;
            $phoneCleaned = '';
            
          
      }
            
            
            
                 
      // save cleaned phone number into database not the number posted by user
      if (!empty($phoneCleanedInt) 
                    && is_numeric($phoneCleanedInt) 
                     && preg_match('/^([0-9]){4,16}$/', ($phoneCleanedInt))) 
      { 
        $valid['phone'] = htmlentities(trim($phoneCleanedInt)); 
        
        //echo $valid['phone'];
      } else { 
        $inputErrors[] = 'Telephone';
        $errorFlag = 6; 
      } 
      
       // validate user address 
      if (!empty($_POST['address']) 
          && preg_match('/^([a-zA-Z0-9\-_])([a-zA-Z0-9\-_\s]*){2,50}$/', $_POST['address'])) { 
        $valid['address'] = htmlentities(trim($_POST['address'])); 
      } else { 
        $inputErrors[] = 'Address';
        $errorFlag = 7; 
      } 
      
      // validate user city 
       if (!empty($_POST['city']) 
           && preg_match('/^([a-zA-Z0-9\-_])([a-zA-Z0-9\-_\s]*){2,50}$/', $_POST['city']))  { 
        $valid['city'] = htmlentities(trim($_POST['city'])); 
      } else { 
        $inputErrors[] = 'City';
        $errorFlag = 8; 
      }    
       // validate user region 
      if (!empty($_POST['region']) 
          && preg_match('/^([a-zA-Z0-9\-_][a-zA-Z0-9\-_\s]*){2,50}$/', $_POST['region'])) { 
        $valid['region'] = htmlentities(trim($_POST['region'])); 
      } else { 
        $inputErrors[] = 'Region';
        $errorFlag = 9; 
      }    
      // validate user country 
      if (!empty($_POST['country'])) { 
        $valid['country'] = htmlentities(trim($_POST['country'])); 
      } else { 
        $inputErrors[] = 'Country';
        $errorFlag = 10; 
      }  
      
      // Validate user password
      if (isset($valid['passwordconfirm']) && isset($valid['password']))
      {
        if  ($valid['passwordconfirm'] == $valid['password'])
        { 
          $valid['password'] = htmlentities(trim($_POST['password'])); 
        } else { 
        $inputErrors[] = 'Passwords Different'; 
        $errorFlag = 11;
        } 
      }
    
      
        $valid['date'] = date("Y-m-d H:i:s", time());
        
        
        // Validate Variables for MLM subscribers table
        
        //Validate mimetype 
        if (!empty($_POST['mimetype'])) { 
          $valid['mimetype'] = htmlentities(trim($_POST['mimetype'])); 
        } 
        
        //Validate code 
        if (!empty($_POST['code']) && (is_numeric($_POST['code']))) { 
         $valid['code'] = htmlentities(trim($_POST['code'])); 
        } 
        
        
      
      if($errorFlag > 0)
      $errorHeader = 'ERROR: Form filled incorrectly, Please correct errors!';
      
/* 
// Uncomment this to add user to DB for real
// Comment when testing input validation and client error messages     
 if(($errorFlag == 0) || count($inputErrors) == 0)
 {    
  // sanitize data and insert into database including date
  $name = addslashes($valid['name']);
  $username = addslashes($valid['username']);
  $password = addslashes($valid['password']);
  $email = addslashes($valid['email']);
  $address = addslashes($valid['address']);
  $city = addslashes($valid['city']);
  $region = addslashes($valid['region']);
  $country = addslashes($valid['country']);
  $phone = addslashes($valid['phone']);
  $date = addslashes($valid['date']);
  //print_r($valid);
 } 
 */  
               
} 
 
    // if form not submitted 
    // or if validation errors exist 
    // (re)display form 
if (($submitted == true && count($inputErrors) > 0) || $submitted == false) 
{ 

  // get list of countries 
     $query = "SELECT city_id, country FROM city";
    $result = getAll($query, $params = null);
    
    // variable containing list of countries
    $countries = $result;
   
     $successHeader = false;
    


  do_html_header2($lang['register_title'], $lang['register_heading'], 
                  $errorHeader, $successHeader); 
  if(isset($_SESSION['name']) && ($_SESSION['name']!='' ))
  {
     echo '<h2>'.'Registration Successful!' .'</h2>';
     echo '<span style="font-size: 170%;">'.'Hi '.'</span>'.'<span class="success">'.$_SESSION['name']. '<br />'.
          'Click '.'<a href="'. $linkToCancelPage.'">'.' HERE to START'.'</a>'.'</span>' ;
  }
  
 

 ?>
 
 
                   
  
  <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="signup_form">
  <h3><?php if(isset($lang['register_form_title']))
               echo $lang['register_form_title'];
           else 
              echo 'Please enter your details: Registration'; ?></h3>
  <table class="user-table">
  
     <tr>
      <td> <?php if(isset($lang['name'] ))
               echo $lang['name'] ;
           else 
              echo 'Name:'; ?>   </td>
      <td>
        <input type="text" name="name"  
        value="<?php echo isset($_POST['name']) ? $_POST['name'] : '';?>" 
        size="40" maxlength="50"/>
        <?php echo getInputError('name', $inputErrors); ?> 
      </td> 
      <td><em><small>*Atmost 50 characters</small></em></td>
    </tr>
    <tr>
      <td> <?php if(isset($lang['username']))
               echo $lang['username'];
           else 
              echo 'Username:'; ?>   </td>
      <td>
        <input type="text" name="username"  
        value="<?php echo isset($_POST['username']) ? $_POST['username'] : '';?>" 
        size="32" maxlength="20" />
        <?php echo getInputError('Username', $inputErrors); ?> 
        <?php echo getInputError('Username-Already taken', $inputErrors); ?> 
      </td>
      <td><em><small>*Atmost 20 characters</small></em></td>
    </tr>
     <tr>
      <td><?php if(isset($lang['email']))
               echo $lang['email'];
           else 
              echo 'E-mail Address:'; ?> </td> 
      <td>
      <input type="email" name="email"  maxlength="100"
        value="<?php echo isset($_POST['email']) ? $_POST['email'] : '';?>" 
        <?php if($editMode="readonly") echo 'size="40"';?> /> 
        <?php echo getInputError('email-Already used', $inputErrors); ?> 
        
      <?php echo getInputError('email', $inputErrors); ?> 
      </td>
      <td><em><small>*Required </small></em></td>
    </tr>
    
     <tr>
      <td><?php if(isset($lang['password']))
               echo $lang['password'];
           else 
              echo 'Password:'; ?>  </td>
      <td>
        <input type="password" name="password" size="40" maxlength="40"
         value="<?php echo isset($_POST['password']) ? $_POST['password'] : '';?>" />
        <?php echo getInputError('password', $inputErrors); ?> 
        <?php echo getInputError('Passwords Different', $inputErrors); ?> 
         
      </td>
      <td><em><small>*Must start with a Capital Letter</small></em></td>
    </tr>
    <tr>
      <td><?php if(isset($lang['password_confirm']))
               echo $lang['password_confirm'];
           else 
              echo 'Re-enter Password:'; ?> </td>
      <td>
        <input type="password" name="passwordconfirm" size="40" maxlength="40"
         value="<?php echo isset($_POST['passwordconfirm']) ? $_POST['passwordconfirm'] : '';?>"/>
        <?php echo getInputError('password confirm', $inputErrors); ?>
        
      </td>
      <td><em><small>*Must start with a Capital Letter<small></em></td>
    </tr>
    <tr>
      <td><?php if(isset($lang['address']))
               echo $lang['address'];
           else 
              echo 'Address:'; ?></td>
      <td>
        <input type="text" name="address"  value="<?php echo isset($_POST['address']) ? $_POST['address'] : '';?>"
          <?php if($editMode) echo 'size="32"';?> maxlength="50" />
        <?php echo getInputError('Address', $inputErrors); ?>     
        
      </td>
      <td><em><small>*Atmost 50 character</small></em></td>
    </tr>
    <tr>
      <td><?php if(isset($lang['city']))
               echo $lang['city'];
           else 
              echo 'City:'; ?></td>
      <td>
        <input type="text" name="city"  value="<?php echo isset($_POST['city']) ? $_POST['city'] : '';?>"
          <?php if($editMode) echo 'size="32"';?>  maxlength="50" />
        <?php echo getInputError('City', $inputErrors); ?>     
        
      </td>
      <td><em><small>*Atmost 50 character</small></em></td>
    </tr>
    
    <tr>
      <td><?php if(isset($lang['region']))
               echo $lang['region'];
           else 
              echo 'Region:'; ?></td>
      <td>
        <input type="text" name="region"  value="<?php echo isset($_POST['region']) ? $_POST['region'] : '';?>"
          <?php if($editMode) echo 'size="32"';?> maxlength="50" />
        <?php echo getInputError('Region', $inputErrors); ?>     
        
      </td>
      <td><em><small>*Atmost 50 character</small></em></td>
    </tr>
    
    
    <tr>
      <td><?php if(isset($lang['telephone']))
               echo $lang['telephone'];
           else 
              echo 'Telephone:'; ?> </td>
      <td>
        <input type="text" name="phone"  value="<?php echo isset($_POST['phone']) ? $_POST['phone'] : '';?>"
          <?php if($editMode) echo 'size="32"';?> maxlength="50" />
        <?php echo getInputError('Telephone', $inputErrors); ?>
          
        
      </td>
      <td><em><small>* e.g 111 222 11111</small></em></td>
    </tr>
    <tr>
      <td> <?php if(isset($lang['country']))
                echo $lang['country'];
             else 
              echo 'Country:'; ?> </td>
      <td>
        <select name="country"> 
    <?php
    
    // Display a timezone select element with different timezones as options
  
     for($i=0; $i < sizeof($countries); $i++)
     {
       echo   '<option value="'.$countries[$i]['country'].'"';
               if($countries[$i]['country'] == 'United States')
                echo 'selected';
       echo   ' >';
      
      
         echo     $countries[$i]['country']; 
       
     
       echo   '</option>' ;
    }
    ?>
    </select>
        <?php echo getInputError('Country', $inputErrors); ?>
          
        
      </td>
    </tr>
    
    
      
  <tr>
    <td>
       <input type="submit" name="submit" 
         value="<?php if(isset($lang['signup_btn']))
                         echo $lang['signup_btn'];
                      else 
                          echo 'Log In'; ?> "  /> |
                          
   <a href="<?php  echo $linkToCancelPage; ?>">
     <?php if(isset($lang['cancel_btn'] ))
              echo $lang['cancel_btn'] ;
           else 
              echo 'Cancel'; ?> </a>
    </td>
 </tr>
 </table>
 
 <!--HIDDEN fields used for MLM subscribers tables-->
 
     <!--Hidden input field for mime type -->
     <input type="hidden" name="mimetype"  value="H" /> 
      
     
      <!--Hidden input field for email verification -->
     <input type="hidden" name="code"  
        value="<?php 
                    echo rand(3000000, 5000000);
                ?>" /> 
    
  </form> 
  


<?php 

do_html_footer($lang); 
  // if form submitted with no errors 
  // write the input to the database 
} 

else 
{ 
    $submitted = true; 
   
  // sanitize data and insert into database including date
  $name = addslashes($valid['name']);
  $username = addslashes($valid['username']);
  $password = addslashes($valid['password']);
  $email = addslashes($valid['email']);
  $address = addslashes($valid['address']);
  $city = addslashes($valid['city']);
  $region = addslashes($valid['region']);
  $country = addslashes($valid['country']);
  $phone = addslashes($valid['phone']);
  $date = addslashes($valid['date']);
  $password = PasswordHasher::Hash($password, true);
 
  // MLM subscribers data: sanitize and insert into database
   $realname = addslashes($valid['name']);
   $mimetype = addslashes($valid['mimetype']);
   $admin = (int) 0;
   $language = (int) 1;
   $code = addslashes($valid['code']);
   $verified = (int) 0;       
   $password_sub = addslashes($valid['password']);
   
 
  // Insert data into database: user table 
  // Build the SQL query
  
    $sql = "INSERT INTO user (name, username, password, email, address, 
                             city, region, country, phone, lvisit) 
            VALUES ('$name', '$username', '$password', '$email',
                   '$address', '$city', '$region', '$country', '$phone', '$date')";

    // Execute the query
     $lastInsertId1 = executeQuery($sql, $params = null);
    
 unset($database_handler); 
 
 
 
    // Check if subscriber with $email exist
    // create and execute SELECT query 
        $sql = "SELECT COUNT(*) from subscribers
                         where email = '$email'";
                        

        $row1 = getOne($sql, $params=NULL);
 
   
         if($row1[0]== 0)
         {
           // if  $email is valid and does not exist, proceed to add user
           // to subscribers table
           
           
            // Insert data into CT database: MLM subscribers table 
            // Build the SQL query
  
             $sql = "insert into subscribers (email, realname, mimetype,
                                password, admin, language, code, verified)
                 values ('$email',
                         '$realname',
                         '$mimetype',
                         sha1('$password_sub'),
                         $admin,
                         $language,
                         $code,
                         $verified)";

               // Execute the query
               $lastInsertId2 = executeQuery($sql, $params = null); 
               
                // if data is stored in subscribers table, then send email
                if ($lastInsertId2 > 0)
                {
                  // send code to subscriber by mail
            
                  $to = $email;
                  $subject = 'Email Verification';
                  $email= 'info@calculteller.com';
                  $name = $realname;
                  $code = $code;

                 $mailcontent = 'CalculTELLER: '.'Hi'.$name."\n"
                              .'From: '.$email."\n"
                              .'Subject '.$subject."\n\r"
                              ."Message:"."\n"
                              .'Thank you for subscribing to CalculTELLER\'S 
                                 Mailing Lists. Please verify your email address
                                 to activate your account. Your verification code
                                 is'."\t".$code."\t".'Click on this link http://
                                 calculteller.com/mlm, copy and paste the 
                                 code in the space provided and click Verify'
                              ."\n";
                    /*                  
                   if(mail($to, $subject, $mailcontent))
                   {
                       // prepare success message variable to display
                       return true;
                   }
                   else
                   {
                     // display error message
                     // if email already taken (invalid) prepare error message to be displayed
                    $inputErrors[] = 'Error: Unable to register your account. Please try again!.';
                    $errorFlag = 1;
                   }
                   */  
                  return true;
                }
                
                else
                {
                   // if user data not stored into subscribers table
                   $inputErrors[] = 'Error: Unable to register your account. Please try again!.';
                   $errorFlag = 1; 
          
                }      
           
         }
            
         else
         {
           // if email already taken (invalid) prepare error message to be displayed
           $inputErrors[] = 'Email already exist! please change email.';
           $errorFlag = 1; 
           
           // DELETE this after testing subscriber code
           // exit();
         }                     
    
  
 
    
 unset($database_handler); 
  
 
 
 // register session variables
 $_SESSION['name'] = $name;
 $_SESSION['username'] = $username;
 $_SESSION['email'] = $email;
 
 // SET cookies
 $app_name = 'CalculTELLER';
 $ret1 = (isset($username)) ? setcookie('username', $username, 
           time() + 172800, '/') : null;
 $ret2 = (isset($app_name)) ? setcookie('app_name', $app_name, 
           time() + 172800, '/') : null;

/*
// read cookie and assign cookie values 
// to PHP variables 
$username = isset($_COOKIE['username']) ? $_COOKIE['username'] : ''; 
$app_name = isset($_COOKIE['$app_name']) ? $_COOKIE['$app_name'] : '';

*/
  // Redirect user to index if registration is successful
 header('Location:'.$linkToCancelPage);
 exit();
} 


 
?> 
