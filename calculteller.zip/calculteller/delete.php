<?php
// include config file containing directory paths
 require_once 'include/config.php';
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 // start session, authenticate user....
 session_start();
 
  $userName = (!isset($_SESSION['username']))? '' : $_SESSION['username'] ;
  
  
  // Variable to hold admin username
  $userName = (!isset($_SESSION['name']))? '' : $_SESSION['name'] ;
  
  
  $user_name = (!isset($_SESSION['name']))? '' : $_SESSION['name'] ;
  
  // get data Id to be deleted 
   $deleteId  = (!isset($_GET['deleteId']))? NULL : $_GET['deleteId'];
 
  if(!isset($_SESSION['username']) || $_SESSION['username']=='' || !isset($deleteId))
 {
 
  fixed_html_header('CalculTELLER: Balance domain calculates 
                    your change in less than a second',
                      'Balance (Change) Functions', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Missing record ID! or You are not logged in! 
                Please login to gain FULL ACCESS to all functions</h2></center>';
 echo '<p class="login_advice">';
 echo  'After you log in, you can  SAVE and DELETE your answers and information
              and retrieve them anywhere in the world and at any time of the day.
              Thank You!';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('login.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
 }
 
// check for record ID
if ((isset($deleteId) &&!empty($deleteId)) && (isset($userName) &&!empty($userName))) 
{ 
   // Build the SQL query to delete record
   // generate and execute query
  
   $query = "DELETE FROM user_data WHERE data_id = '$deleteId'";
                 
                 
     $lastDeleteId = executeQuery($query, $params = null);
    
    
     // ADMIN DELETE REDIRECT: Redirect admin to admin/user_data.php page
     if($userName == 'ADMIN' || $userName == '')
     {
        $linkToAdminUserDataTab = Link::Build('admin/user_data.php');
    
        header('Location:'.$linkToAdminUserDataTab);
      }
      else
      {
        
         // Redirect user to myaccount if registration is successful
         $linkToMyAccount = Link::Build('myaccount.php');
    
          header('Location:'.$linkToMyAccount);
      }
     
     fixed_html_header('CalculTELLER: Balance domain calculates 
                    your change in less than a second',
                      'Balance (Change) Functions', $user_name);
  fixed_html_sidebar();
  display_domains_list();
  fixed_html_content();

  // display login advice to user
  
  echo  '<center><h2>Record Deleted Successfully!</h2></center>';
  echo '<p class="login_advice">';
  echo  '<span style="float:center;">'.'<b>'.'<a href="'.
         Link::Build('myaccount.php').'">'.'Go Back to My Account '.'</a>'.'</b>'.'</span>' ;;
  echo '</p>';
  echo '<center>';
  echo '<span style="float:center;">'.'<b>'.'<a href="'.
         Link::Build('index.php').'">'.' Go to Home Page'.'</a>'.'</b>'.'</span>' ;
  echo '</center>';
  //display_domain_image_links();
  fixed_html_ads();
  fixed_html_footer();
  unset($database_handler);
 
 
 exit(); 
}



?>