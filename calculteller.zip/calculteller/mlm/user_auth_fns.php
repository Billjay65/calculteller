<?php

function check_verified_user($email)
{
  // if user has logged in or registered
  // check if user is verified before displaying
  // buttons and options
  // connect to db
  $conn =  db_connect();
  

  // compare user code submitted with that in database
  // create and execute SELECT query 
        $sql = "SELECT COUNT(*) from subscribers
                         where email = '$email'
                         AND verified = 1"; 
                         
    $statement_handler = $conn->query($sql);
    
    if(!$statement_handler)
      return false;
    
   // Fetch result
   $result = $statement_handler->fetch(PDO::FETCH_NUM);
    
   // Save the first value of the result set to $result    
   $row = $result[0];
  
   // if the codes match for the unique user, insert 1 into
   // verified field of subscribers table
   if($row == 1)
   {
         return true;
   
   }
   else
   {
     return false;
   
   }
  

}


function verify_user($email, $code)
// verify the user using the code he submits
//if the code is correct, insert 1 in verified field in dB
{

  // connect to db
  $conn =  db_connect();
  

  // compare user code submitted with that in database
  // create and execute SELECT query 
        $sql = "SELECT COUNT(*) from subscribers
                         where email = '$email'
                         AND code = '$code'"; 
                         
    $statement_handler = $conn->query($sql);
    
    if(!$statement_handler)
      return false;
    
   // Fetch result
   $result = $statement_handler->fetch(PDO::FETCH_NUM);
    
   // Save the first value of the result set to $result    
   $row = $result[0];
  
   // if the codes match for the unique user, insert 1 into
   // verified field of subscribers table
   if($row == 1)
   {
       // update subscribers table insert 1 into verified field 
       // create and execute SELECT query 
         $query = "update subscribers
                   set verified = 1
                   where email = '$email'";
               
      $result = $conn->query($query);
      
      if($result)
         return true;
   
   }
   else
   {
     // return false
     return false;
   
   }
  
 
}



function check_normal_user()
// see if somebody is logged in and notify them if not
{
  if (isset($_SESSION['normal_user']))
    return true;
  else
    return false;
}

function check_admin_user()
// see if somebody is logged in and notify them if not
{
  if (isset($_SESSION['admin_user']))
    return true;
  else
    return false;
}


function check_logged_in()
{
  return (check_normal_user() || check_admin_user() );
}




function login($email, $password)
// check username and password with db
// if yes, check and return login type
//else return false
{

  //sanitize  $email and $password
   addslashes($email);

  //sanitize  $email and $password
   addslashes($password);
  
  // connect to db
  $conn =  db_connect();
  

  // Check if unique user record  record exist with given criteria
  // create and execute SELECT query 
        $sql = "SELECT COUNT(*) from subscribers
                         where email = '$email'
                         and password = sha1('$password')"; 
                         
    $statement_handler = $conn->query($sql);
    
    if(!$statement_handler)
      return false;
    
   // Fetch result
   $result = $statement_handler->fetch(PDO::FETCH_NUM);
    
   // Save the first value of the result set to $result    
   $row = $result[0];
  
  if($row < 1)
    return false;
  
  
  
  if($row ==1)
  {
    // if record found i.e user exist, execute query to determine type of user
   $query = "select admin from subscribers
                         where email = '$email'
                         and password = sha1('$password')";

   $statement_handler = $conn->query($query);
  
    if(!$statement_handler)
       return false;
    
    // Fetch result
    $result = $statement_handler->fetch(PDO::FETCH_NUM);
    
    //Save the first value of the result set to $result    
    $rowUser = $result[0];
 
   if($rowUser[0] == 1)
      return 'admin';
   else
    return 'normal';
  }
}


// get the email of the user from database
function get_email()
{
  if (isset($_SESSION['normal_user']))
    return $_SESSION['normal_user'];
  if (isset($_SESSION['admin_user']))
    return $_SESSION['admin_user'];

  return false;
}




function change_password($email, $old_password, $new_password,
                         $new_password_conf)
// change password for email/old_password to new_password
// return true or false
{
  // if the old password is right
  // change their password to new_password and return true
  // else return false
  if (login($email, $old_password))
  {
    if($new_password==$new_password_conf)
    {
      if(!($conn = db_connect()))
        return false;
        
      $query = "update subscribers
               set password = sha1('$new_password')
               where email = '$email'";
               
      $result = $conn->query($query);
      
      return $result;
    }
    else
      echo '<p> Your passwords do not match. </p>';
  }
  else 
    echo '<p> Your old password is incorrect. </p>';
  
 return false; // old password was wrong
}


?>











