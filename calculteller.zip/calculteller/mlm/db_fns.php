<?php

// Functions providing generic data access functionality
function db_connect()
{
 
  // attempt a connection 
  try { 
     $pdo = new PDO('mysql:dbname=calculteller;host=localhost', 'root', 'Sikehjaphetberyuf12'); 
  } 
  catch (PDOException $e) { 
     die("ERROR: Could not connect: " . $e->getMessage()); 
  }
  
  return $pdo;
}



?>
 