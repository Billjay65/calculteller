
<?php


// set for 600x800 screen
$table_width = '780';


function do_html_header($title = '')
{
  // print an HTML header

  global $table_width;

  //draw title bar  
?>
   <!-- display header with application name and description of page or action-->
  
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
   
  <html>
  <head>
    <title><?php echo $title?></title>
    
      <meta charset="UTF-8" />  
   <link  type="image/png"  rel="icon"  href="../images/mlm-logo.png" />
   
    <style>
      h1 { font-family: Arial,  Helvetica, sans-serif; font-size: 32; 
           font-weight: bold; color:  white; margin-bottom: 0}
      h2 { margin-bottom: 0}
      b { font-family: Arial, Helvetica, sans-serif; font-size: 14; 
          font-weight: bold; color: black }
      th { font-family: Arial,  Helvetica, sans-serif; font-size: 18
           font-weight: bold; color:  white; }
      body, li, td, p { font-family: Arial, Helvetica, sans-serif; 
                     font-size: 14; margin = 5px }
      a { color: #000000 }
    </style>
  </head>
  <body bgcolor="#4b0082">
   <center>
  <table width = <?php echo $table_width?> cellspacing = 0 cellpadding = 6 border = 0>
  <tr>
  <td bgcolor = "#220082"  width = 73>
   
  <img src="../images/mlm-logo.png" width="73" height="49" 
           alt="" valign="middle" /></td>
  <td bgcolor = "#220082" width = <?php echo $table_width-73;?>><h1><?php echo $title?></h1></td>
  </tr>
  </table>
  <table width = <?php echo $table_width?> cellpadding = 0 cellspacing = 0 border = 0>
  <tr><td>

<?php
}



function do_html_footer()
{
  // print an HTML footer
  global $table_width;
?>
  </td></tr>
  </table>
  <table width = <?php echo $table_width?> cellspacing = 0 cellpadding = 6 border = 0>
  <tr>
  <td bgcolor = "#220082" align = "left">
    <img src = "../images/mlm-logo.png"
                 width = 73 height = 49 alt ="" valign = "middle" />
     <p class="terms_privacy">
     | <a href="terms-conditions.html" target="_blank">Terms and Conditions</a> 
     | <a href="privacy-policy.html" target="_blank">Privacy Policy</a> 
     | <a href="contactus.html" target="_blank">Contact Us</a>  
     | <a href="sitemap.html" target="_blank">Sitemap</a> | 
     | Tel: +237 673 301 819 | 
    
    </p>
    <p class="copyright">  © 2017 Calculteller</p>
  </td>
  </tr>
  </table>
  </center>
  </body>
  </html>
<?php
}


// Print a flexible list of items and optional action buttons for each
// This function is a bit of a mess to read
// $title is the heading
// $list is the array of items to list
//  - $list[x][0] -item id
//  - $list[x][1] -item name
//  - $list[x][2] -parent name (optional)
//  - $list[x][3] -parent id (optional)
// action1, 2, and 3 are the optional actions for up to three buttons per item 
function display_items($title, $list, $action1='', $action2='', $action3='')
{
  global $table_width;
  echo "<table width = $table_width cellspacing = 0 cellpadding = 0  
         border = 0>";
  
  // count number of actions
  $actions = (($action1!='') + ($action2!='') + ($action3!='')); 
  
  echo '<tr>
        <th colspan = '. (1+$actions) ." bgcolor='#220082'> $title </th>
        </tr>"; 
  
 // count number of items
  $items = sizeof($list);
    
  if($items == 0)
    echo '<tr>
         <td colspan = '.(1+$actions).'align = center>No Items to Display</td>
         </tr>';
  else
  { 
    // print each row 
    for($i = 0; $i<$items; $i++)
    {
      if($i%2) // background colors alternate
        $bgcolor = "'#ffffff'";
      else 
        $bgcolor = "'#ccccff'";
      echo "<tr>
            <td bgcolor = $bgcolor 
             width = ". ($table_width - ($actions*149)) .'>';
      echo $list[$i][1];
      if(@$list[$i][2])
        echo ' - '.$list[$i][2];
      echo '</td>';
      
      // create buttons for up to three actions per line
      for($j = 1; $j<=3; $j++)
      { 
        $var = 'action'.$j; 
        if($$var)
        {
          echo "<td bgcolor = $bgcolor width = 149>";
          // view/preview buttons are a special case as they link to a file
          if($$var == 'preview-html'||$$var == 'view-html'||
             $$var == 'preview-text'||$$var == 'view-text')
            display_preview_button($list[$i][3], $list[$i][0], $$var);
          else        
            display_button( $$var, '&id=' . $list[$i][0] );
          echo '</td>';
        }
      }
      echo "</tr>\n";
    }
    echo '</table>';
    echo  '<br />';
  } 
}


// Print a flexible list of items and optional action buttons for each
// special version of display_items(), displays all subs and lists ADMIN
function display_items_all($title, $list, $action1='', $action2='', $action3='')
{
  global $table_width;
  echo "<table width = $table_width cellspacing = 0 cellpadding = 0  
         border = 0>";
  
  // count number of actions
  $actions = (($action1!='') + ($action2!='') + ($action3!='')); 
  
  echo '<tr>
        <th colspan = '. (1+$actions) ." bgcolor='#220082'> $title </th>
        </tr>"; 
  
 // count number of items
  $items = sizeof($list);
    
  if($items == 0)
    echo '<tr>
         <td colspan = '.(1+$actions).'align = center>No Items to Display</td>
         </tr>';
  else
  { 
    // print each row 
    for($i = 0; $i<$items; $i++)
    {
      if($i%2) // background colors alternate
        $bgcolor = "'#ffffff'";
      else 
        $bgcolor = "'#ccccff'";
      echo "<tr>
            <td bgcolor = $bgcolor 
             width = ". ($table_width - ($actions*149)) .'>';
      echo $list[$i][1];
      if(@$list[$i][2]==1)
        echo ' - '.'EN';
      else
        echo ' - '.'FR';
        
      echo ' | '.$list[$i][3];
      if(@$list[$i][4]==1)
        echo ' - '.'EN';
      else 
        ' - '.'FR';
      echo '</td>';
      
      // create buttons for up to three actions per line
      for($j = 1; $j<=3; $j++)
      { 
        $var = 'action'.$j; 
        if($$var)
        {
          echo "<td bgcolor = $bgcolor width = 149>";
          // view/preview buttons are a special case as they link to a file
          if($$var == 'preview-html'||$$var == 'view-html'||
             $$var == 'preview-text'||$$var == 'view-text')
            display_preview_button($list[$i][3], $list[$i][0], $$var);
          else        
            display_button( $$var, '&id=' . $list[$i][0] .'&email=' . $list[$i][3] );
          echo '</td>';
        }
      }
      echo "</tr>\n";
    }
    echo '</table>';
    echo '<br />';
  } 
}




// diplay stored information about each list
function display_information($listid)
{
  if(!$listid)
    return false;

  $info = load_list_info($listid);

  if($info)
  {
    echo '<h2>'.pretty($info['listname']).'</h2>';
    echo '<p>'.pretty($info['blurb']);
    echo '</p><p>Number of subscribers:' . $info['subscribers'];
    echo '</p><p>Number of messages in archive:' . $info['archive'].'</p>';
  }
}


// display form to verify user's email address
function display_verification_form($email) 
{                              
 
    $title = 'Email Verification: Please verify your email!';
?>
  
  <form method=post action="index.php?action=verify-email">
  <table bgcolor='#cccccc' cellpadding = 6 cellspacing = 0 border =0>
   <tr>
     <th colspan = 2 bgcolor = '#220082'>
        <?php echo $title?> 
     </th>
   </tr>
   
    <tr>
     <td>
       <label>Enter your Verification Code:</label> 
     </td>
     <td>
       <input type="text" name="code" size="7" maxlength="7" /> 
     </td> 
   </tr>
   
   <tr>
   <td colspan=2 align="center">
   <?php display_form_button('verify-email'); ?> 
   </td>
   </tr>    
 </table>
       
     
      <!--Hidden input field for email verification -->
     <input type="hidden" name="email"  
            value="<?php  echo $email; ?>" /> 
                
 </form> 

 <br />
<?php
}

// display form to gather new account data or change existing account data
function display_account_form($email='', $realname='', $mimetype='') 
{                              
  if($realname)
    $title = $realname;
  else
    $title = 'New Account';
?>
 
  <form method=post action="index.php?action=store-account">
  <table bgcolor='#cccccc' cellpadding = 6 cellspacing = 0 border =0>
   <tr>
     <th colspan = 2 bgcolor = '#220082'>
        <?php echo $title?> 
     </th>
   </tr>
   
    <tr>
     <td>
       <label>Real Name:</label> 
     </td>
     <td>
       <input type="text" name="realname" size="32" maxlength="50" 
          value="<?php echo $realname; ?>"/> 
     </td> 
   </tr>
   
   <tr>
     <td>
       <label>Email Address:</label> 
     </td>
     <td>
       <input type="text" name="email" size="32" maxlength="100" 
          value="<?php echo $email; ?>" />  
     </td> 
   </tr>
   
   
   
   <?php 
   //only request password if not logged in to an existing account
    if (!isset($_SESSION['admin_user']) && !isset($_SESSION['normal_user']))
    echo "<tr>
     <td>Password:</td>
     <td><input type = \"password\" name = \"new_password\"
          maxlength = 16 value = ''></td>
   </tr>";
   ?>

   <tr>
     <td>
       <label>Language:</label> 
     </td>
     <td>
       <select name="language">
         <option name="english" selected>English</option>
         <option name="french">French</option>
       </select>
     </td> 
   </tr> 
   
   <tr>
   <td colspan=2 align="center">
   <?php display_form_button('save-changes'); ?> 
   </td>
   </tr>
    
 </table>
 
    
      <!--Hidden input field for action -->
     <input type="hidden" name="action"  value="store-account" />  
   
     <!--Hidden input field for mime type -->
     <input type="hidden" name="mimetype"  value="H" /> 
      
     
      <!--Hidden input field for email verification -->
     <input type="hidden" name="code"  
        value="<?php 
                    echo rand(3000000, 5000000);
                ?>" /> 
                
 </form> 

 <br />
<?php
}


function display_login_form($action)
{
  // display form asking for email and password
?>


  <form method="post" action="index.php?action=<?php echo $action?>">
  <table bgcolor='#cccccc'  border = 0 cellpadding = 6 cellspacing = 0>
   <tr>
     <th colspan = 2 bgcolor = '#220082'>
       CalculTELLER Mail: Please Log in
     </th>
   </tr>
   
   
   <tr>
     <td>
       <label>Email Address:</label> 
     </td>
     <td>
       <input type="text" name="email" size="32" maxlength="100" />  
     </td> 
   </tr>
   
   <tr>
     <td>
       <label>Password:</label> 
     </td>
     <td>
       <input type="password" name="password"  size="32" maxlength="14" />
     </td> 
   </tr>    
    
    <tr>
     <td colspan=2 align="center">
     <?php display_form_button('log-in'); ?>
     </td></tr>
   <tr>
 </table></form>

 <br />
<?php
}


function display_form_button($button)
{
  //display one of our standard buttons in a form
  echo "<center><input type = 'image' src = 'images/".$button.".gif' 
                 border = 0 ";
  echo 'width = 149 height = 43 ';
  echo "alt = '".format_action($button)."' /></a></center>";
}

function display_button($button, $extra_parameters = '')
{
  //display one of our standard buttons as a href
  $url = "index.php?action=$button";
  if($extra_parameters)
    $url .= $extra_parameters;
  echo "<center><a href = '$url'>";
  echo "<img src = 'images/$button.gif' border = 0 ";
  echo 'width = 149 height = 43 ';
  echo "alt = '".format_action($button)."' /></a></center>";
}



function display_preview_button($list, $mail, $button)
{
  if( $button == 'view-html'||$button== 'preview-html' )
    echo "<center><a href = 'archive/$list/$mail/index.html' 
                   target = '_new'><img src ='images/$button.gif' 
                   width = 149 height = 43 border=0 
                   alt = '".format_action($button)."' /></a></center>\n";
  else
    echo "<center><a href = 'archive/$list/$mail/text.txt' 
                   target = '_new'><img src ='images/$button.gif' 
                   width = 149 height = 43 border=0 
                   alt = 'format_action($button)' /></a></center>\n";
}

function display_spacer()
{
  //display blank spacer the size of our buttons
  echo "<img src = 'images/spacer.gif' border = 0 ";
  echo 'width = 149 height = 43 ';
  echo "alt = '' />";
}

function format_action($string)
{
  // convert our actions into a displayable string
  // eg "account-setup" becomes "Account Setup"
  $string = str_replace('-', ' ', $string);
  $string = ucwords($string);
  return $string;
}

function display_toolbar($button, $extra_parameters = '')
{
  // draw our toolbar
  // there are up to five buttons per row and up to three rows
  // these numbers are completely arbitary and depend on the 
  // images size and acceptable screen width
  
  global $table_width;
  
  echo "<table width = $table_width cellpadding = 0 cellspacing = 0 
          border = 0>";
  
  for($i = 0; $i < 3; $i++ )
  {

    if(@$button[($i*5)])
    {
      echo '<tr>';
      echo '<td bgcolor = "#cccccc">';
      for($j = 0; $j < 5; $j++)
      {
        echo '<td bgcolor = "#cccccc">';
        if (@$button[($i*5+$j)])
          display_button($button[$i*5+$j], $extra_parameters);
        else 
          display_spacer();
        echo '</td>';
      }
      echo '</tr>';
    }
  }
  echo '</table>';
  echo '<br />';
}

function pretty($string)
{
  //prepare a text message for tidy display as HTML
  
  $string = trim($string);
  $string = htmlspecialchars($string);
  $string = nl2br($string);
  $string = stripslashes($string);
    
  return $string;
}

function pretty_all($array)
{
  //prepare an array of text messages for tidy display as HTML
  foreach ($array as $key => $val)
    $array[$key] = pretty($val);
  return $array;
}

function display_mail_form($email, $listid=0)
{
  // display html form for uploading a new message
  global $table_width;
  $list = get_all_lists();
  $lists = sizeof($list);
?>
  <table cellpadding = 4 cellspacing = 0 border = 0 width = <?php echo $table_width?>>
  <form enctype='multipart/form-data' action='upload.php' method='post'>
  <tr>
    <td bgcolor = "#cccccc">
      List:
    </td>
    <td bgcolor = "#cccccc"> 
      <select name = "list">
      <?php
      for($i = 0; $i<$lists; $i++)
      {
        echo '<option value = '.$list[$i][0];
        if ($listid== $list[$i][0]) echo ' selected';
        echo '>'.$list[$i][1]."</option>\n";
      }
      ?>
      </select>
    </td>
  </tr>
  <tr>
    <td bgcolor = "#cccccc">
      Subject:
    </td>
    <td bgcolor = "#cccccc">
      <input type = "text" name = "subject" value = "<?php (isset($subject))?
                                                          $subject: '';?>" 
       size = 60 ></td>
  </tr>
  <tr><td bgcolor = "#cccccc">
    Text Version:  
  </td><td bgcolor = "#cccccc">
    <input type="file" name='userfile[0]' size = 60>
  </td></tr>
  <tr><td bgcolor = "#cccccc">
    HTML Version:  
  </td><td bgcolor = "#cccccc">
    <input type="file" name='userfile[1]' size = 60>
  </td></tr>
  <tr><td bgcolor = "#cccccc" colspan =2>Images: (optional)
  
<?php
  $max_images = 10;
  for($i = 0; $i<10; $i++)
  {
    echo "<tr><td bgcolor = '#cccccc'>Image ". ($i+1) .' </td>';
    echo "<td bgcolor = '#cccccc'>";
    echo "<input type=\"file\" name='userfile[".($i+2)."]' size = 60></td></tr>";
  }
?>   
  <tr><td colspan = 2 bgcolor = '#cccccc' align = "center">
  <input type = "hidden" name = "max_images"  value = <?php echo $max_images?>>
  <input type = "hidden" name = "listid"  value = <?php echo $listid?>>
  <?php display_form_button('upload-files'); ?>
  </td>
  </form>
  </tr>
  </table>
  <br />
<?php
}

function display_password_form()
{
// display html change password form
?>
   <br />
   
   <form action="index.php?action=store-change-password" method="post">
   <table cellpadding=2 cellspacing=0 bgcolor="#cccccc">
   <tr><th colspan = 2 bgcolor = "#220082" > Change Password </th></tr> 
   <tr><td>Old password:</td>
       <td><input type="password" name="old_passwd" size=16 maxlength=16></td>
   </tr>
   <tr><td>New password:</td>
       <td><input type="password" name="new_passwd" size=16 maxlength=16></td>
   </tr>
   <tr><td>Repeat new password:</td>
       <td><input type="password" name="new_passwd2" size=16 maxlength=16></td>
   </tr>
   <tr><td colspan=2 align="center"><?php display_form_button('change-password'); ?>
   </td></tr>
   </table>
  
   <br />
<?php
};

function display_list_form()
{
// display html new list form
?>
   <br />
   <center>
   <form action="index.php?action=store-list" method="post">
   <table cellpadding=2 cellspacing=0 bgcolor="#cccccc">
   <tr><th colspan = 2 bgcolor = "#220082" > Create New List </th></tr> 
   <tr><td>List Name:</td>
       <td><input type="name" name="name" size=20 maxlength=20></td>
   </tr>
   <tr><td colspan = 2>List Description:</td></tr>
   <tr><td colspan = 2><textarea rows = 4 cols = 72 
                        name = "blurb"></textarea></td></tr>
   <tr>
     <td>
       <label>Language:</label> 
     </td>
     <td>
       <select name="language">
         <option name="english" selected>English</option>
         <option name="french">French</option>
       </select>
     </td> 
   </tr> 
   <tr><td colspan=2 align="center"><?php display_form_button('save-list'); ?>
   </td></tr>
   </table>
   </center>
   <br />
<?php
};


?>




