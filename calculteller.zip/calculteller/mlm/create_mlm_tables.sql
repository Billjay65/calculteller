
use calculteller;

create table lists
(
  listid int auto_increment not null primary key,
  listname char(20) not null,
  blurb varchar(255)
);

create table subscribers
(
  email char(100) not null primary key,
  realname char(100) not null,
  mimetype char(1) not null,
  password char(40) not null,
  admin tinyint not null, 
); 

# stores a relationship between a subscriber and a list 

create table sub_lists
(
  email char(100) not null,
  listid int not null
);

create table mail
(
  mailid int auto_increment not null primary key,
  email char(100) not null,
  subject char(100) not null,
  listid int not null,
  status char(10) not null,
  sent datetime,
  modified timestamp
);

#stores the images that go with a particular mail

create table images
(
  mailid int not null,
  path char(100) not null,
  mimetype char(100) not null
);

--Alter lists table ADD LANGUAGE to each mail 
ALTER TABLE lists ADD language
         tinyint NOT NULL DEFAULT 1;
--Alter subscribers table ADD LANGUAGE to each subscriber
ALTER TABLE subscribers ADD language
         tinyint NOT NULL DEFAULT 1;
         
--Alter subscribers table ADD code to each subscriber
ALTER TABLE subscribers ADD code
         int(7) NOT NULL;
--Alter subscribers table ADD verified to each subscriber
ALTER TABLE subscribers ADD verified
         tinyint NOT NULL DEFAULT 0;

insert into subscribers values
('admin@localhost', 'Administrative User', 'H', sha1('admin'), 1);










