<?php

 // start session, authenticate user....
 session_start();
 
 // Start output buffer
 ob_start();
 
 // include config file containing directory paths
 require_once 'include/config.php';
 
 // include error handling class php file
 require_once 'error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 // Delete later for testing purposes Errorhandler test
 // require_once('inexistent_file.php');
 
 
 // Get web browser language of User 
// get first value(Primary Language) from language array
 $browserLanguage = $_SERVER['HTTP_ACCEPT_LANGUAGE'][0] 
                      . $_SERVER['HTTP_ACCEPT_LANGUAGE'][1];
                      
  // Get selected language of page default is en
  // include language configuration file based on selected language
	$language = "en";
                      
  // Create session variable to store selected language
  if(isset($_SESSION['language'])){
     $userLanguage = $_SESSION['language'];
     $language     = $userLanguage; 
  }
  else{
     $userLanguage = ''; 
  }
 
 

  
  // read browser language Only when user language SESSION variable
  // is NOT SET(equals ''), if userLanguage is set, do not use browser language
  if((!empty($browserLanguage)) && ($browserLanguage == 'en' ||
       $browserLanguage == 'fr' || $browserLanguage == 'es'
       || $browserLanguage == 'zh')
      && ($userLanguage =='')){
    $language = $browserLanguage;
      
  }
  
	if(isset($_GET['lang'])){ 
		$language = $_GET['lang'];
    $_SESSION['language'] = $language;
     
	} 
 
   
  // get language file based on user's language
	require_once(SITE_ROOT."/values/".$language.".php");
 
 
 
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 
 // Call the home page to display html content on screen
 
 
 fixed_html_header($lang['title_index'],
                  'Balance (Change) Functions', 
                    $user_name, $member, null, $lang, $language);
fixed_html_sidebar();
display_domains_list($lang);
fixed_html_content();
display_domain_image_links();
display_ads();
fixed_html_ads();
fixed_html_footer($lang);
 
 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();
?>