
<?php

// Start session and read username from session variable if it is set
 session_start(); 

// include config file containing directory paths
 require_once 'include/config.php';
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
   // Get web browser language of User 
// get first value(Primary Language) from language array
 $browserLanguage = $_SERVER['HTTP_ACCEPT_LANGUAGE'][0] 
                      . $_SERVER['HTTP_ACCEPT_LANGUAGE'][1];
                      
  // Get selected language of page default is en
  // include language configuration file based on selected language
	$language = "en";
                      
  // Create session variable to store selected language
  if(isset($_SESSION['language'])){
     $userLanguage = $_SESSION['language'];
     $language     = $userLanguage; 
  }
  else{
     $userLanguage = ''; 
  }
 
 

  
  // read browser language Only when user language SESSION variable
  // is NOT SET(equals ''), if userLanguage is set, do not use browser language
  if((!empty($browserLanguage)) && ($browserLanguage == 'en' ||
       $browserLanguage == 'fr' || $browserLanguage == 'es'
       || $browserLanguage == 'zh')
      && ($userLanguage =='')){
    $language = $browserLanguage;
      
  }
  
	if(isset($_GET['lang'])){ 
		$language = $_GET['lang'];
    $_SESSION['language'] = $language;
     
	} 
   
  // get language file based on user's language
	require_once(SITE_ROOT."/values/".$language.".php");



    // display input validation error 
    function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        return "<div class=\"error\">ERROR: Invalid data for field '$key'</div>"; 
      } else { 
        return false; 
      } 
    } 
    
    
   $editMode = 0;
   $errorFlag = 0;
   //$errorHeader = 'ERROR: Form filled incorrectly, Please correct error';
   $errorHeader = '';
  

  $linkToAccountDetails;
  $linkToCancelPage = Link::Build('index.php');
  
  

  // header('Location:'.$mLinkToCancelPage);
 
    $inputErrors = array(); 
    $submitted = false; 
    
    $successHeader = false;
    
    
 
 
    // if form submitted 
    // validate form input 
if (isset($_POST['submit'])) 
{ 
      
      $submitted = true; 
      $valid = array(); 
      $_username = '';
      $_email = '';
      
 
      
      
      // validate user email 
      // if email is unique then it is valid
      // email must be found in database
      if (!empty($_POST['email']) && preg_match('/^([a-z0-9_-])+([\.a-z0-9_-])*@([a-z0-9-])+(\ 
       .[a-z0-9-]+)*\.([a-z]{2,6})$/', $_POST['email'])) { 
       
         $_email = htmlentities(trim($_POST['email']));
       
        // Check if email is unique
         // create and execute SELECT query 
        $sql = "SELECT COUNT(*) FROM user
                WHERE email = '$_email'"; 

        $row1 = getOne($sql, $params=NULL);
 
 
         if($row1[0]== 1)
         {
            $valid['email'] = htmlentities(trim($_POST['email']));
            
         }
         else
         {
          $inputErrors[] = 'Email does not exist';
          $errorFlag = 3; 
         
         }
       
      } else { 
        $inputErrors[] = 'email';
        $errorFlag = 3; 
      } 
 
      // validate user password Must start with Capital letter atleast 4 characters long
      // passord can accept any character in utf-8 or ansi
      if (!empty($_POST['password']) && preg_match('/^([A-Z])+(.){3,16}$/', $_POST['password']))  { 
        $valid['password'] = htmlentities(trim($_POST['password'])); 
      } else { 
        $inputErrors[] = 'password';
        $errorFlag = 4; 
      } 
      // validate user password Must start with Capital letter atleast 4 characters long
      if (!empty($_POST['passwordconfirm']) && preg_match('/^([A-Z])+(.){3,16}$/', $_POST['passwordconfirm']))  { 
        $valid['passwordconfirm'] = htmlentities(trim($_POST['passwordconfirm'])); 
      } else { 
        $inputErrors[] = 'password confirm'; 
        $errorFlag = 5;
      } 
      
     
                         
      // Validate user password
      if (isset($valid['passwordconfirm']) && isset($valid['password']))
      {
        if  ($valid['passwordconfirm'] == $valid['password'])
        { 
          $valid['password'] = htmlentities(trim($_POST['password'])); 
        } else { 
        $inputErrors[] = 'Passwords Different'; 
        $errorFlag = 11;
        } 
      }
               
      
      if($errorFlag > 0)
      $errorHeader = 'ERROR: Form filled incorrectly, Please correct errors!';
      
      
      // if there are no errors in input UPDATE user details in database
    if(($errorFlag == 0) || count($inputErrors) == 0)
    { 
     
      // sanitize data and insert into database including date
      $password = addslashes($valid['password']);
      $email = addslashes($valid['email']);
      $password = PasswordHasher::Hash($password, true);
 
   
 
     // Update data into database: user table 
     // Build the SQL query
  
      $sql = "UPDATE user SET
                   password = '$password'
             WHERE email = '$email'";

      // Execute the query
      $lastInsertId1 = executeQuery($sql, $params = null);
    
       if($lastInsertId1 == 0 )
       {
    
          $successHeader = true;
           
      }                  
            
      else
      {
        // if user data was NOT saved, store error message
           
        $errorHeader = 'Error: We were unable to save your details.
                        Try again!';
        $errorFlag = 1;   
           
        // DELETE this after testing subscriber code
        // exit();
      }  
    
   unset($database_handler); 
 

  }
               
} 


 
    // if form not submitted 
    // or if validation errors exist 
    // or if password reset successful
    // (re)display form  with correct header message
if (($submitted == true && count($inputErrors) > 0) || $submitted == false ||
    ($submitted == true && $successHeader == true)) 
{ 
   
  do_html_header2($lang['reset_password_title'], $lang['reset_password_title'], 
                  $errorHeader, $successHeader); 
  if($successHeader)
  {
     echo '<span class="success">'.'Password Reset Successful!' .'<br/>';
     echo 'Click '.'<a href="'. $linkToCancelPage.'">'.' Here To Start'.'</a>'.'</span>' ;
  }
  
 

 ?>
 
 
                   
  <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="reset_password_form">
  <h3><?php if(isset($lang['reset_password_form_title']))
               echo $lang['reset_password_form_title'];
           else 
              echo 'Enter Your New Password'; ?></h3>
  <table class="user-table">
  
     
    
     <tr>
      <td><?php if(isset($lang['email']))
               echo $lang['email'];
           else 
              echo 'E-mail Address:'; ?>
      <br />        
      
      <input type="email" name="email"  maxlength="100"
        value="<?php echo isset($_POST['email']) ? $_POST['email'] : '';?>" 
        <?php if($editMode="readonly") echo 'size="40"';?> /> 
        <?php echo getInputError('Email does not exist', $inputErrors); ?> 
        
      <?php echo getInputError('email', $inputErrors); ?> 
      </td>
    </tr>
    
     <tr>
      <td><?php if(isset($lang['password']))
               echo $lang['password'];
           else 
              echo 'Password:'; ?>  
              
        <br />
        
        <input type="password" name="password" size="40" maxlength="40"
         value="<?php echo isset($_POST['password']) ? $_POST['password'] : '';?>" />
        <?php echo getInputError('password', $inputErrors); ?> 
        <?php echo getInputError('Passwords Different', $inputErrors); ?> 
         
      </td>
    </tr>
    <tr>
      <td><?php if(isset($lang['password_confirm']))
               echo $lang['password_confirm'];
           else 
              echo 'Re-enter Password:'; ?>
              
        <br />
        
        <input type="password" name="passwordconfirm" size="40" maxlength="40"
         value="<?php echo isset($_POST['passwordconfirm']) ? $_POST['passwordconfirm'] : '';?>"/>
        <?php echo getInputError('password confirm', $inputErrors); ?>
        
      </td>
    </tr>
   
     
      
  <tr>
    <td>
       <input type="submit" name="submit" 
         value="<?php if(isset($lang['reset_password_btn']))
                         echo $lang['reset_password_btn'];
                      else 
                          echo 'Reset Password'; ?> "  /> |
                          
   <a href="<?php  echo $linkToCancelPage; ?>">
     <?php if(isset($lang['cancel_btn'] ))
              echo $lang['cancel_btn'] ;
           else 
              echo 'Cancel'; ?> </a>
    </td>
 </tr>
 </table>
 
    
  </form> 
  


<?php 

do_html_footer($lang); 
  // if form submitted with no errors 
  // write the input to the database 
} 

 


 
?> 
