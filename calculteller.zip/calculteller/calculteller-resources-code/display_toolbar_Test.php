<html>
<head></head> 
<body>
<?php
// Server HTTP port (can omit if the default 80 is used)
define('HTTP_SERVER_PORT', '80');
/* Name of the virtual directory the site runs in, for example:
   '/tshirtshop/' if the site runs at http://www.example.com/tshirtshop/
   '/' if the site runs at http://www.example.com/ */
define('VIRTUAL_LOCATION', '/calculteller/calculteller-resources-code/');

// Define constant to use SSL or Not
define('USE_SSL', 'no');

 $action = (isset($_GET['action']))? $_GET['action'] : '';
 $buttons = array();

  // append to this string if anything processed before header has output
  $status = '';
  
  
   // if a normal user
  $buttons[0] = 'change-password';
  $buttons[1] = 'account-settings';
  $buttons[2] = 'show-my-lists';
  $buttons[3] = 'show-other-lists';
  $buttons[4] = 'log-out';
  
 // Call functions
 display_toolbar($buttons); 
  
  
  
 // define functions  
function display_toolbar($buttons)
{
  if (!is_array($buttons))
  {
     echo 'No categories currently available<br />';
     return;
  }
  echo '<ul>';
  foreach ($buttons as $action)
  {
    $url = 'index.php?action='.($action);
    $title = $action;
    echo '<li>';
    echo do_html_url($url, $title);
    echo '</li>';
  }
  echo '</ul>';
  echo '<hr />';
}

function do_html_url($link, $title, $type = 'http')
{
    $base = (($type == 'http' || USE_SSL == 'no') ? 'http://' : 'https://') .
            getenv('SERVER_NAME');

    // If HTTP_SERVER_PORT is defined and different than default
    if (defined('HTTP_SERVER_PORT') && HTTP_SERVER_PORT != '80' &&
        strpos($base, 'https') === false)
    {
      // Append server port
      $base .= ':' . HTTP_SERVER_PORT;
    }

    $link = $base . VIRTUAL_LOCATION . $link;

    // Escape html
    $link =  htmlspecialchars($link, ENT_QUOTES);
  

   return '<a href='.$link.'>'.$title.'</a>';

}

?>
</body>
</html>