
<?php 
    // display input validation error 
    function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        return "<div class=\"error\">ERROR: Invalid data for field '$key'</div>"; 
      } else { 
        return false; 
      } 
    } 
   
   // Variables for display mode(edit mode or normal), input and links 
    $editMode = 0;
   $email = '';
   $name = '';
  $password ='';
   $phone = null;
 /* 
  $nameError = 0;
  $emailAlreadyTaken = 0;
  $emailError = 0;
  $passwordError = 0;
  $passwordConfirmError = 0;
  $passwordMatchError = 0;
  */
  $linkToAccountDetails;
  $linkToCancelPage;
 
    $inputErrors = array(); 
    $submitted = false; 
 
    // if form submitted 
    // validate form input 
 if (isset($_POST['submit'])) { 
      $submitted = true; 
      $valid = array(); 
 
      // validate title 
      if (!empty($_POST['title'])) { 
        $valid['title'] = htmlentities(trim($_POST['title'])); 
      } else { 
        $inputErrors[] = 'title'; 
      } 
 
      // validate author name 
      if (!empty($_POST['author']) && preg_match("/^[a-zA-Z\s.\-]+$/",  
$_POST['author'])) { 
        $valid['author'] = htmlentities(trim($_POST['author'])); 
      } else { 
        $inputErrors[] = 'author'; 
      } 
 
      // validate ISBN 
      if (!empty($_POST['isbn']) && preg_match('/^(97(8|9))?\d{9}(\d|X)$/',  
$_POST['isbn'])) { 
        $valid['isbn'] = htmlentities(trim($_POST['isbn'])); 
      } else { 
        $inputErrors[] = 'isbn'; 
      } 
      // validate price 
      if (!empty($_POST['price']) && is_numeric($_POST['price']) && $_POST['price'] > 0) 
{ 
        $valid['price'] = htmlentities(trim($_POST['price'])); 
      } else { 
        $inputErrors[] = 'price'; 
      } 
    } 
 
    // if form not submitted 
    // or if validation errors exist 
    // (re)display form 
 if (($submitted == true && count($inputErrors) > 0) || $submitted == false) { 
?> 
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
  <h2>Sign up to gain full access</h2>
  <h3>Please enter your details:</h3>
  <table class="user-table">
  
     <tr>
      <td>E-mail Address:</td> 
      <input type="text" name="email" 
        value="<?php echo isset($_POST['email']) ? $_POST['email'] : '';?>" 
        <?php if($editMode="readonly") echo 'size="32"';?> /> 
        
      <?php echo getInputError('email', $inputErrors); ?> 
      </td>
    </tr>
    <tr>
      <td>Name:</td>
      <td>
        <input type="text" name="name"  
        value="<?php echo isset($_POST['name']) ? $_POST['name'] : '';?>" 
        size="32" />
        <?php echo getInputError('name', $inputErrors); ?> 
      </td>
    </tr>
     <tr>
      <td>Password:</td>
      <td>
        <input type="password" name="password" size="32" />
        <?php echo getInputError('password', $inputErrors); ?> 
         
      </td>
    </tr>
    <tr>
      <td>Re-enter Password:</td>
      <td>
        <input type="password" name="passwordConfirm" size="32" />
        <?php echo getInputError('passwordConfirm', $inputErrors); ?>
        
      </td>
    </tr>
    <tr>
      <td>Telephone:</td>
      <td>
        <input type="text" name="phone" 
          value="<?php if($editMode=) echo 'size="32"';?> />
        <?php echo getInputError('telephone', $inputErrors); ?>
          
        
      </td>
    </tr>
    
    
      
     
      <input type="submit" name="submit" value="Sign Up" /> |
  <a href="<?php $linkToCancelPage; ?>">Cancel</a>
</form>


<?php 
    // if form submitted with no errors 
    // write the input to the database 
    } else { 
      // open SQLite database file 
      try { 
         $pdo = new PDO('sqlite:books.db'); 
         $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
      } catch (PDOException $e) { 
         die("ERROR: Could not connect: " . $e->getMessage()); 
      } 
 
      // create and execute INSERT query 
      try { 
        $title = $pdo->quote($valid['title']); 
        $author = $pdo->quote($valid['author']); 
        $isbn = $pdo->quote($valid['isbn']); 
        $price = $pdo->quote($valid['price']); 
        $sql = "INSERT INTO books (title, author, isbn, price) VALUES ($title, $author, 
$isbn, $price)"; 
        $ret = $pdo->exec($sql); 
        echo '<div class="success">SUCCESS: Record saved!</div>'; 
      } catch (Exception $e) { 
        echo '<div class="error">ERROR: ' . $e->getMessage() . '</div>'; 
      } 
 
      // close connection 
      unset($pdo); 
    } 
?> 
