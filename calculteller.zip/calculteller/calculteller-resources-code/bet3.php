<?php

 // Obtaining root directory  from domains folder
 define('SITE_ROOT2', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT2.'/include/config.php';
   

 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 // Preprocessing: get query, form data string and get database data
 // Define short variables
 
  
  
 
 // create short variable names  
   $tabId   = (!isset($_GET['tab_id']))? 1 : $_GET['tab_id'];
  $domainId = (!isset($_GET['domain_id']))? '' : $_GET['domain_id'];   

$radioUnits = (!isset($_POST['radio_units']))? 'Abbrevation': $_POST['radio_units'];
$radioUnits = (!isset($_POST['radio_units']))? 'Full': $_POST['radio_units'];
$unitSelected = (!isset($_POST['unitselected']))? 'unit(s)': $_POST['unitselected'];
   

 // Variables for bet domain number rows of input data 
 // (Number of games corresponds to number of rows)
  $gcNo = (!isset($_POST['gcno']))? '': $_POST['gcno'];
  $amountP = (!isset($_POST['amountp']))? '': $_POST['amountp'];
  
  $gcTotal = '';
  $codeTotal =  (!isset($_POST['codetotal']))? '': $_POST['codetotal'];
  $totalAmountW = (!isset($_POST['totalamountw']))? '': $_POST['totalamountw'];
  

  
 
 
 // Array variables
  $gameCno = (!isset($_POST['gamecno']))? array(''): $_POST['gamecno']; 
  $code = (!isset($_POST['code']))? array(''): $_POST['code'];
  $amountW = (!isset($_POST['amountw']))? array(''): $_POST['amountw']; 
 
 // Flag variable to show if domain table rows have been created or not
  $domainTableRowsCreated = false; 
 
 
  
   
   
   

 
 // get domain Id when form is submitted
 if(isset($_POST['domain']))
    $domainId = $_POST['domain'];
    

  
 
 if(isset($domainId) )
 {
  
  // get domain id, name and other properties
  $query1 = "SELECT * FROM domain 
             WHERE domain_id = $domainId";       
    $result1 = getRow($query1, $params=NULL);
  
  
   
   // get domain tabs 
  $query2 = "SELECT tab_id, tab_name from domain_tab
              WHERE  domain_id = $domainId";
    $result2 = getAll($query2, $params = null);
   
   // get domain units
   
    
   $query3 = "SELECT      u.unit_id, u.abbrevation, u.unit_name
               FROM     unit u
               WHERE    u.unit_id IN
               (SELECT unit_id
               FROM    domain_unit
               WHERE   domain_id = $domainId)  
               ORDER BY u.unit_id" ;
   $result3 = getAll($query3, $params = null);
   
  }
  
  
   
  $domain_name = strip_tags($result1['name']);
  $description = strip_tags($result1['description']);
 $domain_image = strip_tags($result1['image']);
 $image_string = 'images/'. $domain_image;  
 
   $domain_tabs = $result2;
   $domain_units = $result3;
   




    
 // display html conponents of web page
fixed_html_header('CalculTELLER: Balance domain calculates 
                    your change in less than a second',
                      'Balance (Change) Functions');  


// look for starting marker
 // if not available, assume 0
fixed_html_sidebar(); 
display_domains_list();  
fixed_html_content();




if(!isset($_POST['me']))
{
?>
 <div>
<table width="100%" border="0">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="domain" value="<?php echo $domainId; ?>"> 

  <tr> 
    <td colspan="4" bgcolor="#00a0a0"> 
      <h1>Calculteller:<?php echo $domain_name; ?> Domain </h1> 
      <span><?php echo $description; ?></span>
    </td> 
  </tr> 

  <tr valign="top"> 
    <td  rowspan="2"> 
     <img src=<?php echo Link::Build($image_string); ?> alt="domain-image" width="150px" height="70px" />
    </td> 
    
    <td  colspan="3"> 
  
       <ul >
    
    <?php
     // display domain tabs
     
     $selectedtab = 0;
     $selectedt = '';
    
    for($i=0; $i < sizeof($domain_tabs); $i++)
    {
     echo   '<li style="float:left; list-style:none;">';
     
     
     if (isset ($_GET['tab_id']))
       $selectedtab = (int)$_GET['tab_id'];

     if ($selectedtab == $domain_tabs[$i]['tab_id'])
        $selectedt = 'class="selectedt"';
     
     //Generate a link for each result     
     echo "<a ".$selectedt." href=". Link::ToDomainTab($domain_tabs[$i]['tab_id'], $domainId). ">";
     echo '| '. strtoupper($domain_tabs[$i]['tab_name']);
     echo   '</a>'.'&nbsp';
     echo '</li>';
        
    }
    ?>
     |</ul>
    </td>  
  </tr> 

  <tr valign="top" > 
    
    <td  colspan="3"> 
        Technical and Managerial Tutorials 
    </td> 
    
  </tr> 


  <tr> 
    <td colspan="4" bgcolor="#00a0a0">
    
    
    
    <p class="inputfields"> 
    
    SELECT TYPE OF UNITS:
    <input type="radio" name="radio_units" value="Abbrevation"
    <?php if ($radioUnits==''||$radioUnits=='Abbrevation') echo 'checked'; 
          else echo ''; ?> >  Abbreviation
    <input type="radio" name="radio_units" value="Full"
    <?php if ($radioUnits=='Full') echo 'checked'; 
          else echo '';  ?> > Full
     
      <br />
      <select name="unitselected"> 
    <?php
     // display units as options of select input element 
     // taking into account the unit selected and Full or Abbrevated
    if($radioUnits == 'Abbrevation') 
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['abbrevation'].'"';
               if($domain_units[$i]['abbrevation'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
         echo     $domain_units[$i]['abbrevation']; 
       
     
       echo   '</option>' ;
    }
   }  
    if($radioUnits == 'Full')
    {
     for($i=0; $i < sizeof($domain_units); $i++)
     {
       echo   '<option value="'.$domain_units[$i]['unit_name'].'"';
              if($domain_units[$i]['unit_name'] == $unitSelected)
                echo 'selected';
       echo   ' >';
      
      
     
         echo     $domain_units[$i]['unit_name'];
     
       echo   '</option>' ;
     }
    } 
    ?>
    
    </select> 
 
     <input type="submit" name="units" value="SET AS CURRENT"> <br />
      
     
     
 
  <input type="submit" name="save" value="SAVE"> <br /><br />
  <input type="submit" name="donate" value="DONATE: PLEASE CLICK HERE TO DONATE">
 
  </p>
  
  
    </td> 
  </tr> 
  
  <tr>
  <td colspan="4"><label>NUMBER of GAMES or CONDITIONS</label>
  <input type="text" name="gcno" value="<?php echo $gcNo; ?>"> 
  <label>AMOUNT_PLACED</label> 
   <input type="text" name="amountp" value="<?php echo $amountP; ?>"> 
   <input type="text" name="unit[]" value="<?php echo $unitSelected; ?>"> 
  <input type="submit" name="gamesnumber" value="GO!"> <br />
  
  </td>
  </tr>  
  <tr>
      <td >G/C</td>
      <td >GAME/CONDITION</td>
      <td >CODE</td>
      <td >AMOUNT_WON</td>
   </tr>   
 
 
 
 <!-- Display the number of rows of data specified for domain-->
<?php

  
 // If the submit button  of the number of games is clicked code below is executed  
if(isset($_POST['gamesnumber'])) 
{  
    
  $amountP = $_POST['amountp'];
  $gcNo = $_POST['gcno']; 
  $codeTotal =  $_POST['codetotal'];
  $totalAmountW =  $_POST['totalamountw'];
 
 
 if($domainTableRowsCreated == false)
 {
  for($j=0; $j < $gcNo ; $j++) 
  {
    echo '<tr>';
   
    echo '<td rowspan='.'"1"'.'>GC</td>';
    echo  '<td>'.'<input type="text"'.'name="gamecno[]"'.'value="'.$gameCno[$j] .'">'.'</td>';
    echo  '<td>'.'<input type="text"'.'name="code[]"'.'value="'.$code[$j] .'">'.'</td>';
    echo  '<td>'.'<input type="text"'.'name="amountw[]"'.'value="'.$amountW[$j].'">'.'</td>';
  
    echo  '</tr>';
    $domainTableRowsCreated = true; 
  }
 }

 /*
 // Array variables
  $code =  $_POST['code'];
  $amountW =  $_POST['amountw']; 
 */ 
  // Calculate total values of input elements
  
   for($i=0; $i < $gcNo; $i++)
   {
     $gcTotal += 1;
     
     $codeTotal = $code[$i];
     $amountW[$i] = $code[$i] * $amountP[$i];  
     $totalAmountW += $amountW[$i];
    
   }

}



    
 ?> 
 
   <tr>
      <td >TOTAL</td>
      <td ><input type="text" name="gctotal" value="<?php echo $gcTotal  ?>"></td>
      <td ><input type="text" name="codetotal" value="<?php echo $codeTotal  ?>"></td>
      <td ><input type="text" name="totalamountw" value="<?php echo $totalAmountW  ?>">
      <input type="text" name="unit[]" value="<?php echo $unitSelected; ?>"></td>
   </tr>   
 <tr>
 <td colspan="4">
 <input type="submit" name="gamesnumber" value="ANSWER"> 
 </td>
 </tr> 
  
</form>
</table> 
</div>
 

<?php
}   







fixed_html_ads();
fixed_html_footer();
 
 
 




 unset($database_handler);

?>