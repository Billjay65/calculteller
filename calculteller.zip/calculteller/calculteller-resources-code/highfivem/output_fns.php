
<?php




function display_html_header($lang, $language, $languageSelectTitle, $category=false)
{

?>
   <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html>
 
   <head>
   
     <title><?php echo $lang['title'] ?></title>
   
     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
     <meta charset="UTF-8" />

     <meta name="viewport" content="width=device-width, initial-scale=1.0" />

 
    <link rel="icon" type="image/png" href=<?php echo Link::Build('images/favicon.png'); ?> />
  
  
  
    <script src=<?php echo Link::Build('scripts/css3-mediaqueries.min.js'); ?>></script>



  
   <link rel="stylesheet" media="screen and (max-width: 600px)" href=<?php echo Link::Build('styles/highfivem_mobile.css'); ?> />
   <link rel="stylesheet" media="screen and (min-width: 600px)" href=<?php echo Link::Build('styles/highfivem.css'); ?> />
  
   
   <script type="text/javascript" src=<?php echo Link::Build('scripts/sidemenu.js'); ?>></script> 
   <script type="text/javascript" src=<?php echo Link::Build('scripts/language.js'); ?>></script>
   
    
   
  
   
  </head>
  
  
 <body>
     
   <div id="main">
    
    
     <div id="header">
    
      <span class="logo_span">
       <h1 class="logo"><a href="<?php echo LINK::Build('index.php');?>" target="_self">
              <img src="<?php echo LINK::Build('images/logo.png');?>" alt="High Five Marijuana Shop logo" />
            </a></h1>
      </span>
      
      <span class="tel_email_span">
          <span>
            <a href="tel:+12053456441" target="_self">
              <img src="<?php echo LINK::Build('images/ic_call_black_18dp.png');?>" alt="High Five Marijuana Shop logo" />
              <?php echo $lang['tel']; ?>
            </a>
          </span>&nbsp;
            
            <span>
             <a href="mailto:info@highfivem.com" target="_self">
               <img src="<?php echo LINK::Build('images/ic_email_white_18dp.png');?>" alt="High Five Marijuana Shop logo" />
               <?php echo $lang['email_invite']; ?>
              </a>
            </span>
      </span>
      
      
      
      
     <!--START - language div from zumcars-->
       <!--Language div and buttons below --> 
       <span class="languagebtn"> 
         
         
         
         <!-- Button for Changing language-display different btns depending on selected language-->
         
           <a  href="javascript:void(0)" class="languagebtn" onclick="openLang()">
             
             <?php 
              if($language == 'en'){
              ?>
               
              <img src="<?php echo LINK::Build('images/english-icon.png')?>" alt="en" /> 
              
              <?php 
              } 
              ?>
               <?php 
              if($language == 'fr'){
              ?>
               
              <img src="<?php echo LINK::Build('images/french-icon.png')?>" alt="fr" /> 
              
              <?php 
              } 
              ?>
               <?php 
              if($language == 'es'){
              ?>
               
              <img src="<?php echo LINK::Build('images/spanish-icon.png')?>" alt="en" /> 
              
              <?php 
              } 
              ?>
                    
                    
           </a>
           
           
            <div id="lang_header_form"> 
             
              <a  href="javascript:void(0)" class="closebtn" onclick="closeLang()">
                    &times;</a>
          
              
            <a class="language-link-item" href="index.php?lang=en" <?php if($language == 'en')
              {?> style="color:#ff9900;" <?php } ?>> <?php echo $lang['english']; ?> </a>
                
		        <a class="language-link-item" href="index.php?lang=fr"  <?php if($language == 'fr')
              {?> style="color:#ff9900;" <?php } ?>> <?php echo $lang['french']; ?> </a>
             
            <a class="language-link-item" href="index.php?lang=es"  <?php if($language == 'es')
              {?> style="color:#ff9900;" <?php } ?>> <?php echo $lang['spanish']; ?> </a>
              
         </div>
        </span>
           
    
     <!--END - language div from zumcars-->
      
      <span class="contact_help">
         <a href="<?php echo LINK::Build('help.php');?>" target="_self">
            <?php echo ' | '.$lang['help']; ?>
         </a>
         <a href="<?php echo LINK::Build('contactus.php');?>" target="_self">
            <?php echo ' | '.$lang['contactus'].' |'; ?>
         </a>
      </span> 
    
     
      
     
      <span class="sh_cart">
        <!--Shopping icon display with Number of items in sc-->
          <a href="<?php echo LINK::ToCartDetails($language); ?>" >
            <span id="sc_icon_box">
              <span class="sc_items_number" 
              style="display:inline;"><?php echo $_SESSION['cart_items'];?>
              </span>
                <img src="<?php echo LINK::Build('/images/s-cart-icon.png')?>" alt="shopping cart icon" />
            </span>
            <small> <?php echo $lang['cart']; ?> </small>
          </a> 
      </span>
          
    
 
 <?php
 
 }
 
function display_nav_screen($lang, $search_term='', $category=false)
{
 ?>
    </div>
    
    
    
   
    <div id="navigation">
    
    
 
     <div id="nav_big_screen">
        <ul>
         
            <li id="home_page"><a <?php if(!$category) 
                                            echo 'class="item"';
                                        else 
                                            echo ''; ?> 
               href="<?php echo LINK::Build('index.php');?>" >
                   <?php echo $lang['home'];?></a></li>
        
            <li id = "how_to_order">
             <a  href="<?php echo LINK::Build('how-to-order.php');?>" >
                   <?php echo $lang['how_to_order'];?></a></li>
            
            <li id = "security_safety">
             <a  href="<?php echo LINK::Build('security-safety.php');?>">
                 <?php echo $lang['security_and_safety'];?></a></li>
            
            <li id = "packaging_shipping">
             <a   href="<?php echo LINK::Build('packaging-shipping.php');?>">
                 <?php echo $lang['packaging_and_shipping'];?></a></li>
        
         </ul>
      </div>
      
          <span id="side_menu_btn">
               
            <span class="menu_button"  onclick="openNav()">
              <img src="<?php echo  Link::Build('images/ic_menu_white_36dp.png');?>" alt="menu button" /> 
            </span> 
            
          </span>
          
          <span id="search_box">
            <form method="get" class="search_form" action=<?php echo  Link::Build('search.php'); ?> > 
             <input name="search_term" id="searchInput" type="text"  
                   style="background-image: url(<?php echo  Link::Build('images/ic_search_black_18dp.png');?>); 
                          background-repeat: no-repeat; 
                          background-position: left center; " 
                   
              placeholder="Search" title="Search"  value=<?php echo  '"'.$search_term.'"'; ?>>&nbsp; 
                            
                            
            <input name="search_button"  type="hidden" class="search" value="Search" title="Search"> 
            <input type="submit" class="search_btn" name="search" value="<?php echo $lang['search']; ?>" />
           </form>
          </span>
         
      
      
     <!-- Side navigation menu links --> 
      <div id="main_mySidenav">  
      
        <div  id="mySidenav">
    
          <a  href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
          
          <a  class="item_mobile"  href="<?php echo LINK::Build('index.php');?>"> 
             <?php echo $lang['home']; ?></a>
        
          <a  href="<?php echo $_SERVER['PHP_SELF'].'#categories'; ?>" >
             <?php echo $lang['categories']; ?></a>
            
          <a  href="<?php echo LINK::Build('how-to-order.php'); ?>">
            <?php echo $lang['how_to_order']; ?></a>
            
            
          <a  href="<?php echo LINK::Build('security-safety.php'); ?>">
            <?php echo $lang['security_and_safety']; ?></a>
        
          <a  href="<?php echo LINK::Build('contactus.php'); ?>">
            <?php echo $lang['contactus']; ?></a>
            
          <a  href="<?php echo LINK::Build('packaging-shipping.php'); ?>">
            <?php echo $lang['packaging_and_shipping']; ?></a>
            
          <a  href="<?php echo FACEBOOK_LINK; ?>" target="_blank">
            <?php echo $lang['share_facebook']; ?></a>
            
          <a  href="<?php echo INSTAGRAM_LINK; ?>" target="_blank">
            <?php echo $lang['share_instagram']; ?></a>
            
          <a  href="<?php echo TWITTER_LINK; ?>" target="_blank">
            <?php echo $lang['share_twitter']; ?></a>
            
          <a  href="<?php echo GOOGLEPLUS_LINK; ?>" target="_blank">
            <?php echo $lang['share_g+']; ?></a>
          
         
         
   
         </div>

      
    

   </div>   
    
 <?php
 }
 
 
function display_html_sidebar()
{
 ?>
    </div>
 
 
 
    <div id="sidebar_left">
      
      <!--side bar: Categories of Items  -->
        
 <?php
 }
 
function display_html_content()
{
 ?>  
 
    </div>
    
    
    
    
    <div id="contents">
    

         
            
<?php
}


function display_slide_show($lang){

?>
    <div id="slideshow">
    
     <div>
      <a href="products.php" id="slide_link" target="_self"> 

        <img name="slide" id="slide" src="<?php echo 'slide_images/bugatti-veyron1-revise ME3.png'; ?>"
                      alt="Product Slide Show: Loading..." />
        
      </a>
     
                
          <a href="javascript:void()"  class="slide_left_button" title="Previous"
             id="slidePreviousBtn" onclick="nextImage()"> << </a>
            
          <a href="javascript:void()" class="slide_right_button" title="next"
             id="slideNextBtn" onclick="previousImage()"> >> </a>
          
          <span id="slide_site_url">HighFiveM.COM</span>
          
         <a href="products.php" id="slide_link" target="_self"> 
          <div id ="mydiv">Bugatti veyron1 revise ME3</div>
         </a>  
     </div>
    
                
        
    </div>
       

 <?php
 
}

function display_products_list($mProducts, $mSearchDescription, 
                $mLinkToPreviousPage=null, $mProductListPages=null, 
                $mLinkToNextPage, $lang, $languageSelected, $sku)
{
 

   
 ?>  
     


<p class="separation"></p>


<table class="product-list" >
  <tbody>
  
    <tr>
    
      
    
   <?php 
   
         
     foreach($mProducts as $key=>$value)
     {
       
      echo '<td>';
      echo '<h3 class="product-title" >';
      echo '<a href="'. LINK::ToProduct($key, $languageSelected) .'">';
      echo $value['title'];
      echo '</a>';
      echo '</h3>';
      echo '<p>';
         
          echo '<a href="'. LINK::ToProduct($key, $languageSelected) .'">';
          echo  '<img src="'.LINK::Build('product-images/'.$value['img1']).
               '" alt="'.$value['title'].'" />';
          echo '</a>';
              echo '<p class="description">';
                // if description is greater than a 115 characters trim to 100
                if(strlen($value['desc']) > 115)
                {
                  $value['desc'] = substr($value['desc'], 0, 100). '...';
                   
                }
                
                // if less than 50, add white spaces to fill two lines
                if(strlen($value['desc']) < 80)
                {
                   $numberOfTimes = 80;
                   $value['desc'] = $value['desc']. 
                                       str_repeat('&nbsp;', $numberOfTimes);    
                }
                
                echo $value['desc'];
                
              echo '</p>';     
      echo '</p>';
        echo '<p class="section">';
        echo $lang['price'].': ';
          
            echo '<span class="old-price">'.'$'.$value['dprice'].' '.'</span>';
            echo '<span class="price">'.'$'.$value['price'].'</span>';
          
      echo '</p>';
      
        //Add to cart form or p: query strings for each product 
      echo '<p class="add-product-form">';
      
        echo '<a class="item" href="'.
                       LINK::ToAddProduct($key, $key, $languageSelected).'" >'.
                    $lang['add_to_cart'].
             '</a>';

     
      echo '</p>';
     

     
    echo '</td>';
    
   
  }
  

 ?>
       
       </tr>
    
   </tbody> 
</table> 

<!-- Display products page numbers-->

<p>

  <span>Pages:</span>&nbsp;  
  
  <?php
  
    for($i=0; $i < $mProductListPages; $i++)
    {
      //create page numbers....
    
    }
   ?>
    
 
       <a href="<?php echo $mLinkToNextPage; ?>">
                      <?php echo $lang['next_page'];  ?></a>
  
  
</p>

<!--HOW highfivem works -->
    <hr class="thin_line" /> 
   <p class="how_it_works"><b> <?php echo $lang['how-it-works-p1']; ?> 
               As simple as ABC:</b></p>
      
       <div class="works_container">
         
         <p class="works_footer_item"><span class="ranking_footer">A</span> 
            <?php echo $lang['how-it-works-p1']; ?>
        </p>
        <p class="works_footer_item"><span class="ranking_footer">B</span> 
            <?php echo $lang['how-it-works-p2']; ?>
        </p>
        <p class="works_footer_item"><span class="ranking_footer">C</span> 
            <?php echo $lang['how-it-works-p3']; ?>
          <br />
          <span class="social_media_footer"> 
          
          <a href="<?php echo FACEBOOK_LINK; ?>" title="Share on faceboook" target="_blank">
                      <img src="images/ico-fb.png" alt="facebook-footer button" /></a>
           <a href="<?php echo TWITTER_LINK; ?>" title="share of twitter" target="_blank"> 
                      <img src="images/ico-tw.png" alt="twitter-footer-button" /></a>
           <a href="<?php echo INSTAGRAM_LINK; ?>" title="share of Instagram" target="_blank"> 
               <img src="images/instagram.png" alt="Instagram button" /></a>
           </span>
           
           
        </p> 
      </div>     
            
<?php
}

function display_html_ads($lang)
{
 ?>   
     </div>
     
        
     
    <div id="sidebar_right">
      <?php echo $lang['advertisement']; ?>
 <?php
 }
 
 function display_html_footer($terms, $privacy, $aboutus, $sitemap, $news, $tel,
                              $help)
 {
   
  ?>   
  
    </div>
   
   <!-- 
    <div class="separation">separation</div>
    -->
    
    
    <div id="footer">
   
   
      <p class="terms_privacy">
        <a href="<?php echo LINK::Build('terms-conditions.php'); ?>" 
            target="_blank"> <?php echo $terms; ?></a> 
      | <a href="<?php echo LINK::Build('privacy-policy.php'); ?>" 
            target="_blank"> <?php echo $privacy; ?></a> 
      | <a href="<?php echo LINK::Build('aboutus.php'); ?>" 
            target="_blank"> <?php echo $aboutus; ?> </a>  
      | <a href="<?php echo LINK::Build('sitemap.php'); ?>" 
           target="_blank"> <?php echo $sitemap; ?> </a> 
      | <a href="<?php echo LINK::Build('news.php'); ?>" 
           target="_blank"><?php echo $news; ?></a>| <br />
      | <a href="tel://+237673301819" target="_blank"><?php echo $tel; ?></a> 
      | <a href="<?php echo LINK::Build('forum.php'); ?>" 
           target="_blank"><?php echo $help; ?></a> 
 
    </p>
    
     <p class="copyright"> Copyright © 2017, wwww.highfivem.com</p>
     
   </div>
        
 </div>
 

<?php
} 

function display_category_list($total_records, $productCatLinks, 
                          $language, $lang, $category=false, $categoryId=null)
{
 ?>
 
 <?php
 
   
  // if records exist
  if ($total_records > 0)
  {
        
     // Array function sizeof() is used to find the number of results return
    echo '<br />';
    echo '<div class="box">';
    echo '<p class="box-title">'. $lang['select_category'] . '<br />'.
         '</p>';
    echo  '<ul>';
    
    // loop repeats only twice for 302 and 303 categories
    for($i=1; $i <= $total_records; $i++)
    {
     echo   '<li>';
     $indexCat = 300 + $i; 
    
     //Generate a link for each result     
     echo '<a href="'. Link::ToCategory($productCatLinks["$indexCat"], 
            $language).'" ';
           if(($category == true) && ($indexCat == $categoryId)) 
                  echo 'class="item" ';
           else 
                  echo '';  
     echo  '>';
     echo $lang['cat30'.$i];
     echo $total_records;
     echo   '</a>';
     echo '</li>';
        
    }
    
    echo '</ul></div>';  
  } 
  
 }
 
function display_cart_summary($total, $totalFrs, $items, $language, $lang)
                          
{
 ?>
  <br />
  <div class="box" id="cart-summary">
    <p class="box-title"><?php echo $lang['cart_summary']; ?></p>
    
    <div id="updating">Updating...</div>
    
    <?php
    if($items == 0)          
    {?>
      <p class="empty-cart"><?php echo $lang['sc_empty']; ?></p>
    <?php
    }
    else{
      
     echo '<table class="cart-summary">';
     echo '<tbody>';
      
         echo '<tr>';
           echo '<td  valign="top" class="cart-summary-subtotal">';
                echo $lang['total_items'].' :  ';
           echo '</td>';
            echo '<td class="cart-summary-subtotal">';
                echo $items;
           echo '</td>';
         echo '</tr>';
          
         echo '<tr>';
         echo    '<td colspan="2" class="cart-summary-subtotal">';
         echo      '<span class="total_amount"><b>'. $lang['total_cost'].' :    '.
                    '</b></span>';  
         echo      '<span class="price">&nbsp;&nbsp;'.'  $'.sprintf("%0.2f", $total).'<br />'.
                      ' (' .sprintf("%0.2f", $totalFrs). 'FCFA) </span><br />';
         echo      '<span>';
         echo       '[ <a href="'.LINK::ToCartDetails($language).'">'.
                     $lang['view_cart_details'].
                     '</a>]';
         echo      '</span>';
         echo    '</td>';
         echo '</tr>';
         echo '<tbody>';
         echo '</table>'; 
                  
    }
    
    
?>
   </div>

<?php  
 }
 
function display_html_header_adm($lang, $language, $languageSelectTitle)
{

?>
   <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html>
 
   <head>
   
     <title><?php echo $lang['title'] ?></title>
   
     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
     <meta charset="UTF-8" />

     <meta name="viewport" content="width=device-width, initial-scale=1.0" />

 
    <link rel="icon" type="image/png" href=<?php echo Link::Build('images/favicon.png'); ?> />
  
  
  
    <script src=<?php echo Link::Build('scripts/css3-mediaqueries.min.js'); ?>></script>



  
   <link rel="stylesheet" media="screen and (max-width: 600px)" href=<?php echo Link::Build('styles/highfivem_mobile.css'); ?> />
   <link rel="stylesheet" media="screen and (min-width: 600px)" href=<?php echo Link::Build('styles/highfivem.css'); ?> />
  
   
   <script type="text/javascript" src=<?php echo Link::Build('scripts/sidemenu.js'); ?>></script> 
   <script type="text/javascript" src=<?php echo Link::Build('scripts/language.js'); ?>></script>
   
    
   
  
   
  </head>
  
  
 <body>
     
   <div id="main">
    
    
     <div id="header">
    
      <span class="logo_span">
       <h1 class="logo"><a href="index.html" target="_self">
              <img src="<?php echo LINK::Build('images/logo.png');?>" alt="High Five Marijuana Shop logo" />
            </a></h1>
      </span>
      
      <span class="tel_email_span">
          <span>
            <a href="tel:+12053456441" target="_self">
              <img src="<?php echo LINK::Build('images/ic_call_black_18dp.png');?>" alt="High Five Marijuana Shop logo" />
              <?php echo $lang['tel']; ?>
            </a>
          </span>&nbsp;
            
            <span>
             <a href="mailto:info@highfivem.com" target="_self">
               <img src="<?php echo LINK::Build('images/ic_email_white_18dp.png');?>" alt="High Five Marijuana Shop logo" />
               <?php echo $lang['email_invite']; ?>
              </a>
            </span>
      </span>
      
      
      
      
     <!--START - language div from zumcars-->
       <!--Language div and buttons below --> 
       <span class="languagebtn"> 
         
         
         
         <!-- Button for Changing language-display different btns depending on selected language-->
         
           <a  href="javascript:void(0)" class="languagebtn" onclick="openLang()">
             
             <?php 
              if($language == 'en'){
              ?>
               
              <img src="images/english-icon.png" alt="en" /> 
              
              <?php 
              } 
              ?>
               <?php 
              if($language == 'fr'){
              ?>
               
              <img src="images/french-icon.png" alt="fr" /> 
              
              <?php 
              } 
              ?>
               <?php 
              if($language == 'es'){
              ?>
               
              <img src="images/spanish-icon.png" alt="en" /> 
              
              <?php 
              } 
              ?>
                    
                    
           </a>
           
           
            <div id="lang_header_form"> 
             
              <a  href="javascript:void(0)" class="closebtn" onclick="closeLang()">
                    &times;</a>
          
              
            <a class="language-link-item" href="index.php?lang=en" <?php if($language == 'en')
              {?> style="color:#ff9900;" <?php } ?>> <?php echo $lang['english']; ?> </a>
                
		        <a class="language-link-item" href="index.php?lang=fr"  <?php if($language == 'fr')
              {?> style="color:#ff9900;" <?php } ?>> <?php echo $lang['french']; ?> </a>
             
            <a class="language-link-item" href="index.php?lang=es"  <?php if($language == 'es')
              {?> style="color:#ff9900;" <?php } ?>> <?php echo $lang['spanish']; ?> </a>
              
         </div>
        </span>
           
    
     <!--END - language div from zumcars-->
      
      <span class="contact_help">
         <a href="<?php echo LINK::Build('help.php');?>" target="_self">
            <?php echo ' | '.$lang['help']; ?>
         </a>
         <a href="<?php echo LINK::Build('contactus.php');?>" target="_self">
            <?php echo ' | '.$lang['contactus'].' |'; ?>
         </a>
          <a href="<?php echo LINK::Build('admin/logout.php');?>" target="_self">
           logout
         </a>
         
         
      </span> 
    
          
    
 
 <?php
 
 }

  
?>