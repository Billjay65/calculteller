<?php

 // start session
session_start();


 
 // include config file containing directory paths
 require_once 'C:/Users/JAY.V/Desktop/highfiveroot/include/config.php';
 
 // include error handling class php file
 require_once SITE_ROOT.'error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'highfivem_fns.php';
 
// Get web browser language of User 
// get first value(Primary Language) from language array
 $browserLanguage = $_SERVER['HTTP_ACCEPT_LANGUAGE'][0] 
                      . $_SERVER['HTTP_ACCEPT_LANGUAGE'][1];
                      
  // Create session variable to store selected language
  $userLanguage = (!isset($_SESSION['language']))? '' : $_SESSION['language'] ;
 

  // Get selected language of page 
  // include language configuration file based on selected language
	$language = "en";
  
  // read browser language Only when user language SESSION variable
  // is NOT SET(equals ''), if userLanguage is set, do not use browser language
  if((!empty($browserLanguage)) && ($browserLanguage == 'en' ||
       $browserLanguage == 'fr' || $browserLanguage == 'es')
      && ($userLanguage =='')){
    $language = $browserLanguage;
      
  }
  
	if(isset($_GET['lang'])){ 
		$language = $_GET['lang'];
    $_SESSION['language'] = $language;
     
	} 
 
   
  
	require_once(SITE_ROOT."values/".$language.".php");
  
  
// look for catalog file based on Choosen Language
$catalogFile = 'C:/Users/JAY.V/Desktop/highfiveroot/catalog-'. $language. '.dat';

// get item to Add to  shopping cart 
 if(isset($_GET['addProduct']))
      $itemToAdd = $_GET['addProduct'];
 else
     $itemToAdd = 0;

      
      

/***Shopping Cart: Add to Cart functions and Code***/
// initialize session shopping cart
if(!isset($_SESSION['cart']))
{
   $_SESSION['cart'] = array();
   
}

// initialize shopping cart number of items to zero  if it is Not set
// before calculating it below
 $_SESSION['cart_items'] = (!isset($_SESSION['cart_items']))? 0 : 
                                                $_SESSION['cart_items'];
                                                
// initialize a variable to hold total cost
$total = 0;
$totalFrs = 0;
      

// check to see if the form has been submitted
// and which submit button was clicked
// if this is an add operation
// add to already existing quantities in shopping cart
if ($itemToAdd > 0)
{
    // which submit btn has been clicked (choosen product)
    $productId = (int)$itemToAdd;
    
  
   // initialize shopping cart number of items to zero before calculating it below
   $_SESSION['cart_items'] = (int) 0;
               
      
           
    // create session variables for the selected item with its 
    // quantity set to 1 if its quantity is zero(0) 
    // or add 1 to its existing quantity if its seesion variable
    // isset , this means it contains 1
    if(!isset($_SESSION['cart'][$productId])) 
        $_SESSION['cart'][$productId] =  (int) 1;
    else
       $_SESSION['cart'][$productId] +=  $_SESSION['cart'][$productId];
       
    
    
     // calculating the total number of items in the shopping cart using 
     // $_SESSION['cart'] variable
    if(isset($_SESSION['cart']))
    {
      foreach ($_SESSION['cart'] as $k => $v)
      {
        // if the value is 0 or negative
        // don't bother changing the cart
        if ($v > 0)
        { 
             /* Each time cart_infor.php is called by clicking add to cart or 
             any other button, calculate the number of items in the shopping cart*/  
           $_SESSION['cart_items'] += (int) 1;
        }
     }    
   }
   
  
}


//echo $_POST['a_qty'][102]. '<br />';

//echo $_SESSION['cart_items'];

/***End of SC: Add to Cart code***/




/***CREATING CATALOG AND LINKS***/
  // variables to use in any script containing product_list
  // variables for pagination and more
  $mPage = 1;
  
  // categories start with 301, hence test change starting with this value
  $previousCategory = 301;
  
  // totalPages equals total number of categories in catalog
  $mrTotalPages = 1;
  $mLinkToNextPage;
  $mLinkToPreviousPage;
  $mProductListPages = array();
  $mProducts;
  $mSearchDescription;
  $mSearchString;
  $mEditActionTarget;
  $mShowEditButton;

  // category variable
  $mCategoryId;
  $productCatLinks = array('301'=>'americancush', // folder: americancush/index.php,
                           '302'=>'blackmarijuana', // folder: blackmarijuana/index.php
                           '303'=>'havercush');   // folder: havercush/index.php

  // Save page request for continue shopping functionality
  $_SESSION['link_to_continue_shopping'] = $_SERVER['QUERY_STRING'];


// file is available, extract data from it
// place into $CATALOG array, with SKU as key
if(file_exists($catalogFile))
{
    // read data from dat file using built in file()
    $data = file($catalogFile);
    
    foreach($data as $line)
    {
       $lineArray = explode(':', $line);
       $sku = trim($lineArray[0]);
       
       // determine the total number of pages (total number of categories)
       
       if(trim($lineArray[7]) != $previousCategory)
           $mrTotalPages++;
           
      
       $CATALOG[$sku]['title']  = trim($lineArray[1]);
       $CATALOG[$sku]['price']  = trim($lineArray[2]);
       $CATALOG[$sku]['dprice'] = trim($lineArray[3]);
       $CATALOG[$sku]['desc']   = trim($lineArray[4]);
       $CATALOG[$sku]['img1']   = trim($lineArray[5]);
       $CATALOG[$sku]['img2']   = trim($lineArray[6]);
       $CATALOG[$sku]['cat']    = trim($lineArray[7]);
       
       // store the current category in a Global variable and use the 
       // value in the next iteration to count the number of categories
       $previousCategory = $CATALOG[$sku]['cat'];
             
    }
    
     
    

}

// file is not available
// stop immediately with an error
else
{
   //log or email Technical Error message
   // log("Could not find catalog file");
   // mail($to, $from, $message....)
   
   // display user friendly error message and exit
   die('<b>Application Error:</b> An Internal Error occurred!<br />
        Please try again later! ');

}

   

    // Save page request for continue shopping functionality
    $_SESSION['link_to_continue_shopping'] = $_SERVER['QUERY_STRING'];
    
    
    
    
     // If there are subpages of products, display navigation
     //controls
    if ($mrTotalPages > 1 && $mrTotalPages == count($productCatLinks))
    {
      // Build the Next link
      if ($mPage < $mrTotalPages)
      {
        /*
        if (isset($_GET['SearchResults']))
          $mLinkToNextPage =
            Link::ToSearchResults($mSearchString, 
                                        $mPage + 1);
        */
        // create links to next category page
              $mLinkToNextPage =
            Link::ToCategory($productCatLinks['301'], $language);
        
        // link to home page category 301
        //  $mLinkToNextPage = Link::ToIndex($language);
      }

      // Build the Previous link
      if ($mPage > 1)
      {
         // index, page 1 has no previous page link
        /*
        if (isset($_GET['SearchResults']))
             $mLinkToPreviousPage =
               Link::ToSearchResults($mSearchString, $mPage - 1);
       
          $mLinkToPreviousPage = Link::ToIndex($language);
       */
      }

      // Build the pages links
      for ($i = 1; $i <= $mrTotalPages; $i++)
        if (isset($_GET['SearchResults']))
           $mProductListPages[] =
            Link::ToSearchResults($mSearchString, $i);
        // build links to categories pages
           $mProductListPages[] =
              Link::ToCategory($productCatLinks['302'], $mPage + 1, 
                          $language, $lang);
       
        // link to home page category 301
          $mProductListPages[] = Link::ToIndex($language);
    }
    else{
        // display user friendly error
        /*DELETE CODE BELOW AND LOG ERROR TO FILE*/
        echo '<b>Error</b>: verify that product Categories match total number
              of pages';
    
    }
    
/***END of  CATALOG functions and links***/

    
  if(isset($_SESSION['cart']) && (count($_SESSION['cart'])>0)) 
 { 
     // get and shopping cart items and 
    // Calculate the Total Cost
        foreach ($_SESSION['cart'] as $k => $v)
        {
          // only display items that have been selected
          // that is, quantities > 0
          if ($v > 0)
          {
            $subtotal = $v * $CATALOG[$k]['price'];
            $total += $subtotal;
            $totalFrs = $total * 620;
            // no need for line below since user cannot add items 
            // to cart on this page, user can only remove items from cart
            //$_SESSION['cart_items'] += 1; 

         }
       }
  }       



 // Call the home page to display html content on screen
 display_html_header($lang, $language, $lang['select_lang']);
  
  
 
 display_nav_screen($lang);
 
 display_html_sidebar();
 
 display_category_list($mrTotalPages, $productCatLinks, $language, $lang);
 
 display_cart_summary($total, $totalFrs,  $_SESSION['cart_items'], 
                         $language, $lang);

 
 display_html_content();
 
  
 
 display_slide_show($lang);
 
 
 
 
 /*
 display_products_list($mProducts, $mSearchDescription=null, 
                $mLinkToPreviousPage=null, $mProductListPages=null, 
                $mLinkToNextPage = null, $lang, $languageSelected) */
 
 display_products_list($CATALOG, $lang['cat301'], null, null,  $mLinkToNextPage, 
                        $lang, $language, $sku);

 display_html_ads($lang);
  
 display_html_footer($lang['terms_conditions'], $lang['privacy_policy'],
                   $lang['about_us'], $lang['sitemap'], $lang['news'],
                    $lang['tel'], $lang['help']);
?>

<script type="text/javascript"> 

var i = 0; 
var image = new Array();   
// LIST OF IMAGES 
image[0] = "slide_images/black-cush.png"; 
image[1] = "slide_images/havercush.png"; 
image[2] = "slide_images/high-marijuana.png"; 
image[3] = "slide_images/indian-marijuana.png";
image[4] = "slide_images/white-marijuana.png";
 
var k = image.length-1;    
var caption = new Array(); 
// LIST OF CAPTIONS  
caption[0] = "Black Cush"; 
caption[1] = "Havercush"; 
caption[2] = "High Marijuana"; 
caption[3] = "Indian Marijuana"; 
caption[4] = "Wite Marijuana"; 


// get next and previous buttons and add
// onclick event handlers for next and previous
// images in slideshow
var slideNextBtn = document.getElementById("slideNextBtn");  
var slidePreviousBtn= document.getElementById("slidePreviousBtn");

function nextImage(){
   i++;
   return false;
}

function previousImage(){ 
   i--;
   return false;
} 
 

function swapImage(){ 
  var el = document.getElementById("mydiv");
  
  var img= document.getElementById("slide");
  
   if((caption[i]=='undefined') && (el=='undefined')
      && (el.innerHTML=='undefined') && (img.src=='undefined'))
   {
      el.innerHTML='Bugatti';
    
     img.src= "slide_images/bugatti-veyron1-revise ME3.png";  
   }
   
    el.innerHTML=caption[i];
    
     img.src= image[i];  
 
 
 if(i < k ) { i++;}  
 else { i = 0; } 
 setTimeout("swapImage()", 2000);  
} 
function addLoadEvent(func) { 
 var oldonload = window.onload; 
  if (typeof window.onload != 'function') { 
    window.onload = func; 
  } 
  else { 
     window.onload = function() { 
     if (oldonload!='undefined') { 
       oldonload(); 
    } 
   func();}
 }
}  
addLoadEvent(function() { 
swapImage(); });  
</script>


  <!--Colored menu links script-->
       <script>
            var anchorArr = document.getElementsByTagName("a");
            
            
            for(var i=0; i<anchorArr.length; i++)
            {
              
              if(anchorArr[i].className=="item")
              {   
                
                
                     anchorArr[i].className="selected";
                      
                
              }
              
               else if(anchorArr[i].className=="item_mobile")
               {
                  
                     anchorArr[i].className = "selected_mobile";
                    
               }
            }
        </script>       

<!-- closing body an html tags-->
  </body>
</html>