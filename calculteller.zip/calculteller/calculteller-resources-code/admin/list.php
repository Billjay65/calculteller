<html>
<head></head>
<body>
<!-- standard page header -->
<?php
// includes
include('C:/Program Files/Apache Software Foundation/Apache2.2/htdocs/news/conf.php');
include('C:/Program Files/Apache Software Foundation/Apache2.2/htdocs/news/functions.php');
// open database connection
$connection = mysql_connect($host, $user, $pass) 
or die ('Unable to connect!');
// select database
mysql_select_db($db) or die ('Unable to select database!');
// generate and execute query
$query = "SELECT id, title, timestamp FROM news ORDER BY timestamp 
DESC";
$result = mysql_query($query) 
or die ("Error in query: $query. " . mysql_error());
// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
      ?>
      <font size="-1"><b><?php echo $row->title; ?></b> 
      [<?php echo formatDate($row->timestamp); ?>]</font>
      <br>
      <font size="-2"><a href="edit.php?id=<?php echo $row->id; ?>">
      edit</a> | <a href="delete.php?id=<?php echo $row->id; ?>">
      delete</a></font>
      <p>
      <?php
      }
}
// if no records present
// display message
else
{
?>
      <font size="-1">No releases currently available</font><p>
<?php
}
// close connection
mysql_close($connection);
?>
<font size="-2"><a href="add.php">add new</a></font>
<!-- standard page footer -->
</body>
</html>