<html>
<head></head>
<body>
<!-- standard page header -->
<?php
// includes
include('C:/Program Files/Apache Software Foundation/Apache2.2/htdocs/news/conf.php');
include('C:/Program Files/Apache Software Foundation/Apache2.2/htdocs/news/functions.php');
// check for record ID
if ((!isset($_GET['id']) || trim($_GET['id']) == '')) 
{ 
    die('Missing record ID!'); 
}
// open database connection
$connection = mysql_connect($host, $user, $pass) 
or die ('Unable to connect!');
// select database
mysql_select_db($db) or die ('Unable to select database!');
// generate and execute query
$id = $_GET['id'];
$query = "DELETE FROM news WHERE id = '$id'";
$result = mysql_query($query) 
or die ("Error in query: $query. " . mysql_error());
// close database connection
mysql_close($connection);
// print result
echo '<font size=-1>Deletion successful.';
echo '<a href=list.php>Go back to the main menu</a>.</font>';
?>
<!-- standard page footer -->
</body>
</html>