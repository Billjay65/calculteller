<html>
<head></head>
<body>
<!-- standard page header -->
<?php
// includes
include('C:/Program Files/Apache Software Foundation/Apache2.2/htdocs/news/conf.php');
include('C:/Program Files/Apache Software Foundation/Apache2.2/htdocs/news/functions.php');
// form not yet submitted
// display initial form with values pre-filled
if (!$_POST['submit'])
{
     // check for record ID
     if ((!isset($_GET['id']) || trim($_GET['id']) == '')) 
     { 
         die('Missing record ID!'); 
     }
    // open database connection
    $connection = mysql_connect($host, $user, $pass) 
or die ('Unable to connect!');
    // select database
    mysql_select_db($db) or die ('Unable to select database!');
    // generate and execute query
    $id = $_GET['id'];
    $query = "SELECT title, content, contact FROM news 
WHERE id = '$id'";
    $result = mysql_query($query) 
or die ("Error in query: $query. " . mysql_error());
    
    // if a result is returned
    if (mysql_num_rows($result) > 0)
    {
        // turn it into an object
        $row = mysql_fetch_object($result);
        // print form with values pre-filled
?>
<table cellspacing="5" cellpadding="5">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<input type="hidden" name="id"  value="<?php echo $id; ?>">
<tr>
    <td valign="top"><b><font size="-1">Title</font></b></td>
    <td>
      <input size="50" maxlength="250" type="text" name="title" 
value="<?php echo $row->title; ?>">
    </td>
</tr>
<tr>
    <td valign="top"><b><font size="-1">Content</font></b></td>
    <td>
      <textarea name="content" cols="40" rows="10">
      <?php echo $row->content; ?>
      </textarea>
    </td>
</tr>
<tr>
    <td valign="top"><font size="-1">Contact person</font></td>
    <td>
      <input size="50" maxlength="250" type="text" name="contact"
      value="<?php echo $row->contact; ?>">
    </td>
</tr>
<tr>
    <td colspan=2>
      <input type="Submit" name="submit" value="Update">
    </td>
</tr>
</form>
</table>
<?php
    }
    // no result returned
    // print graceful error message
    else
    {
        echo '<font size=-1>That press release could not be located 
in our database.</font>';
    }
}
else
{
    // set up error list array
    $errorList = array();
    
    $title = $_POST['title'];
    $content = $_POST['content'];
    $contact = $_POST['contact'];
    $id = $_POST['id'];
        
    // check for record ID
    if ((!isset($_POST['id']) || trim($_POST['id']) == '')) 
    { 
      die ('Missing record ID!'); 
    }
    // validate text input fields
    if (trim($_POST['title']) == '') 
    { 
      $errorList[] = 'Invalid entry: Title'; 
    }
    
    if (trim($_POST['content']) == '') 
    { 
      $errorList[] = "Invalid entry: Content"; 
    }
    
    // set default value for contact person
    if (trim($_POST['contact']) == '') 
    { 
      $contact = $def_contact; 
    }
    
    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) 
or die ('Unable to connect!');
        // select database
        mysql_select_db($db) 
or die ('Unable to select database!');
        // generate and execute query
        $query = "UPDATE news SET title = '$title', 
content = '$content', contact = '$contact', timestamp = NOW() 
WHERE id = '$id'";
        $result = mysql_query($query) 
or die ("Error in query: $query. " . mysql_error());
        // print result
        echo '<font size=-1>Update successful.';
        echo '<a href=list.php>Go back to the main menu</a>.</font>';
        // close database connection
        mysql_close($connection);
    }
    else
    {
        // errors occurred
        // print as list
        echo '<font size=-1>The following errors were encountered:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        {
            echo "<li>$errorList[$x]";
        }
        echo '</ul></font>';
    }
}
?>
<!-- standard page footer -->
</body>
</html>