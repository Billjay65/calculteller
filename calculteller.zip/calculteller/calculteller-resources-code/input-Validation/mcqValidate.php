<html>
<head>
<basefont face="Arial">
</head>
<body>
<?php
if (!$_POST['submit'])
{
      // form not submitted
?>
 <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
 Username: 
 <br />
 <input type="text" name="username">
 <p />
 Password: 
 <br />
 <input type="password" name="password">
 <p />
 Date of Birth:
 <br />
 Month <input type="text" name="month" size="2"> 
 Day <input type="text" name="day" size="2"> 
 Year <input type="text" name="year" size="4">
 <p />
 Hobbies (select at least <b>three</b>): 
 <br />
 <input type="checkbox" name="hobbies[]" value="Sports">Sports 
 <input type="checkbox" name="hobbies[]" value="Reading">Reading 
 <input type="checkbox" name="hobbies[]" value="Travel">Travel
 <input type="checkbox" name="hobbies[]" value="Television">Television
 <input type="checkbox" name="hobbies[]" value="Cooking">Cooking
 <p />
 Subscriptions (Select at least <b>two</b>):
 <br />
 <select name="subscriptions[]" multiple> 
 <option value="General">General Newsletter</option>
 <option value="Members">Members Newsletter</option>
 <option value="Premium">Premium Newsletter</option>
 </select>
 <p />
 <input type="submit" name="submit" value="Sign Up">
 </form>
<?php
}
else
{
 // form submitted
                 
 // validate "username", "password" and "date of birth" fields
 $username = (!isset($_POST['username']) || 
trim($_POST['username']) == "") 
? die ('ERROR: Enter a username') : trim($_POST['username']);
 $password = (!isset($_POST['password']) 
|| trim($_POST['password'] == "")) 
? die ('ERROR: Enter a password') : trim($_POST['password']); 
 if (!checkdate($_POST['month'], $_POST['day'], $_POST['year'])) 
 { 
    die ('ERROR: Enter a valid date'); 
 }
 // check the "hobbies" field for valid values
 $hobbies = ((sizeof($_POST['hobbies']) < 3) ?  
die ('ERROR: Please select at least 3 hobbies') : 
implode(',', $_POST['hobbies']));
      
 // check the "subscriptions" field for valid values
 $subscriptions = ((sizeof($_POST['subscriptions']) < 2) ?  
die ('ERROR: Please select at least 2 subscriptions') : 
implode(',', $_POST['subscriptions']));      
      
 // connect to database
 // save record
}
?>
</body>
</html>