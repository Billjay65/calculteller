<?php 
// attempt database connection
$mysqli = new mysqli("localhost", "root", "Sikehjaphetberyuf12", "music"); 
echo 'successful'; 
?>