<html>
<head>
<basefont face="Arial">
</head>
<body>
<?php
if (!$_POST['submit'])
{
      // form not submitted
?>
      <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
      Username: 
      <br />
      <input type="text" name="username">
      <p />
      Password: 
      <br />
      <input type="password" name="password">
      <p />
      Email address: 
      <br />
      <input type="text" name="email">
      <p />
      <input type="submit" name="submit" value="Sign Up">
      </form>
<?php
}
else
{
      // form submitted           
      
      // validate "username", "password" and "email" fields 
      // using regular expressions
      $username = (!isset($_POST['username']) || 
!ereg('^([a-zA-Z]){3,8}$', $_POST['username'])) ? 
die ('ERROR: Enter valid username') : 
mysql_escape_string(trim($_POST['username']));
      
      $password = (!isset($_POST['password']) || 
!ereg('^([a-z0-9]){5,8}$', $_POST['password'])) ? 
die ('ERROR: Enter valid password') : 
mysql_escape_string(trim($_POST['password']));
      
      $email = (!isset($_POST['email']) || 
!ereg('^([a-zA-Z0-9_-]+)@([a-zA-Z0-9_-]+) 
(\.[a-zA-Z0-9_-]+)+$', $_POST['email'])) ? 
die ('ERROR: Enter valid email address') : 
mysql_escape_string(trim($_POST['email']));
      // connect to database
      // save record      
}
?>
</body>
</html>