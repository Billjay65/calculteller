<html>
<head>
<basefont face="Arial">
</head>
<body>
<?php
if (!$_POST['submit'])
{
      // form not submitted
?>
      <form action="formValidation1.php" method="post">
      Item name: 
      <br />
      <input type="text" name="itemName">
      <br />
      Item sale price:       
      <br />
      <input type="text" name="itemSPrice"> 
      <br />
      Item cost price:
      <br />
      <input type="text" name="itemCPrice">  
      <br />
      Item quantity: 
      <br />
      <input type="text" name="itemQuantity">
      <br/><br/>
      <input type="submit" name="submit" value="Enter Data">
      </form>
<?php
}
else
{
      // form submitted
                                      
      // check the itemName field
      $itemName = (!isset($_POST['itemName']) || trim($_POST['itemName']) == "") 
? die ('ERROR: Enter the item name') : mysql_escape_string(trim($_POST['itemName']));
    
      // check the itemSPrice field
      if(!isset($_POST['itemSPrice']) || trim($_POST['itemSPrice']) == "")
      {
        die ('ERROR: Enter the item\'s selling price'); 
      } 
      elseif(!is_numeric(trim($_POST['itemSPrice']))) 
      { 
        die ('ERROR: Enter numeric value for the item\'s selling price');
      } 
      else 
      {    
        $itemPrice = floatval(trim($_POST['itemSPrice']));
      }                  
      
      // check the itemCPrice field
      if(!isset($_POST['itemCPrice']) || trim($_POST['itemCPrice']) == "")
      {
        die ('ERROR: Enter the item\'s cost price'); 
      } 
      elseif (!is_numeric(trim($_POST['itemCPrice']))) 
      {
        die ('ERROR: Enter numeric value for the item\'s cost price');
      } 
      else 
      { 
        $itemCost = floatval(trim($_POST['itemCPrice']));
      }        
            // check the itemQuantity field
      if(!isset($_POST['itemQuantity']) || trim($_POST['itemQuantity']) == "") 
      { 
            die ('ERROR: Enter the quantity');
      }
      elseif (!is_numeric(trim($_POST['itemQuantity'])))  
      { 
            die ('ERROR: Enter numeric value for quantity');
      } 
      else 
      {
            $itemQuantity = intval(trim($_POST['itemQuantity']));
      }              
      // connect to database
      // save record
}
?>
</body>
</html>