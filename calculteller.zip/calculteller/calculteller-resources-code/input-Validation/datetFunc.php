<?php
//output 1491215647
echo mktime(). '<br/>';

//output
echo date("d F Y", mktime());

//output
echo date("h: l i a d M Y", mktime());
?>