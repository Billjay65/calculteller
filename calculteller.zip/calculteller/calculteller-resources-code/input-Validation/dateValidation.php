<html>
<head>
<basefont face="Arial">
</head>
<body>
<?php
if (!$_POST['submit'])
{
      // form not submitted
?>
      <form action="dateValidation.php" method="post">
      Day <input type="text" name="day" size="2"> 
      Month <input type="text" name="month" size="2">  
      Year <input type="text" name="year" size="2"> 
      <br />
      <input type="submit" name="submit" value="Check">
      </form>
<?php
}
else
{
      // form submitted
      
      // check date
      if (!checkdate($_POST['month'], $_POST['day'], $_POST['year'])) 
      { 
        die ('ERROR: Enter a valid date'); 
      }
}
?>
</body>
</html>