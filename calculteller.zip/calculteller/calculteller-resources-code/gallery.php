

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
   "DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 
  <head> 
    <title>Project 6-2: Creating An Image Gallery</title> 
  </head> 
  <style type="text/css"> 
  ul { 
        list-style-type: none; 
  } 
 
  li { 
      float: left; 
      padding: 10px; 
      margin: 10px; 
      font: bold 10px Verdana, sans-serif; 
  } 
 
  img { 
      display: block; 
      border: 1px solid #333300; 
      margin-bottom: 5px; 
      } 
  </style> 
  <body> 
  


function home_domain_image_links()
{
?>
   
<?php 

  $image_string = 'images/'. $domain_image;  

   echo '<ul>'' ;
 
    // iterate over domain images 
    // display each image as a link to that domain
 
    for($i=0; $i < sizeof($result); $i++)
    {
     echo   '<li>';
     
     /* If DomainId  exists in the query string, we're visiting a
       domain */
    if (isset ($_GET['domain_id']))
      $selectedDomain = (int)$_GET['domain_id'];

    if ($selectedDomain == $result[$i]['domain_id'])
     $selected = 'class="selected"';
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomain($result[$i]['name'], $result[$i]['domain_id']). ">";
     
     // display image link for each domain
      
     echo '<img src='.Link::Build($image_string). 'alt="domain-image" width="200px" height="150" />';
     
     echo '<p>'.$result[$i]['name'].'</p>';
     echo   '</a>';
     echo '</li>';
    }
  echo '</ul>';

?> 
<?php
}
    </ul> 
  </body> 
</html>



for($i=0; $i < sizeof($result); $i++)
    {
     echo   '<li>';
     
     /* If DomainId  exists in the query string, we're visiting a
       domain */
    if (isset ($_GET['domain_id']))
      $selectedDomain = (int)$_GET['domain_id'];

    if ($selectedDomain == $result[$i]['domain_id'])
     $selected = 'class="selected"';
     
     //Generate a link for each result     
     echo "<a ".$selected." href=". Link::ToDomain($result[$i]['name'], $result[$i]['domain_id']). ">";
     
     // display image link for each domain
      
     echo '<img src='.Link::Build($image_string). 'alt="domain-image" width="200px" height="150" />';
     
     echo '<p>'.$result[$i]['name'].'</p>';
     echo   '</a>';
     echo '</li>';
    }