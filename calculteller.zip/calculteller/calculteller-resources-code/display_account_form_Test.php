<html>
<head></head> 
<body>
<table>
  <form id="display_account_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"> 
   <tr>
     <td colspan="2">
       <h3>New Account</h3>
     </td>
   </tr>
   
   <tr>
     <td>
       <label> Name:</label> 
     </td>
     <td>
       <input type="text" name="$details['realname']" size="32" maxlength="50" 
          value="<?php
                         ?>"  />
        
     </td> 
   </tr>
   
   <tr>
     <td>
       <label>Email Address:</label> 
     </td>
     <td>
       <input type="text" name="$details['email']" size="32" maxlength="100" 
          value="<?php
                         ?>"  />
        
     </td> 
   </tr>
   
  
   
   <tr>
     <td>
       <label>Password:</label> 
     </td>
     <td>
       <input type="password" name="password"  size="32" maxlength="18" />
     </td> 
   </tr> 
   
   <tr>
     <td>
       <label>Language:</label> 
     </td>
     <td>
       <select name="$details['language']">
         <option name="english" selected>English</option>
         <option name="french">French</option>
       </select>
     </td> 
   </tr> 
   
      
    <tr colspan="2">
      <td>
       <input type="submit" name="submit" value="Log In" />
      </td> 
    </tr>  
   
     <!--Hidden input field for mime type -->
     <input type="hidden" name="$details['mimetype']"  value="H" />  
     
      <!--Hidden input field for email verification -->
     <input type="hidden" name="$details['code']"  
        value="<?php 
                    echo rand(3000000, 5000000);
                ?>" /> 
                
   
     
    </form> 
   </table>  
</body>
</html>