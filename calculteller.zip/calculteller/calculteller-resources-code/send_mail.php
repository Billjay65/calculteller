﻿<?php
// send mail code: This code accepts input from formmail and sends it to an email
//create short variable names


if(!isset($_SERVER['HTTP_REFERER']))
{
  // Redirect user to index if he did not click on button
          header('Location: index.html');
          exit(); 
}



$zumCarsHeader = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html> 
<head> 
<title>ZumCars: Home page-Main-page of top10greatcars.com. Realize your dreams</title> 
<!--
<base href="http://www.top10greatcars.com/"> 
-->

 <link  type="image/png"  rel="icon"  href="images/favicon1.png" />
 
 <script src="scripts/css3-mediaqueries.min.js"></script>
 
<link type="text/css" rel="stylesheet" href="styles/zumcars.css" />


</head> 



 <body>
 
  <div id="main">
    
      <div id="header">
              
           <h1><a href="" target="_self">
              <img src="images/tshirtshop.png" alt="ZumCars logo" />
            </a></h1>
            
              
  
         <span id="social_help_header">
            <a href="http://www.facebook.com" title="Share on facebook" target="_blank">f</a>
            <a href="http://www.twitter.com" title="Share on twitter" target="_blank">t</a>
            <a href="http://www.google+.com"title="Share g+"  target="_blank">G+</a>
            <a id="yt-play" href="http://www.youtube.com" title="Watch videos"  target="_blank">
            <img src="images/yt-play1.png" alt="Youtube videos" /></a> 
             
         </span> 
         
          <span id="header_forms"> 
           
           <form  method="POST">
             <select name="language">
                   <option value="English" selected>English</option>
                   <option value="French">French</option>
                   <option value="Spanish">Spanish</option>
                   <option value="Chinese">Chinese</option>
              </select>
              <input type="submit" name="language" value="ok">
            </form>
            <form>  
              <input type="image" name="menubutton" src="images/menu.png" 
                                style=" border-radius:5px; vertical-align:top;"/> 
            </form>
         </span>    
      </div>';
      
$zumCarsFooter ='  <div id="footer">
                    footer
                       </div>
                    </body></html>';
$linkBactToContactPage = $_SERVER['HTTP_REFERER'];
 
$to = $_POST['to'];
$subject = $_POST['subject'];
$message = $_POST['message'];
$email= $_POST['email'];
$name = $_POST['name'];

$mailcontent = 'Customer name: '.$name."\n"
                .'From: Customer email: '.$email."\n"
                .'Subject '.$subject."\n"
                ."Message: \n".$message."\n";


 // check an email address is possibly valid
 if (empty($_POST['email']) && !ereg('^([a-z0-9_-])+([\.a-z0-9_-])*@([a-z0-9-])+(\ 
             .[a-z0-9-]+)*\.([a-z]{2,6})$', $_POST['email'])) 
 {
      echo $zumCarsHeader ;
 
 
 
      echo '<center>';
      echo '<p style="color:#ee0011; font-size:120%;">
              <b>Failed to send email: Please enter valid email and try again</b>
              </p><br />';
              
      echo '<a href="'.$linkBactToContactPage.'"><big><b>New Message</b></big></a>';
      echo '</center>';
      
      echo $zumCarsFooter;
      exit();
 }
 

else if(mail($to, $subject, $mailcontent))
{
  echo $zumCarsHeader ;
  echo '<center>';
  echo '<h1>Message Sent!!!</h1>'.'<br />'; 
  echo '<a href="'.$linkBactToContactPage.'"> 
        <big><b>Go To HOME PAGE</b></big></a>';
  echo '</center>';
  
  echo $zumCarsFooter;
   exit();
}

else{
  echo $zumCarsHeader ;
  echo '<center>';
  echo '<p style="color:#ee0011; font-size:120%;">
         <b>Failed to send email: Please try again</b>
          </p><br />';
  echo '<a href="'.$linkBactToContactPage.'"><big><b>New Message</b></big></a>';
  echo '</center>';
  
  echo $zumCarsFooter;
}

 
?>


                
                
                
                
                
                

  


