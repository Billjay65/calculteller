<?php
  // Set the 404 status code
  header('HTTP/1.0 500 Internal Server Error');

  require_once 'include/config.php';
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
    <title>
      CalculTELLER Application Error (500): Internal Server Error!
    </title>
    <link rel="stylesheet" media="screen and (max-width: 780px)" href=<?php echo Link::Build('styles/calculteller_mobile.css'); ?> />
    <link rel="stylesheet" media="screen and (min-width: 780px)" href=<?php echo Link::Build('styles/calculteller.css'); ?> />
  </head>
  <body>
    <div >
      <div >
        <div >
         <h1>
          <a href="<?php echo Link::Build(''); ?>" 
                                 style="text-decoration:none;">
            <img id="logo_error" src="<?php echo Link::Build('images/logo2.jpg'); ?>"
             alt="tshirtshop logo" />
          </a> 
          <span id="app-name">CalculTELLER</span>
         </h1>
        </div>
        
        <div  >
          <h1>
            CalculTELLER is experiencing technical difficulties.
          </h1>
          <p>
            Something is wrong and Calculteller is down. Please
            <a href="<?php echo Link::Build(''); ?>">visit us</a>
            again later.
            
            or <a href="<?php echo ADMIN_ERROR_MAIL; ?>">email us</a>
            if you need further assistance. 
          </p>
          <p>Thank you!</p>
          <p>The CalculTELLER team.</p>
        </div>
      </div>
    </div>
  </body>
</html>
