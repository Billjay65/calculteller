<?php

// include config file containing directory paths
 require_once 'include/config.php';
 
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';

 
/*
// Database connectivity setup  for world database
define('DB_PERSISTENCY', 'true');
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'jay.v');
define('DB_PASSWORD', 'Sikehjaphetberyuf12');
define('DB_DATABASE', 'world');
define('PDO_DSN', 'mysql:host=' . DB_SERVER . ';dbname=' . DB_DATABASE);

 $insert_query_done = false;
 
  
  // Get city, country and continent information from world DB
  $query1 = "SELECT c.Name AS city, t.Name AS country, t.Continent AS continent
             FROM  city c
             INNER JOIN country t
             ON    c.CountryCode = t.Code
             GROUP BY country
             ORDER BY country";       
    $result1 = getAll($query1, $params=NULL);
   
  
  
  $noCities = sizeof($result1);

 
// close connection 
unset($pdo); 
  
  //  INSERT query...
  
  NEVER EXECUTE FOLLOWING CODE AGAIN: USED TO POPULATE city table 
 // of CALCULTELLER database with information from world database 
 for($i=0; $i < $noCities; $i++)
 {
  
   $city = addslashes($result1[$i]['city']);
   $country = addslashes($result1[$i]['country']);
   $continent = addslashes($result1[$i]['continent']);
   
   try { 
   $pdo = new PDO('mysql:dbname=calculteller;host=localhost', 'root', 'Sikehjaphetberyuf12'); 
   }
   catch (PDOException $e) { 
   die("ERROR: Could not connect: " . $e->getMessage()); 
   } 
   
   $sql = "INSERT INTO  city (city_name, country, continent)
               VALUES ('$city', '$country', '$continent')"; 
                     
    $ret = $pdo->exec($sql); 
    if ($ret === false) { 
    echo "ERROR: Could not execute $sql. " . print_r($pdo->errorInfo()); 
    } else { 
     $id = $pdo->lastInsertId(); 
     echo 'New city: '  . $id  . ' added.'; 
    } 
   
   
  
   //echo '('.'\''.strip_tags($result1[$i]['city']).'\',';
   //echo ' '.'\''.strip_tags($result1[$i]['country']).'\',';
   //echo ' '.'\''.strip_tags($result1[$i]['continent']).'\''.'),';
   
  
  }

*/ 
 
// Get  GMT time
// Formats a GMT/UTC date and time
//returns GMT time relative to 'now' 

echo 'It is now'. gmdate('H:i:s d-M-Y', mktime());
      
echo ' GMT'.'<br />';
//Returns the Unix timestamp for a GMT date	
//gmmktime() 	

date_default_timezone_set("Africa/Lagos");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year'];    




date_default_timezone_set("America/New_York");
echo date_default_timezone_get();


// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 

date_default_timezone_set("Europe/Paris");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 

date_default_timezone_set("Europe/Paris");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 

date_default_timezone_set("America/Argentina/San_Juan");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 

date_default_timezone_set("Europe/Paris");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 


date_default_timezone_set("Antarctica/Casey");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 


date_default_timezone_set("Asia/Bangkok");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 

date_default_timezone_set("Atlantic/Cape_Verde");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 


date_default_timezone_set("Australia/Melbourne");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 


date_default_timezone_set("Canada/Central");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 

date_default_timezone_set("Europe/London");
echo date_default_timezone_get(); 
echo '<br />';

// get current date and time as array 
$now = getdate(); 
 
// output: 'It is now 19:26:23 on 12-11-2007' 
echo 'It is now ' . $now['hours'] . ':' . $now['minutes'] . ':'  
. $now['seconds'] . ' on ' . $now['mday'] . '-' . $now['mon'] . '-'  
. $now ['year']; 
 

/*
// display list of all timezones in PHP
foreach(timezone_abbreviations_list() as $abbr => $timezone){
        foreach($timezone as $val){
                if(isset($val['timezone_id'])){
                        var_dump($abbr,$val['timezone_id']);
                }
        }
}

*/


// Returns an indexed array with all timezone identifiers
$timeZoneIdentifiers = timezone_identifiers_list();
foreach($timeZoneIdentifiers as $t)
   echo $t. '<br />';
 
 /* 
 //TIME ZONE PHP functions and variables
 

PHP Date/Time Introduction

The date/time functions allow you to get the date and time from the server where your PHP script runs. You can then use the date/time functions to format the date and time in several ways.

Note: These functions depend on the locale settings of your server. Remember to take daylight saving time and leap years into consideration when working with these functions.
Installation

The PHP date/time functions are part of the PHP core. No installation is required to use these functions.
Runtime Configuration

The behavior of these functions is affected by settings in php.ini:
Name 	Description 	Default 	PHP Version
date.timezone 	The default timezone (used by all date/time functions) 	"" 	PHP 5.1
date.default_latitude 	The default latitude (used by date_sunrise() and date_sunset()) 	 "31.7667" 	PHP 5.0
date.default_longitude 	The default longitude (used by date_sunrise() and date_sunset()) 	"35.2333" 	PHP 5.0
date.sunrise_zenith 	The default sunrise zenith (used by date_sunrise() and date_sunset()) 	"90.83" 	PHP 5.0
date.sunset_zenith 	The default sunset zenith (used by date_sunrise() and date_sunset()) 	"90.83" 	PHP 5.0
PHP 5 Date/Time Functions
Function 	Description
checkdate() 	Validates a Gregorian date
date_add() 	Adds days, months, years, hours, minutes, and seconds to a date
date_create_from_format() 	Returns a new DateTime object formatted according to a specified format
date_create() 	Returns a new DateTime object
date_date_set() 	Sets a new date
date_default_timezone_get() 	Returns the default timezone used by all date/time functions
date_default_timezone_set() 	Sets the default timezone used by all date/time functions
date_diff() 	Returns the difference between two dates
date_format() 	Returns a date formatted according to a specified format
date_get_last_errors() 	Returns the warnings/errors found in a date string
date_interval_create_from_date_string() 	Sets up a DateInterval from the relative parts of the string
date_interval_format() 	Formats the interval
date_isodate_set() 	Sets the ISO date
date_modify() 	Modifies the timestamp
date_offset_get() 	Returns the timezone offset
date_parse_from_format() 	Returns an associative array with detailed info about a specified date, according to a specified format
date_parse() 	Returns an associative array with detailed info about a specified date
date_sub() 	Subtracts days, months, years, hours, minutes, and seconds from a date
date_sun_info() 	Returns an array containing info about sunset/sunrise and twilight begin/end, for a specified day and location
date_sunrise() 	Returns the sunrise time for a specified day and location
date_sunset() 	Returns the sunset time for a specified day and location
date_time_set() 	Sets the time
date_timestamp_get() 	Returns the Unix timestamp
date_timestamp_set() 	Sets the date and time based on a Unix timestamp
date_timezone_get() 	Returns the time zone of the given DateTime object
date_timezone_set() 	Sets the time zone for the DateTime object
date() 	Formats a local date and time
getdate() 	Returns date/time information of a timestamp or the current local date/time
gettimeofday() 	Returns the current time
gmdate() 	Formats a GMT/UTC date and time
gmmktime() 	Returns the Unix timestamp for a GMT date
gmstrftime() 	Formats a GMT/UTC date and time according to locale settings
idate() 	Formats a local time/date as integer
localtime() 	Returns the local time
microtime() 	Returns the current Unix timestamp with microseconds
mktime() 	Returns the Unix timestamp for a date
strftime() 	Formats a local time and/or date according to locale settings
strptime() 	Parses a time/date generated with strftime()
strtotime() 	Parses an English textual datetime into a Unix timestamp

// Time zone in built functions and variables
time() 	Returns the current time as a Unix timestamp
timezone_abbreviations_list() 	Returns an associative array containing dst, offset, and the timezone name
timezone_identifiers_list() 	Returns an indexed array with all timezone identifiers
timezone_location_get() 	Returns location information for a specified timezone
timezone_name_from_ abbr() 	Returns the timezone name from abbreviation
timezone_name_get() 	Returns the name of the timezone
timezone_offset_get() 	Returns the timezone offset from GMT
timezone_open() 	Creates new DateTimeZone object
timezone_transitions_get() 	Returns all transitions for the timezone
timezone_version_get() 	Returns the version of the timezone db
*/

?> 