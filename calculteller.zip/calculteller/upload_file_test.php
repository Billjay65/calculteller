﻿<?php
/*** Upload file test - Upload file, read its content
     and display in html page ***/

if (isset($_POST['load']))
{
  echo '<pre>';  
      print_r($_FILES);
      print_r($_POST);
      $handle = fopen($_FILES['uploadedfile']['tmp_name'], "r");
      echo '</pre>';
}
else{      
?>      


 <form enctype="multipart/form-data" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" 
        id="balanceFormTab2">
        <!-- inputs for load file functionality -->
        <input size="50" type="file" name="uploadedfile">
        <input type="submit" name="load" value="Load File"  class="addgame" id="load"> <br />
      </form>

<?php
}
?>