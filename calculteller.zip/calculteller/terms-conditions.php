<?php

 // start session, authenticate user....
 session_start();
 
 // Start output buffer
 ob_start();
 
 // include config file containing directory paths
 require_once 'include/config.php';
 
 // include error handling class php file
 require_once 'error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 
 // Call the home page functions to display html content on screen
 
 fixed_html_header('CalculTELLER: Terms and Conditions',
                      '', $user_name, $member);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

?>

  <div class="extra_page_content">
    
   <h1>Calculteller Terms and Conditions</h1>

    <h2>Terms of Use</h2>
     <p>
       The following terms and conditions apply to all users of this website. 
       IF YOU DO NOT ACCEPT THESE TERMS, DO NOT USE THE WEBSITE. Calculteller
       may change these terms of use at any time by posting the amended terms 
       on the website. Your use of the website after such changes are posted 
       will signify your acceptance of the revised terms.
     </p>
     
    <h2>Use of Website</h2>
     <p>
       Information on this Web site may contain technical inaccuracies or 
       typographical errors. Information may be changed or updated without notice. 
       Calculteller may also make improvements or changes in the products at any 
       time without notice. Redistribution and reverse engineering of the software
       is prohibited without agreement. Calculteller assumes no responsibility 
       regarding the accuracy of the information that is provided by Calculteller 
       and use of such information is at the user's own risk. Calculteller provides 
       no assurances that any reported problems may be resolved though we will
       work very hard to solve all your problems. Calculteller reserves the right 
       to terminate or suspend this website for any reason.
     </p>
     
    <h2>Copyright and Trademarks</h2>
     <p>
       The content of this website is protected by copyright, trade-marks and/or 
       other rights and is owned or licensed by Calculteller. Trademarks and logos 
       identifying calculteller products and services, are registered and 
       unregistered trade-marks of Calculteller. All other product names and logos
       are the trade-marks of their respective owners. The use or misuse of these 
       trade-marks, copyrights or other materials, except as permitted herein, is 
       expressly prohibited.
     </p>
    <h2>Disclaimer</h2>
     <p>
      The materials and information on this website are provided on an "as is" 
      basis, without warranties of any kind, either express or implied. CALCULTELLER
      DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED IN RESPECT OF THE 
      INFORMATION, INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OR CONDITIONS 
      OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT 
      OF INTELLECTUAL PROPERTY. Limitation of Liablility IN NO EVENT WILL 
      CALCULTELLER BE LIABLE FOR ANY DAMAGES WHATSOEVER, INCLUDING SPECIAL, 
      INDIRECT OR CONSEQUENTIAL DAMAGES, ARISING OUT OF OR IN CONNECTION WITH THE 
      USE OR INABILITY TO USE THIS WEBSITE OR THE INFORMATION CONTAINED IN THIS 
      WEBSITE, INCLUDING BUT NOT LIMITED TO, DAMAGES FOR LOSS OF PROFITS, EVEN 
      IF CALCULTELLER HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
     </p>
     
    <h2>Applicable Laws</h2>
     <p>
       You agree to comply with all applicable laws and regulations. These terms 
       shall be governed by and construed in accordance with the laws of the US
       applicable therein. Any legal action or proceeding relating to your access 
       to, or use of, our Site shall be instituted only in a court of competent 
       jurisdiction in the US. You agree to submit to the jurisdiction of such 
       courts in any such legal action or proceeding.
     </p> 
    
    
    <!--End of extra-page-content div-->
  </div>
<?php

fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();
?>