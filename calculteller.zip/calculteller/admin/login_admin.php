<?php

// Start session and read username from session variable if it is set
 session_start();  

// Obtaining root directory  from admin folder
 define('SITE_ROOT3', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT3.'/include/config.php';
   

// include error handling class php file
 require_once SITE_ROOT3.'/error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';


 // read cookie and assign cookie values 
// to PHP variables
 $username = ''; 
 $user_name_cookie = isset($_COOKIE['username']) ? $_COOKIE['username'] : '';
  
 
 if($user_name_cookie!='')
 {
    $username = $user_name_cookie;
 
 }


    // display input validation error 
    function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        return "<div class=\"error\">ERROR: " . $key . "</div>"; 
      } else { 
        return false; 
      } 
    } 
    
    
   $editMode = 0;
   $errorFlag = 0;
   //$errorHeader = 'ERROR: Form filled incorrectly, Please correct error';
   $errorHeader = '';
 /* 
  $nameError = 0;
  $emailAlreadyTaken = 0;
  $emailError = 0;
  $passwordError = 0;
  $passwordConfirmError = 0;
  $passwordMatchError = 0;
  */
  $linkToAccountDetails;
  $linkToCancelPage = Link::Build('admin/index.php');

 
    $inputErrors = array(); 
    $submitted = false; 
    
    
 
 
    // if form submitted 
    // validate form input 
if (isset($_POST['submit'])) 
{ 
  
      $submitted = true;
      $valid['password'] = ''; 
      $valid['username'] = ''; 
      $_username = '';
      $_password = '';
      $_email = '';
      
   
       // validate username atmost 15 characters 
      if (!empty($_POST['username']) && preg_match('/^([a-zA-Z]){2,15}$/', $_POST['username'])) 
      { 
        $_username = htmlentities(trim($_POST['username'])); 
       
         // Check if username is unique and equals Admin User name in config file
        
  
         if($_username == ADMIN_USERNAME)
         {
            $valid['username'] = htmlentities(trim($_POST['username']));
            $_username = $valid['username'];
         }
         else
         {
           $inputErrors[] = 'Invailid Username';
           $errorFlag = 1; 
         }
                
      } 
      else { 
        $inputErrors[] = 'Invailid Username';
        $errorFlag = 1; 
      } 
      
      
 
      // validate user password Must start with Capital letter atleast 4 characters long
      if (!empty($_POST['password']) && preg_match('/^(.){3,14}$/', $_POST['password']))  
      { 
      
        $_password = htmlentities(trim($_POST['password']));
        
        // Set boolean of passwordhasher to false, so it does NOT use prefix
        $_hpassword = PasswordHasher::Hash($_password, false); 
        
        //echo $_hpassword;
        
        // Check if hashed password matches with that in config, admin password
          
          if($_hpassword == ADMIN_PASSWORD)
          {
            $valid['password'] = htmlentities(trim($_password));
          }
          else { 
          
           $inputErrors[] = 'Invalid Password';
           $errorFlag = 3; 
         } 
      } 
      else { 
        
        $inputErrors[] = 'Invalid Password';
        $errorFlag = 3; 
      } 
     
      
      
      if($errorFlag > 0)
      $errorHeader = 'ERROR: Form filled incorrectly, Please correct errors';
      
 
  // sanitize data and insert into database including date
  $username = $valid['username'];
  $password = $valid['password'];
          
} 


 // if form is submitted with no errors 
  // write the input to the database 

if((isset($_POST['submit'])) && count($inputErrors) <= 0) 
{ 
  
   // register session variables
  $_SESSION['name'] = 'ADMIN';
  $_SESSION['username'] = $username;

 echo $_SESSION['username'] ;
 
 // SET cookies
 $app_name = 'CalculTELLER';
 $ret1 = (isset($username)) ? setcookie('username', $username, 
           time() + 172800, '/') : null;
 $ret2 = (isset($app_name)) ? setcookie('app_name', $app_name, 
           time() + 172800, '/') : null;

/*
// read cookie and assign cookie values 
// to PHP variables 
$username = isset($_COOKIE['username']) ? $_COOKIE['username'] : ''; 
$app_name = isset($_COOKIE['$app_name']) ? $_COOKIE['$app_name'] : '';
 */

 
 
  // Redirect user to index if login is successful
 header('Location:'.$linkToCancelPage);
 exit();
  
  
 }
 
    // if form not submitted  Only
    // or if validation errors exist 
    // (re)display form 
elseif (($submitted == true && count($inputErrors) > 0) || $submitted == false) 
{ 

  do_html_header('Calculteller:Admin Sign In!', ' Sign In and let calculteller talk to you!', 
                  $errorHeader, VIRTUAL_LOCATION); 
                  

 ?>
 
 
 <form id="login_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"> 
 <h3>CalculTELLER Admin Log in</h3>
      <label>Username:</label> <br /> 
      <input type="text" name="username"  
        value="<?php echo isset($_POST['username']) ? $_POST['username'] : $username;?>" 
        size="32" maxlength="14" />
        <?php echo getInputError('Invailid Username', $inputErrors); ?> 
        
      <br /><br />
      <label>Password:</label> <br /> 
      <input type="password" name="password" size="40" maxlength="40"
         value="<?php echo isset($_POST['password']) ? $_POST['password'] : '';?>" />
        <?php echo getInputError('Invalid Password', $inputErrors); ?> 
       
       <br /><br />
      <input type="submit" name="submit" value="Log In" /> 
      
    </form>                   

<?php 

 
  
} 

 
 
 
 unset($database_handler);

do_html_footer();
?>