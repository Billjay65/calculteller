 <?php

// start session, authenticate user and store variables coming from domain for display
 session_start();
 
 // Obtaining root directory  from admin folder
 define('SITE_ROOT3', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT3.'/include/config.php';
   

// include error handling class php file
 require_once SITE_ROOT3.'/error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 $user_name = (!isset($_SESSION['username']))? '' : 'Hi, ADMIN' ;


  // Authenticate Admin user
 if((!isset($_SESSION['username']) || $_SESSION['username']=='') ||
      ((isset($_SESSION['username'])) && ($_SESSION['username']!== ADMIN_USERNAME)))  
 { 
 
  fixed_html_header('CalculTELLER: Access Denied, Admins only',
                      'Unqualified User', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please BE WARNED! Only Admins can access this page</h2></center>';
 echo '<p class="login_advice">';
 echo  'Please leave this page if you are NOT an Admin. If you are an admin,
        login in to gain full access';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('admin/login_admin.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
 }


                                               
?>
 
 
  
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

 <head>
   
 <title> Caclteller:Administration Module, user table </title>
   
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
 <meta name="viewport" content="width=device-width, initial-scale=1.0" />
 
  <link rel="icon" type="image/png" href="images/logo2.png" />
  
   
   <link type="text/css" rel="stylesheet" href=<?php echo Link::Build('styles/admin_styles.css'); ?> />
     
  
  </head>
  
<body> 
  
  
<body> 


<!-- standard page header -->


<div id="doc">

<div class="admin_header">
   <a href=<?php echo  Link::Build('admin/index.php'); ?> >
      <img src="<?php echo Link::Build('images/admin_logo.png'); ?>" alt='Logo-calculteller' border=0
        style="float:left; max-width: 100%;" />
   </a> 

   <span id="app">&nbsp; CalculTELLER:</span> &nbsp;

   <span id="page">Administration Module</span>
    
   
   <span id="help_logout">
       <a title="help" href=<?php echo  Link::Build('forum.php'); ?> >
        HELP|
       </a>
  
       <a title="logout" href=<?php echo  Link::Build('logout.php'); ?> >
        Logout|
       </a> 
       
       <a href=<?php echo  Link::Build('login.php'); ?> >
        Login
       </a>
    </span> 
   

    <span class="user_name">
       <?php 
       echo '<span>'.$user_name.' '.'</span>';
       
       if(!empty($user_name))
       { 
         echo '<a href="'.Link::Build('myaccount.php').'">';
         echo '<img id="user_image" src="'.Link::Build('images/user_image.png').'" alt="user_image" />';
         echo '</a>';
       }
       ?>
    </span>  
    
    <p class="account_tab" >
      <a title="Edit domain table" href="<?php echo Link::Build('admin/domain.php'); ?>">
        domain
      </a>
      <a title="Edit domain_tab table" href="<?php echo Link::Build('admin/domain_tab.php'); ?>">
       domain_tab
      </a>
      <a title="Edit unit table " href="<?php echo Link::Build('admin/unit.php'); ?>">
       unit
      </a>
      <a title="Edit domain_unit table" href="<?php echo Link::Build('admin/domain_unit.php'); ?>">
       domain_unit
      </a>
  
      <a title="Edit user table" href="<?php echo Link::Build('admin/user.php'); ?>">
       user
      </a>
      <a title="Edit user_data" href="<?php echo Link::Build('admin/user_data.php'); ?>">
       user_data
      </a>
      <a title="Go back to main site" href="<?php echo Link::Build('index.php'); ?>">
       Real Site
      </a>
    </p>
 


</div>

<!-- admin_content-->

<?php

 // define array to hold the number records to be displayed in my account
     // range(1,120) creates and arry with values from 1 to 120 Max=120
     $arr = range(1, 200);
     
     // define variable for starting point for database
     $startRecord = 0;
 
     //Get number of records to display from post
     $dataRecords = (!isset($_POST['datarecords']))? 15 : $_POST['datarecords'];
  
     //Get number of records to display from get query string
     if(isset($_GET['records_display']))
       $dataRecords = $_GET['records_display'];
     
     // get starting point from query string  
     if(isset($_GET['start_record']))
       $startRecord = $_GET['start_record'];
  
     // Get button which has been clicked
  
      $recordsNo = (!isset($_POST['recordsno']))? false : true;
  
      $linkToCancelPage = (!isset($_SERVER['HTTP_REFERER']))? '' : 
                                                $_SERVER['HTTP_REFERER'];

if(!isset($_POST['submit']))
{
 ?>


 <div class="admin_content">
 <table class="admin_table_list" >
 <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

  <tr>
      <td colspan="11"> 
      <h1> user table: CalculTELLER-Admin </h1>
      </td>
</tr>
<tr>
  <td colspan="11"><label>NUMBER of records to display</label>
   <select name="datarecords"> 
    <?php
    
    
     // display select list for number of records to display
     for($i=0; $i < sizeof($arr); $i++)
     {
       echo   '<option value="'.$arr[$i].'"';
               if($arr[$i] ==  $dataRecords)
                echo 'selected';
       echo   ' >';
      
      
         echo     $arr[$i]; 
       
     
       echo   '</option>' ;
     }
     ?>
    </select> 
                          
 
   
  <input type="submit" name="recordsno" value="GO!" > <br /> 
                                                                          
                                                        
  
  </td>
  </tr>  
<tr>
      <td >name</td>
      <td >username</td>
      <td >email</td>
      <td >address</td>
      <td >city</td>
      <td >region</td>
      <td >country</td>
      <td >phone</td>
      <td >lvisit</td>   
      <td >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>   
 <!-- Display the number of rows of user data obtained from database-->
    <?php
    // Get the number of records to display and build rows of display table
 
 // open connection to MySQL server and execute queries
 // Get number of records
  $recordsDisplayed = '';

  $sql = "SELECT COUNT(*) FROM user"; 

 $rows = getRow($sql, $params=NULL);
  
   // get total number of records
  $total_records = $rows['COUNT(*)']; 
  
    
    
    
  if (($total_records > 0)  )
  {
    if( $total_records <=  $dataRecords)
    {
       $recordsDisplayed = $total_records;
       $dataRecords = $total_records;
    }
    else
    {
       $recordsDisplayed = $dataRecords;
    }
  
    
    // create and execute query to get batch of records
    $query = "SELECT * FROM user 
              ORDER BY username
              LIMIT $startRecord, $recordsDisplayed";   
    
    $result = getAll($query, $params=NULL);
    
     
     
  /*** The lines below are vital to avoid errors when looping over arrays ***/   
  // count the exact number of records retrieved from database
  // based on starting record and records per page gotten
  // from query string or from input form
  // use this value in for loop to display number of records     
  $sql = "SELECT COUNT(*) AS number from (SELECT * FROM user
          LIMIT $startRecord, $recordsDisplayed) as records"; 

  $rows = getRow($sql, $params=NULL);
  
  
   // get total number of records
  $total_records_real = $rows['number'];
   
  $dataRecords = $total_records_real; 
  
  /*** End of code to get exact number of records gotten from db ***/
  
     // records displayed variables
     // display range of records displayed
     // actual record number is the index plus one
     $displayStartRecord = $startRecord+1; 
     $displayEndRecord   = $startRecord + $dataRecords; 
     
  
  
 // Display specified number of records of user data
  for($j=0; $j < $dataRecords ; $j++) 
  {
     //  sanitize and edit data before from database before displaying it
     // PHP also allows you to slice a string into smaller parts with the substr()
     // e.g $str = 'Welcome to nowhere'; echo substr($str, 3, 4); 
       $name     = strip_tags($result[$j]['name']) ;
       $username = strip_tags($result[$j]['username']) ;                                        
       $email    = strip_tags($result[$j]['email']);
       $address  = strip_tags($result[$j]['address']);
       $city     = strip_tags($result[$j]['city']);
       $region   = strip_tags($result[$j]['region']);
       $country  = strip_tags($result[$j]['country']);
       $phone    = strip_tags($result[$j]['phone']);
       $lvisit   = strip_tags($result[$j]['lvisit']);

       
       
      // links to update.php, delete.php and add input button
       // link to delete.php carrying dataId as query string  
       
       // link to update.php carrying domain Id and table number as query string
       $linkToUpdateString =   Link::Build('admin/edit.php?table=5&userName='.$username);
       
       $linkToUpdate= '<a class="datalink" title="Update record" href="'.
                      $linkToUpdateString. '"> Edit </a>';
       
      
      /*
       // link to delete.php carrying dataId as query string
       $linkToDeleteIdString =   Link::Build('delete.php?deleteId='.$dataId); 
       
       $linkToDelete= '<a class="datalink" title="Delete data record" href="'.
                      $linkToDeleteIdString. '"> Delete </a>';
      */
      
      
      
                      
       // link to delete.php carrying userName as query string
       $linkToDeleteIdString =   Link::Build('admin/delete.php?table=5&userName='.$username);
         
       
       $linkToDelete= '<a class="datalink" title="Delete  record" href="'.
                      $linkToDeleteIdString. '"> Delete </a>';
      // Link to cancel or previous page visited
       $linkToCancelHyper= '<a class="datalink" title="Delete  record" href="'.
                      $linkToCancelPage. '">Back</a>';
     
    
    echo '<tr>';
   
    echo  '<td>'. $name.'</td>';
    echo  '<td>'. $username.'</td>';
    echo  '<td>'.$email .'</td>';
    echo  '<td>'.$address.'</td>';
    echo  '<td>'.$city.'</td>';
    
    echo  '<td>'. $region.'</td>';
    echo  '<td>'. $country.'</td>';
    echo  '<td>'.$phone .'</td>';
    echo  '<td>'.$lvisit .'</td>';
    
    
    
    echo  '<td>';
    echo   $linkToUpdate. '<br /><br />';
    echo   $linkToDelete;
    echo  '</td>';
  
    echo  '</tr>';
  
   
  }
  
      // link to next set of records with start_record and records_display
      // query strings set 
      if ($startRecord + $recordsDisplayed < $total_records && $startRecord >= 0) 
      {
        $linkToNextString = Link::Build('admin/user.php?start_record='.
                    $startRecord + $recordsDisplayed . '&records_display='. $recordsDisplayed);
       
        $linkToNext = '<a class="datalink" title="Next" href="'.
                         $linkToNextString. '"> Next </a>';  
      }
                       
      // link to previous set of records with start_record and records_display
      // query strings set 
      if ($startRecord >= $recordsDisplayed)
      {
        $linkToPreviousString = Link::Build('admin/user.php?start_record='.
                             $startRecord - $recordsDisplayed. 
                             '&records_display='. $recordsDisplayed);
       
        $linkToPrevious = '<a class="datalink" title="Next" href="'.
                         $linkToPreviousString. '"> Previous </a>'; 
      } 
  
  
  
   echo  '</tr>';
    
  
   echo '<tr><td colspan="11">';
   echo   $linkToCancelHyper; 
  echo '</td></tr>';
 
  echo '<tr><td colspan="11">';
  echo '<span style="color:red;">'; 
  echo 'Total Number of Records:'; 
  echo $total_records; 
                              
  echo   '</span>'; 
  echo '</td></tr>';
  
  // display next and previous buttons
  // and range of records displayed
  echo '<tr><td colspan="11">';
  echo '<span style="color:blue;">'; 
  echo 'Records Displayed:'; 
  echo $displayStartRecord . ' - ' .$displayEndRecord;                          
  echo   '</span>'; 
  echo '</td></tr>';
  
  
  // display previous and next links
  echo '<tr><td colspan="11">';
  echo '<span style="color:red;">'; 
  if (isset($linkToPrevious))
    echo  $linkToPrevious; 
  if (isset($linkToNext))
    echo  $linkToNext;                            
  echo   '</span>'; 
  echo '</td></tr>';
  
 }
 
 else
 {
     echo '<br /><br /><br /><br /><br /><br />';
     echo '<center>';
     echo '<h2 style="color:#ff0000;"> No records available!</h2>';
     echo '<center>';
 }
 
  
   
 ?>   
      
</form>
</table>

<?php
}
?>

</div> <br /><br /><br /><br />
<!-- standard page footer -->

   <div id="formft">
     <hr />
    <p>Terms and Conditions | Privacy Policy | Support(image) | Tel (image)651817527 </p>
    <p> Copyright © 2017, CalculTeller SIKEH (signature at bottom right in Gold color or Silver.)</p>
     
   </div>
  </div> 
 </body>
</html>
