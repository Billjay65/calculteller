<?php
// include config file containing directory paths
 require_once 'include/config.php';
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 // start session and store session user variable
session_start();
$username = (!isset($_SESSION['username']))? '' : $_SESSION['username'] ;
$old_user = $username;

// Call the home page to display html content on screen

//store to test if they *were* logged in 
unset($_SESSION['username']);
$result_dest = session_destroy();

// start output html
fixed_html_header('CalculTELLER: Logout, logs user out and closes his account',
                      'Logging out ...', null);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();


if(!empty($old_user))
{
  if($result_dest)
  {
    // if they were logged in and are now logged out
    echo '<center>'.'Logged out!'.'</center>'.'<br />';
    
    //do_html_url('login.php', 'Login');
  }
  else
  {
    // they were logged in and could not be logged out 
    echo '<center>'.'Could not log you out'.'</center>'.'<br />';
  }
}
else 
{
  // if they weren't logged in but came to this page somehow 
  echo '<center>'.'You were not logged in , and so have not been logged out'.
        '</center>'.'<br />';
  //do_html_url('login.php', 'Login');
}
display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
do_html_footer();
?>










