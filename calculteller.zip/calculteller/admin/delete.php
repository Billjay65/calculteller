<?php
// start session, authenticate user and store variables coming from domain for display
 session_start();
 
 // Obtaining root directory  from admin folder
 define('SITE_ROOT3', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT3.'/include/config.php';
   

// include error handling class php file
 require_once SITE_ROOT3.'/error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 // create username variable for display
 $user_name = (!isset($_SESSION['username']))? '' : 'Hi, ADMIN' ;
 
 
 // check whether confirm delete button has been using REQUEST
 // if Not display confirm delete dialog box with Yes or No
 
 $confirmDelete =  (!isset($_REQUEST['confirm']))? null : (int)$_REQUEST['confirm'];

 


  // Authenticate Admin user
 if((!isset($_SESSION['username']) || $_SESSION['username']=='') ||
      ((isset($_SESSION['username'])) && ($_SESSION['username']!== ADMIN_USERNAME)))  
 { 
 
  fixed_html_header('CalculTELLER: Access Denied, Admins only',
                      'Unqualified User', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please BE WARNED! Only Admins can access this page</h2></center>';
 echo '<p class="login_advice">';
 echo  'Please leave this page if you are NOT an Admin. If you are an admin,
        login in to gain full access';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('admin/login_admin.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
 }
 
 
// check for table ID. If it is not set EXIT code execution
if ((!isset($_REQUEST['table']) || trim($_REQUEST['table']) == '')) 
{ 
    fixed_html_header('CalculTELLER: Missing Table Id-Admin Module',
                      'Admin (Change) Functions', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display missing table ID Error message to user
    echo '<center>';
    echo '<p>Missing table ID!</p>'; 
    echo '<p> .
          <a href="domain.php">Please Try Again!</a>
         </p>';
    echo '<center>';
    

fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
}




 //get table number either from query string or from form input using REQUEST

 $table =  (!isset($_REQUEST['table']))? null : (int)$_REQUEST['table'];
 
 // get recordId either from query string or from form input using REQUEST

 $deleteId =  (!isset($_REQUEST['table']))? null : (int)$_REQUEST['table'];

 // successful record delte flag set to false
    $deleteRecordSuccessful = false; 
  
  

// define associative array to hold keys and values of database table
$databaseTable = array(
         'domain' => 1,
         'domain_tab' => 2,
         'unit' => 3,
         'domain_unit' => 4,
         'user' => 5,
         'user_data' => 6);
         

    // display input validation error 
    function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        return "<div class=\"error\">ERROR: Invalid data for field '$key'</div>"; 
      } else { 
        return false; 
      } 
    } 
    
    // successful record update flat set to false
    $addRecordSuccessful = false;
    
    // error flag variable
    $errorFlag = 0;
    
    //$errorHeader = 'ERROR: Form filled incorrectly, Please correct error';
    $errorHeader = '';
   
   // define error array to hold errors
  $inputErrors = array(); 
  
  // if HTTP_REFERER is Not set  display error message
 // This ensures that user accesses this page ONLY from within app
 if(!isset($_SERVER['HTTP_REFERER']))
 {
   echo '<h2> Error: Unable to display page.</h2>
         <p> Please login and try again.
          <a href="login_admin.php">Login.</a>
         </p>';
   
   exit();
 }
 else
 {
    $linkToCancelPage = $_SERVER['HTTP_REFERER'] ;
 
 }     
 
   
   
   
   // if table ID is set, start testing the values of table id and execute
   // the appropriate code below. Start by displaying html header
?>
 
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

 <head>
   
 <title> Caclteller:Administration Module, Add Record </title>
   
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link rel="icon" type="image/png" href="images/logo2.png" />
  
   <link type="text/css" rel="stylesheet" href=<?php echo Link::Build('styles/admin_styles.css'); ?> />
  
  
  </head>
  
  
  
<body> 



<!-- standard page header -->


<div id="doc">

<div class="admin_header">
<a href=<?php echo  Link::Build('admin/index.php'); ?> >
 <img src="<?php echo Link::Build('images/admin_logo.png'); ?>" alt='Logo-calculteller' border=0
     align='left'  height = "100%" width ="7%"  />
</a> 
<span id="app">&nbsp; CalculTELLER:</span> &nbsp;

<span id="page">Admin-Add Record</span> 

<p class="account_tab" >
  
  
  <a title="Admin Home Page" href="<?php echo Link::Build('admin/index.php'); ?>">
   Admin Home
  </a>
  <a title="Go back to main site" href="<?php echo Link::Build('index.php'); ?>">
   Real Site
  </a>
</p>
 
</div>

<?php


// check which table Id has been set and execute the appropriate code
if($table == $databaseTable['domain'])
{ 

  // get recordId either from query string or from form input using REQUEST
 
    if(!isset($_REQUEST['domainId']) && !isset($_REQUEST['domainId']))
    {
       echo '<h2> Error: domainId has not been set.</h2>
              <p> Please go back and try again.
                <a href="'.$linkToCancelPage.'">BACK.</a>
             </p>';
   
       exit();
    }
    else
    {
       $domainId =  (int)$_REQUEST['domainId'];
    }
 

 if(!isset($confirmDelete) || $confirmDelete!==1)
 {
   // if confirm delete button is not clicked, display confirm form
   // link to delete.php carrying dataId as query string
       $linkToDeleteYes = Link::Build('admin/delete.php?table=1&domainId='.$domainId.'&confirm=1');
         
       
       $linkToDeleteNo=  '<a class="datalink" title="Delete  record" href="'.
                      $linkToCancelPage. '"></a>';
                      
        echo '<center><big>';
                      
        echo '<p>'.'Are you sure you want to delete Domain'.
              $domainId.' ?'.
             '</p>'.'<br />'.'<b>'.
              '<a href="'. $linkToDeleteYes.'">'. 'YES'.
             '</a>'.'</b>&nbsp;&nbsp;&nbsp;&nbsp;'.
             
             '<a href="'. $linkToCancelPage.'">'. 'NO'.
             '</a>'.'</b><br />' ;
        
        echo '</big></center>';
 
 
 }
 
 elseif($confirmDelete)
 {

  
 
  // check for record ID
  if ((isset($domainId)) && (!empty($domainId)) ) 
  { 
     // first verify that domain Id is not used in other db tables before deleting
     
     // Verify that domain ID is not found in domain_tab table   
     $sql1 = "SELECT COUNT(*) FROM domain_tab
             WHERE  domain_id = '$domainId'"; 

      $rows1 = getRow($sql1, $params=NULL);
  
     // get total number of records
      $total_records1 = $rows1['COUNT(*)']; 
     
     // Verify that domain ID is not found in domain_unit table
      $sql2 = "SELECT COUNT(*) FROM domain_unit
             WHERE  domain_id = '$domainId'"; 

        $rows2 = getRow($sql2, $params=NULL);
  
     // get total number of records
     $total_records2 = $rows2['COUNT(*)'];
     
     
     //DELETE TWO LINES BELOW AFTER TEST
     echo  $total_records1 .'<br />';
     echo  $total_records2;
     
     if(($total_records1 == 0)&&($total_records2 == 0))
     {
       // if domain is Not related to both domain and domain_tab table,
       // Proceed and DELETE the domain
       // Build the SQL query to delete record
       // generate and execute query
  
  
       /***UNCOMMENT SQL DELETE CODE AFTER TEST 
        $query = "DELETE FROM domain WHERE domain_id = $domainId";
                 
        $lastDeleteId = executeQuery($query, $params = null);
        
         // successful record delete flag set to true
           $deleteRecordSuccessful = true;
           
        ***/
        
       
         
         // display delete success message to user
        if($deleteRecordSuccessful ==true )
        {
          // if update is successful
          echo  '<center><h2>Record Deleted Successfully!</h2></center>';
          echo '<center>';
          echo '<span style="float:center;">'.'<b>'.'<a href="'.
             Link::Build('admin/domain.php').'">'.' Go Back to Domain Tab'.'</a>'.'</b>'.'</span>' ;
          echo '</center>';
     
     
         }
          elseif($deleteRecordSuccessful ==false)
         {
           // if delete is Not successful
          echo '<center><br /> <br /><br />';
          echo '<span class="error">'.'Error: Unable to delete record!'.
                '<br />'.'<br />'.'<b>'.
               '<a href="'. Link::Build('admin/domain.php') .'">'. 
                 'Go Back to Domain Tab'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
     
         }
    
     }
     else
     {
     
        echo  '<center><h2 class="error">Error: Cannot delete domain because
                                    it is related to other tables in database</h2></center>';
        echo '<center>';
        echo '<p>First delete domain from
                its related tables and then try again</p>';
        echo '<span style="float:center;">'.'<b>'.'<a href="'.
           Link::Build('admin/domain.php').'">'.' Go Back to Domain Tab'.'</a>'.'</b>'.'</span>' ;
        echo '</center>';
     
     
     }
     

    
   
   
    unset($database_handler);
 
 
   exit(); 
  }
  
  
 }


}

elseif($table == $databaseTable['domain_tab'])
{
   
    // get recordId either from query string or from form input using REQUEST
 
    if(!isset($_REQUEST['tabId']) && !isset($_REQUEST['tabId']))
    {
       echo '<h2> Error: tabId has not been set.</h2>
              <p> Please go back and try again.
                <a href="'.$linkToCancelPage.'">BACK.</a>
             </p>';
   
       exit();
    }
    else
    {
       $tabId =  (int)$_REQUEST['tabId'];
    }
 

 if(!isset($confirmDelete) || $confirmDelete!==1)
 {
   // if confirm delete button is not clicked, display confirm form
   // link to delete.php carrying dataId as query string
       $linkToDeleteYes = Link::Build('admin/delete.php?table=2&tabId='.$tabId.'&confirm=1');
         
       
       $linkToDeleteNo=  '<a class="datalink" title="Delete  record" href="'.
                      $linkToCancelPage. '"></a>';
                      
        echo '<center><big>';
                      
        echo '<p>'.'Are you sure you want to delete Domain_tab '.
              $tabId.' ?'.
             '</p>'.'<br />'.'<b>'.
              '<a href="'. $linkToDeleteYes.'">'. 'YES'.
             '</a>'.'</b>&nbsp;&nbsp;&nbsp;&nbsp;'.
             
             '<a href="'. $linkToCancelPage.'">'. 'NO'.
             '</a>'.'</b><br />' ;
        
        echo '</big></center>';
 
 
 }
 
 elseif($confirmDelete)
 {


  // check for record ID
  if ((isset($tabId)) && (!empty($tabId)) ) 
  { 
     // tab_id is not related to any other table in dB, so delete straight away
     
       /***UNCOMMENT SQL DELETE CODE AFTER TEST 
        $query = "DELETE FROM domain_tab WHERE  tab_id = '$tabId'";
                 
        $lastDeleteId = executeQuery($query, $params = null);
        
         // successful record delete flag set to true
           $deleteRecordSuccessful = true;
        ***/
        
       
         $deleteRecordSuccessful = true;
         
         
         // display delete success message to user
        if($deleteRecordSuccessful == true)
        {
          // if update is successful
          echo  '<center><h2>Record Deleted Successfully!</h2></center>';
          echo '<center>';
          echo '<span style="float:center;">'.'<b>'.'<a href="'.
             Link::Build('admin/domain_tab.php').'">'.' Go Back to Domain_tab Tab'.'</a>'.'</b>'.'</span>' ;
          echo '</center>';
     
     
         }
          elseif($deleteRecordSuccessful == false)
         {
            
           echo  '<center><h2 class="error">
                       Error: Unable to delete record!</h2></center>';
           echo '<center>';
           echo '<p>Problem encountered while trying to delete record.</p>';
           echo '<span style="float:center;">'.'<b>'.'<a href="'.
           Link::Build('admin/domain_tab.php').'">'.' Go Back to Domain Tab'.'</a>'.'</b>'.'</span>' ;
           echo '</center>';
     
         }
    
     }

   
    unset($database_handler);
 
 
   exit(); 
  }
  
  
}
 



elseif($table == $databaseTable['unit'])
{

   // get recordId either from query string or from form input using REQUEST
 
    if(!isset($_REQUEST['unitId']) && !isset($_REQUEST['unitId']))
    {
       echo '<h2> Error: unitId has not been set.</h2>
              <p> Please go back and try again.
                <a href="'.$linkToCancelPage.'">BACK.</a>
             </p>';
   
       exit();
    }
    else
    {
       $unitId =  (int)$_REQUEST['unitId'];
    }
 

 if(!isset($confirmDelete) || $confirmDelete!==1)
 {
   // if confirm delete button is not clicked, display confirm form
   // link to delete.php carrying dataId as query string
       $linkToDeleteYes = Link::Build('admin/delete.php?table=3&unitId='.$unitId.'&confirm=1');
         
       
       $linkToDeleteNo=  '<a class="datalink" title="Delete  record" href="'.
                      $linkToCancelPage. '"></a>';
                      
        echo '<center><big>';
                      
        echo '<p>'.'Are you sure you want to delete Unit '.
              $unitId.' ?'.
             '</p>'.'<br />'.'<b>'.
              '<a href="'. $linkToDeleteYes.'">'. 'YES'.
             '</a>'.'</b>&nbsp;&nbsp;&nbsp;&nbsp;'.
             
             '<a href="'. $linkToCancelPage.'">'. 'NO'.
             '</a>'.'</b><br />' ;
        
        echo '</big></center>';
 
 
 }
 
 elseif($confirmDelete)
 {


  // check for record ID
  if ((isset($unitId)) && (!empty($unitId))) 
  { 
     // unit_id is found in two tables unit and domain_unit tables
     // hence we need to delete record from two tables starting with domain_unit
     
       /***UNCOMMENT SQL DELETE CODE AFTER TEST  
        $query1 = "DELETE FROM domain_unit WHERE  unit_id = '$unitId'";
                 
        $lastDeleteId1 = executeQuery($query1, $params = null);
        
         $query2 = "DELETE FROM unit WHERE  unit_id = '$unitId'";
                 
        $lastDeleteId2 = executeQuery($query2, $params = null);
        
         // successful record delete flag set to true
           $deleteRecordSuccessful = true;
        ***/
        
       
         $deleteRecordSuccessful = true;
         
         
         // display delete success message to user
        if($deleteRecordSuccessful == true)
        {
          // if update is successful
          echo  '<center><h2>Record Deleted Successfully!</h2></center>';
          echo '<center>';
          echo '<span style="float:center;">'.'<b>'.'<a href="'.
             Link::Build('admin/unit.php').'">'.' Go Back to unit Tab'.'</a>'.'</b>'.'</span>' ;
          echo '</center>';
     
     
         }
          elseif($deleteRecordSuccessful == false)
         {
            
           echo  '<center><h2 class="error">
                       Error: Unable to delete record!</h2></center>';
           echo '<center>';
           echo '<p>Problem encountered while trying to delete record.</p>';
           echo '<span style="float:center;">'.'<b>'.'<a href="'.
           Link::Build('admin/unit.php').'">'.' Go Back to unit Tab'.'</a>'.'</b>'.'</span>' ;
           echo '</center>';
     
         }
    
     }

   
    unset($database_handler);
 
 
   exit(); 
  }
 
}

elseif($table == $databaseTable['domain_unit'])
{
   echo  '<center><h2 class="error">
                      Records in these table are deleted automatically.</h2></center>';
           echo '<center>';
           echo '<p>When a unit is deleted, all its entries in the domain_unit
                    table are also deleted.</p>';
           echo '<span style="float:center;">'.'<b>'.'<a href="'.
           Link::Build('admin/unit.php').'">'.' Go Back'.'</a>'.'</b>'.'</span>' ;
           echo '</center>';
 
}


elseif($table == $databaseTable['user'])
{
 // get recordId either from query string or from form input using REQUEST
 
    if(!isset($_REQUEST['userName']) && !isset($_REQUEST['userName']))
    {
       echo '<h2> Error: Username has not been set.</h2>
              <p> Please go back and try again.
                <a href="'.$linkToCancelPage.'">BACK.</a>
             </p>';
   
       exit();
    }
    else
    {
       $userName =  $_REQUEST['userName'];
    }
 

 if(!isset($confirmDelete) || $confirmDelete!==1)
 {
   // if confirm delete button is not clicked, display confirm form
   // link to delete.php carrying dataId as query string
       $linkToDeleteYes = Link::Build('admin/delete.php?table=5&userName='.$userName.'&confirm=1');
         
       
       $linkToDeleteNo=  '<a class="datalink" title="Delete  record" href="'.
                      $linkToCancelPage. '"></a>';
                      
        echo '<center><big>';
                      
        echo '<p>'.'Are you sure you want to delete User '.
              $userName.' ?'.
             '</p>'.'<br />'.'<b>'.
              '<a href="'. $linkToDeleteYes.'">'. 'YES'.
             '</a>'.'</b>&nbsp;&nbsp;&nbsp;&nbsp;'.
             
             '<a href="'. $linkToCancelPage.'">'. 'NO'.
             '</a>'.'</b><br />' ;
        
        echo '</big></center>';
 
 
 }
 
 elseif($confirmDelete)
 {


  // check for record ID
  if ((isset($userName)) && (!empty($userName)) ) 
  { 
     // tab_id is not related to any other table in dB, so delete straight away
     
       /***UNCOMMENT SQL DELETE CODE AFTER TEST 
        $query = "DELETE FROM user WHERE  username = '$userName'";
                 
        $lastDeleteId = executeQuery($query, $params = null);
        
         // successful record delete flag set to true
           $deleteRecordSuccessful = true;
       ***/
        
       
         $deleteRecordSuccessful = true;
         
         
         // display delete success message to user
        if($deleteRecordSuccessful == true)
        {
          // if update is successful
          echo  '<center><h2>Record Deleted Successfully!</h2></center>';
          echo '<center>';
          echo '<span style="float:center;">'.'<b>'.'<a href="'.
             Link::Build('admin/user.php').'">'.' Go Back to User Tab'.'</a>'.'</b>'.'</span>' ;
          echo '</center>';
     
     
         }
          elseif($deleteRecordSuccessful == false)
         {
            
           echo  '<center><h2 class="error">
                       Error: Unable to delete record!</h2></center>';
           echo '<center>';
           echo '<p>Problem encountered while trying to delete record.</p>';
           echo '<span style="float:center;">'.'<b>'.'<a href="'.
           Link::Build('admin/domain_tab.php').'">'.' Go Back to User'.'</a>'.'</b>'.'</span>' ;
           echo '</center>';
     
         }
    
     }

   
    unset($database_handler);
 
 
   exit(); 
  }

 
}

elseif($table == $databaseTable['user_data'])
{

 echo "I am there";
 // get recordId either from query string or from form input using REQUEST
 
    if(!isset($_REQUEST['userName']) && !isset($_REQUEST['userName']))
    {
       echo '<h2> Error: Username has not been set.</h2>
              <p> Please go back and try again.
                <a href="'.$linkToCancelPage.'">BACK.</a>
             </p>';
   
       exit();
    }
    else
    {
       $userName =  $_REQUEST['userName'];
    }
 

 if(!isset($confirmDelete) || $confirmDelete!==1)
 {
   // if confirm delete button is not clicked, display confirm form
   // link to delete.php carrying dataId as query string
       $linkToDeleteYes = Link::Build('admin/delete.php?table=5&userName='.$userName.'&confirm=1');
         
       
       $linkToDeleteNo=  '<a class="datalink" title="Delete  record" href="'.
                      $linkToCancelPage. '"></a>';
                      
        echo '<center><big>';
                      
        echo '<p>'.'Are you sure you want to delete User '.
              $userName.' ?'.
             '</p>'.'<br />'.'<b>'.
              '<a href="'. $linkToDeleteYes.'">'. 'YES'.
             '</a>'.'</b>&nbsp;&nbsp;&nbsp;&nbsp;'.
             
             '<a href="'. $linkToCancelPage.'">'. 'NO'.
             '</a>'.'</b><br />' ;
        
        echo '</big></center>';
 
 
 }
 
 elseif($confirmDelete)
 {


  // check for record ID
  if ((isset($userName)) && (!empty($userName)) ) 
  { 
     // tab_id is not related to any other table in dB, so delete straight away
     
       /***UNCOMMENT SQL DELETE CODE AFTER TEST
        $query = "DELETE FROM domain_tab WHERE  tab_id = '$tabId'";
                 
        $lastDeleteId = executeQuery($query, $params = null);
        
         // successful record delete flag set to true
           $deleteRecordSuccessful = true;
        ***/
       
         $deleteRecordSuccessful = true;
         
         
         // display delete success message to user
        if($deleteRecordSuccessful == true)
        {
          // if update is successful
          echo  '<center><h2>Record Deleted Successfully!</h2></center>';
          echo '<center>';
          echo '<span style="float:center;">'.'<b>'.'<a href="'.
             Link::Build('admin/user.php').'">'.' Go Back to User Tab'.'</a>'.'</b>'.'</span>' ;
          echo '</center>';
     
     
         }
          elseif($deleteRecordSuccessful == false)
         {
            
           echo  '<center><h2 class="error">
                       Error: Unable to delete record!</h2></center>';
           echo '<center>';
           echo '<p>Problem encountered while trying to delete record.</p>';
           echo '<span style="float:center;">'.'<b>'.'<a href="'.
           Link::Build('admin/domain_tab.php').'">'.' Go Back to User'.'</a>'.'</b>'.'</span>' ;
           echo '</center>';
     
         }
    
     }

   
    unset($database_handler);
 
 
   exit(); 
  }

 
}





?>


   </div> 
 </body>
</html>