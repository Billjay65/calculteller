<?php
// start session, authenticate user and store variables coming from domain for display
 session_start();
 
 // Obtaining root directory  from admin folder
 define('SITE_ROOT3', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT3.'/include/config.php';
   

// include error handling class php file
 require_once SITE_ROOT3.'/error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 $user_name = (!isset($_SESSION['username']))? '' : 'Hi, ADMIN' ;


  // Authenticate Admin user
 if((!isset($_SESSION['username']) || $_SESSION['username']=='') ||
      ((isset($_SESSION['username'])) && ($_SESSION['username']!== ADMIN_USERNAME)))  
 { 
 
  fixed_html_header('CalculTELLER: Access Denied, Admins only',
                      'Unqualified User', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please BE WARNED! Only Admins can access this page</h2></center>';
 echo '<p class="login_advice">';
 echo  'Please leave this page if you are NOT an Admin. If you are an admin,
        login in to gain full access';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('admin/login_admin.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
 }
 
 
// check for table ID. If it is not set EXIT code execution
if ((!isset($_REQUEST['table']) || trim($_REQUEST['table']) == '')) 
{ 
    fixed_html_header('CalculTELLER: Missing Table Id-Admin Module',
                      'Admin (Change) Functions', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display missing table ID Error message to user
    echo '<center>';
    echo '<p>Missing table ID!</p>'; 
    echo '<p> .
          <a href="domain.php">Please Try Again!</a>
         </p>';
    echo '<center>';
    

fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
}




 //get table number either from query string or from form input using REQUEST

 $table =  (!isset($_REQUEST['table']))? null : (int)$_REQUEST['table'];

 
  
  

// define associative array to hold keys and values of database table
$databaseTable = array(
         'domain' => 1,
         'domain_tab' => 2,
         'unit' => 3,
         'domain_unit' => 4,
         'user' => 5,
         'user_data' => 6);
         

    // display input validation error 
    function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        return "<div class=\"error\">ERROR: Invalid data for field '$key'</div>"; 
      } else { 
        return false; 
      } 
    } 
    
    // successful record update flat set to false
    $addRecordSuccessful = false;
    
    // error flag variable
    $errorFlag = 0;
    
    //$errorHeader = 'ERROR: Form filled incorrectly, Please correct error';
    $errorHeader = '';
   
   $linkToCancelPage = Link::Build('admin/index.php'); 
   
   // define error array to hold errors
  $inputErrors = array();      
 
   // if table ID is set, start testing the values of table id and execute
   // the appropriate code below. Start by displaying html header
                                               
?>   

   <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

 <head>
   
 <title> Caclteller:Administration Module, Add Record </title>
   
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link rel="icon" type="image/png" href="images/logo2.png" />
  
   <link type="text/css" rel="stylesheet" href=<?php echo Link::Build('styles/admin_styles.css'); ?> />
  
  
  </head>
  
  
  
<body> 



<!-- standard page header -->


<div id="doc">

<div class="admin_header">
<a href=<?php echo  Link::Build('admin/index.php'); ?> >
 <img src="<?php echo Link::Build('images/admin_logo.png'); ?>" alt='Logo-calculteller' border=0
     align='left'  height = "100%" width ="7%"  />
</a> 
<span id="app">&nbsp; CalculTELLER:</span> &nbsp;

<span id="page">Admin-Add Record</span> 

<p class="account_tab" >
  
  
  <a title="Admin Home Page" href="<?php echo Link::Build('admin/index.php'); ?>">
   Admin Home
  </a>
  <a title="Go back to main site" href="<?php echo Link::Build('index.php'); ?>">
   Real Site
  </a>
</p>
 
</div>

<?php


// check which table Id has been set and execute the appropriate code
if($table == $databaseTable['domain'])
{
  // if domain table choosen. That is table 1, execute code to display form
  // to add a new domain to dB
    $name =  (!isset($_POST['name']))? '': $_POST['name'];
    $description =  (!isset($_POST['description']))? '': $_POST['description'];
    $image =  (!isset($_POST['image']))? '': $_POST['image'];

   if (!isset($_POST['submit']))
   {
      // if form is not yet submitted display empty form to collect domain info
      
      ?>
      
        <table cellspacing="5" cellpadding="5">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

           <input type="hidden" name="table" value="<?php echo $table; ?>">
          
          
           
            <tr>
              <td colspan="2"> 
               <h1> CalculTELLER: Add domain Record:  Add domain record </h1>
  
             </td>
            </tr>
             
    
           <tr>
               <td valign="top"><b>Name</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="name"
                   value="<?php echo $name; ?>" >
      
                 </td>
           </tr>                   
           <tr>
                <td valign="top"><b>Description</b></td>
                <td>
                  <textarea name="description" cols="60" rows="8" > 
                  <?php echo $description; ?>
                   </textarea>
       
                </td>
           </tr>
           <tr>
             <td valign="top"><b>Image</b></td>
             <td>
                <input size="50" maxlength="50" type="text" name="image" 
                value="<?php echo $image; ?>">
                    
              </td>
          </tr>    
          <tr> 
            <td colspan="2">
        
                <input type="Submit" name="submit" value="Add">
          
               <a title="Go to Admin Home Page" href="<?php echo $linkToCancelPage; ?>">
                  |Cancel|
               </a>
           </td>
          </tr>
        </form>
      </table>
     
     <?php
     
     
    
     
   }
   else if(isset($_POST['submit']) ) 
   
   {
   
   
   
          // if update button is clicked  and there are errors
         // define valid array to hold sanitized values
         $valid = array(); 
   
         // define link to previous page
        $linkToPreviousPage = $_SERVER['HTTP_REFERER'];
     
      if (!empty($_POST['name']) ) { 
        $valid['name'] = htmlentities(trim($_POST['name']));  
      } else { 
        $inputErrors[] = 'Name'; 
        $errorFlag = 1; 
      } 
      
     if (!empty($_POST['description']) && !(trim($_POST['description'])=='')) { 
        $valid['description'] = htmlentities(trim($_POST['description']));  
      } else { 
        $inputErrors[] = 'Description'; 
        $errorFlag = 2; 
      } 
      
       if (!empty($_POST['image']) ) { 
        $valid['image'] = htmlentities(trim($_POST['image']));  
      } else { 
        $inputErrors[] = 'Image'; 
        $errorFlag = 3; 
      } 
      
      
      if(count($inputErrors) > 0 && $errorFlag > 0 ) 
      
      {
      
          
          if($errorFlag > 0)
          {
       
           // display global error message and link to previous page 
            echo '<center><br /> <br /><br />'; 
            echo   '<span class="error">'.'Error: Form filled incorrectly!'.
                  ' </span>'.'<br />'.'<b>'.
                 '<a href="'. $linkToPreviousPage .'">'. ' BACK (Go to Previous page)'.
                  '</a>'.'</b>' ;
                  
            echo '</center><br /> ';
          }
          
         
       
        // display error encountered in each input field
         echo  getInputError('Name', $inputErrors);   
         echo  getInputError('Description', $inputErrors);
         echo  getInputError('Image', $inputErrors); 
       }
    
       if(count($inputErrors) == 0 && $errorFlag == 0) 
   
      {
  
        // if data is valid, sanitize data before Adding record to database
        // if there are NO ERRORS in input, add data in database
        
       $name = addslashes($valid['name']) ;
                                               
       $description  = addslashes($valid['description']);

       $image = addslashes($valid['image']);
       
      
    
       $lastAddedId = '';
       
       
         
    // Add domain to domain data into database 
    // Build the SQL query
  
    $sql = "INSERT INTO domain (name, description, image)  VALUES
          ('$name', '$description','$image')";
               
                       
    // Execute the query
     $lastAddedId = executeQuery($sql, $params = null);
     
    // Select domain Id and All units in database to add to domian_unit table 
     $sql = " SELECT d.domain_id, u.unit_id 
              FROM        domain d
              INNER JOIN  unit u
              WHERE  d.domain_id = '$lastAddedId'"; 
    
    // Execute the query to get domain and all units to new domain
     $domainUnits = getAll($sql, $params = null);
     
    
     for($i=0; $i < count($domainUnits); $i++)
     {
        // insert domain and all units into the domain_unit table
         
         $domainId = $domainUnits[$i]['domain_id'];
         $unitId = $domainUnits[$i]['unit_id'];
         
      $sql = "INSERT INTO domain_unit (domain_id, unit_id)  VALUES
               ('$domainId', '$unitId')"; 
      $lastAddedDomainUnitIds = executeQuery($sql, $params = null);
     }
    
     
     $addRecordSuccessful = true;
    
     unset($database_handler); 
   
   
    
     
  } 
  
  
   if($addRecordSuccessful==true )
   {
       // if update is successful
          echo '<center><br /> <br /><br />';
          echo '<span class="success">'.'Domain Added Successfully! '.
               'Domain Id: '. $lastAddedId. '</span>'.'<br />'.'<br />'.'<b>'.
             '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
   
    }
    
    elseif($addRecordSuccessful==false)
    {
       // if update is Not successful
          echo '<center><br /> <br /><br />';
          echo '<span class="error">'.'Error: Unable to Add domain!'.
                '<br />'.'<br />'.'<b>'.
               '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
     
    }
    
   
 } 
  
  
   
  
}



else if($table == $databaseTable['domain_tab'])
{
  // if domain_tab  choosen. That is table 2, execute code to display form
  // to add a new domain to dB
  
   $domainId =  (!isset($_POST['domainId']))? '': $_POST['domainId'];
    $tabName =  (!isset($_POST['tabName']))? '': $_POST['tabName'];
   

   if (!isset($_POST['submit']))
   {
      // if form is not yet submitted display empty form to 
      // collect new domain_tab  info
      
      ?>
      
        <table cellspacing="5" cellpadding="5">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

           <input type="hidden" name="table" value="<?php echo $table; ?>">
          
          
           
            <tr>
              <td colspan="2"> 
               <h1> CalculTELLER: Add domain_tab Record:  Add new tab to a domain</h1>
  
             </td>
            </tr>
             
    
           <tr>
               <td valign="top"><b>Domain ID</b></td>
                 <td>
      
                   <input size="11" maxlength="11" type="text" name="domainId" 
                       value="<?php echo $domainId; ?>" >
      
                 </td>
           </tr>                       
           <tr>
                <td valign="top"><b>Tab_Name</b></td>
                <td>
                  <input size="50" maxlength="50" type="text" name="tabName" 
                       value="<?php echo $tabName; ?>" >
       
                </td>
           </tr>
           
          <tr> 
            <td colspan="2">
        
                <input type="Submit" name="submit" value="Add">
          
               <a title="Go to Admin Home Page" href="<?php echo $linkToCancelPage; ?>">
                  |Cancel|
               </a>
           </td>
          </tr>
        </form>
      </table>
     
     <?php
     
     
    
     
   }
   else if(isset($_POST['submit']) ) 
   
   {
   
   
   
          // if update button is clicked  and there are errors
         // define valid array to hold sanitized values
         $valid = array(); 
   
         // define link to previous page
        $linkToPreviousPage = $_SERVER['HTTP_REFERER'];
     
      if (!empty($_POST['domainId']) && is_numeric($_POST['domainId']) ) { 
        $valid['domainId'] = htmlentities(trim($_POST['domainId']));  
      } else { 
        $inputErrors[] = 'Domain ID'; 
        $errorFlag = 1; 
      } 
      
     if (!empty($_POST['tabName']) ) { 
        $valid['tabName'] = htmlentities(trim($_POST['tabName']));  
      } else { 
        $inputErrors[] = 'Tab_name'; 
        $errorFlag = 2; 
      } 
      
      
      
      if(count($inputErrors) > 0 && $errorFlag > 0 ) 
      
      {
      
          
          if($errorFlag > 0)
          {
       
           // display global error message and link to previous page 
            echo '<center><br /> <br /><br />'; 
            echo   '<span class="error">'.'Error: Form filled incorrectly!'.
                  ' </span>'.'<br />'.'<b>'.
                 '<a href="'. $linkToPreviousPage .'">'. ' BACK (Go to Previous page)'.
                  '</a>'.'</b>' ;
                  
            echo '</center><br /> ';
          }
          
         
       
        // display error encountered in each input field
         echo  getInputError('Domain ID', $inputErrors);   
         echo  getInputError('Tab_name', $inputErrors);
          
       }
    
       if(count($inputErrors) == 0 && $errorFlag == 0) 
   
      {
  
        // if data is valid, sanitize data before Adding record to database
        // if there are NO ERRORS in input, add data in database
        
       $domainId = addslashes($valid['domainId']) ;
                                               
       $tabName  = addslashes($valid['tabName']);

    
       $lastAddedId = '';
       
       
         
    // Add domain to domain data into database 
    // Build the SQL query
  
    $sql = "INSERT INTO domain_tab (domain_id, tab_name)  VALUES
          ('$domainId', '$tabName')";
               
                       
    // Execute the query
     $lastAddedId = executeQuery($sql, $params = null);
     
     
     $addRecordSuccessful = true; 
    
     unset($database_handler); 
   
       
  } 
  
  
   if($addRecordSuccessful==true )
   {
       // if update is successful
          echo '<center><br /> <br /><br />';
          echo '<span class="success">'.'Tab Added Successfully! '.
               'Tab Id: '. $lastAddedId. '</span>'.'<br />'.'<br />'.'<b>'.
             '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
   
    }
    elseif($addRecordSuccessful==false)
    {
       // if update is Not successful
          echo '<center><br /> <br /><br />';
          echo '<span class="error">'.'Error: Unable to tab!'.
                '<br />'.'<br />'.'<b>'.
               '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
     
    }
   
 } 
  
  
   
  
} 

else if($table == $databaseTable['unit'])
{
    // if unit table  choosen. That is table 3, execute code to display form
    // to add a new domain to dB
    
   $abbrevation =  (!isset($_POST['abbrevation']))? '': $_POST['abbrevation'];
    $unitName =  (!isset($_POST['unitName']))? '': $_POST['unitName'];
   

   if (!isset($_POST['submit']))
   {
      // if form is not yet submitted display empty form to 
      // collect new domain_tab  info
      
      ?>
      
        <table cellspacing="5" cellpadding="5">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

           <input type="hidden" name="table" value="<?php echo $table; ?>">
          
          
           
            <tr>
              <td colspan="2"> 
               <h1> CalculTELLER: Add domain_tab Record:  Add new tab to a domain</h1>
  
             </td>
            </tr>
             
    
            <tr>
               <td valign="top"><b>Abbreviation</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="abbrevation" 
                       value="<?php echo $abbrevation; ?>" >
      
                 </td>
           </tr>                   
           <tr>
                <td valign="top"><b>Unit_name</b></td>
                <td>
                  <input size="50" maxlength="50" type="text" name="unitName" 
                       value="<?php echo $unitName; ?>" >
       
                </td>
           </tr>
           
          <tr> 
            <td colspan="2">
        
                <input type="Submit" name="submit" value="Add">
          
               <a title="Go to Admin Home Page" href="<?php echo $linkToCancelPage; ?>">
                  |Cancel|
               </a>
           </td>
          </tr>
        </form>
      </table>
     
     <?php
     
     
    
     
   }
   else if(isset($_POST['submit']) ) 
   
   {
   
   
   
          // if update button is clicked  and there are errors
         // define valid array to hold sanitized values
         $valid = array(); 
   
         // define link to previous page
        $linkToPreviousPage = $_SERVER['HTTP_REFERER'];
     
      if (!empty($_POST['abbrevation']) ) { 
        $valid['abbrevation'] = htmlentities(trim($_POST['abbrevation']));  
      } else { 
        $inputErrors[] = 'Abbreviation'; 
        $errorFlag = 1; 
      } 
      
     if (!empty($_POST['unitName']) ) { 
        $valid['unitName'] = htmlentities(trim($_POST['unitName']));  
      } else { 
        $inputErrors[] = 'Unit_name'; 
        $errorFlag = 2; 
      } 
      
      
      
      
      if(count($inputErrors) > 0 && $errorFlag > 0 ) 
      
      {
      
          
          if($errorFlag > 0)
          {
       
           // display global error message and link to previous page 
            echo '<center><br /> <br /><br />'; 
            echo   '<span class="error">'.'Error: Form filled incorrectly!'.
                  ' </span>'.'<br />'.'<b>'.
                 '<a href="'. $linkToPreviousPage .'">'. ' BACK (Go to Previous page)'.
                  '</a>'.'</b>' ;
                  
            echo '</center><br /> ';
          }
          
         
       
        // display error encountered in each input field
         echo  getInputError('Abbreviation', $inputErrors);   
         echo  getInputError('Unit_name', $inputErrors);
          
       }
    
       if(count($inputErrors) == 0 && $errorFlag == 0) 
   
      {
  
        // if data is valid, sanitize data before Adding record to database
        // if there are NO ERRORS in input, add data in database
        
       $abbrevation = addslashes($valid['abbrevation']) ;
                                               
       $unitName  = addslashes($valid['unitName']);

    
       $lastAddedId = '';
       
       
         
       // Add unit to unit table in database 
       // Build the SQL query
  
       $sql = "INSERT INTO unit (abbrevation, unit_name)  VALUES
              ('$abbrevation', '$unitName')";
              
  
                        
       // Execute the query
       $lastAddedId = executeQuery($sql, $params = null);
     
      // Select all domain ids and  last unit inserted into unit table 
      $sql = " SELECT d.domain_id, u.unit_id 
               FROM        domain d
               INNER JOIN  unit u
               WHERE  u.unit_id = '$lastAddedId'"; 
    
      // Execute the query to get domain and all units to new domain
      $domainsUnit = getAll($sql, $params = null);
     
    
      for($i=0; $i < count($domainsUnit); $i++)
      {
         // insert domain and all units into the domain_unit table
         
         $domainId = $domainsUnit[$i]['domain_id'];
         $unitId = $domainsUnit[$i]['unit_id'];
         
        $sql = "INSERT INTO domain_unit (domain_id, unit_id)  VALUES
               ('$domainId', '$unitId')"; 
        $lastAddedDomainUnitIds = executeQuery($sql, $params = null);
      }
    
    
        $addRecordSuccessful = true;
    
        unset($database_handler); 
                           
    } 
  
    
     
  
  
   if($addRecordSuccessful==true )
   {
       // if update is successful
          echo '<center><br /> <br /><br />';
          echo '<span class="success">'.'unit Added Successfully! '.
               'Unit Id: '. $lastAddedId. '</span>'.'<br />'.'<br />'.'<b>'.
             '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
   
    }
     elseif($addRecordSuccessful==false)
    {
       // if update is Not successful
          echo '<center><br /> <br /><br />';
          echo '<span class="error">'.'Error: Unable to Add domain!'.
                '<br />'.'<br />'.'<b>'.
               '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
     
    }  
    
    
       
 }
 
 
}


?>

 </div> 
 </body>
</html>
