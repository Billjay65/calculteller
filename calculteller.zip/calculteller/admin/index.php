<?php
// start session, authenticate user and store variables coming from domain for display
 session_start();
 
 // Obtaining root directory  from admin folder
 define('SITE_ROOT3', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT3.'/include/config.php';
   

// include error handling class php file
 require_once SITE_ROOT3.'/error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 $user_name = (!isset($_SESSION['username']))? '' : 'Hi, ADMIN' ;


  // Authenticate Admin user
 if((!isset($_SESSION['username']) || $_SESSION['username']=='') ||
      ((isset($_SESSION['username'])) && ($_SESSION['username']!== ADMIN_USERNAME)))  
 { 
 
  fixed_html_header('CalculTELLER: Access Denied, Admins only',
                      'Unqualified User', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please BE WARNED! Only Admins can access this page</h2></center>';
 echo '<p class="login_advice">';
 echo  'Please leave this page if you are NOT an Admin. If you are an admin,
        login in to gain full access';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('admin/login_admin.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
 }
 

                                               
?>   
   
   
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

 <head>
   
 <title>Administration Module: Calculteller </title>
   
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
 <meta name="viewport" content="width=device-width, initial-scale=1.0" />
 
  <link rel="icon" type="image/png" href="images/logo2.png" />
  
   
   <link type="text/css" rel="stylesheet" href=<?php echo Link::Build('styles/admin_styles.css'); ?> />
   
  
  
  </head>
  
  
<body> 



<!-- standard page header -->


<div id="doc">

<div class="admin_header">
   <a href=<?php echo  Link::Build('admin/index.php'); ?> >
      <img src="<?php echo Link::Build('images/admin_logo.png'); ?>" alt='Logo-calculteller' border=0
        style="float:left; max-width: 100%;" />
   </a> 

   <span id="app">&nbsp; CalculTELLER:</span> &nbsp;

   <span id="page">Administration Module</span>
    
   
   <span id="help_logout">
       <a title="help" href=<?php echo  Link::Build('forum.php'); ?> >
        HELP|
       </a>
  
       <a title="logout" href=<?php echo  Link::Build('logout.php'); ?> >
        Logout|
       </a> 
       
       <a href=<?php echo  Link::Build('login.php'); ?> >
        Login
       </a>
    </span> 
   

    <span class="user_name">
       <?php 
       echo '<span>'.$user_name.' '.'</span>';
       
       if(!empty($user_name))
       { 
         echo '<a href="'.Link::Build('myaccount.php').'">';
         echo '<img id="user_image" src="'.Link::Build('images/user_image.png').'" alt="user_image" />';
         echo '</a>';
       }
       ?>
    </span>  
    
    <p class="account_tab" >
      <a title="Edit domain table" href="<?php echo Link::Build('admin/domain.php'); ?>">
        domain
      </a>
      <a title="Edit domain_tab table" href="<?php echo Link::Build('admin/domain_tab.php'); ?>">
       domain_tab
      </a>
      <a title="Edit unit table " href="<?php echo Link::Build('admin/unit.php'); ?>">
       unit
      </a>
      <a title="Edit domain_unit table" href="<?php echo Link::Build('admin/domain_unit.php'); ?>">
       domain_unit
      </a>
  
      <a title="Edit user table" href="<?php echo Link::Build('admin/user.php'); ?>">
       user
      </a>
      <a title="Edit user_data" href="<?php echo Link::Build('admin/user_data.php'); ?>">
       user_data
      </a>
      <a title="Go back to main site" href="<?php echo Link::Build('index.php'); ?>">
       Real Site
      </a>
    </p>
 


</div>

<!-- admin_content-->

<div class="admin_content">

  <h1> Calculteller: Administration section</h1>
  <h2>Please select a database table to view and edit from the list below</h2>
  
  <ul>
  
  <li>
  <a title="Edit domain table" href="<?php echo Link::Build('admin/domain.php'); ?>">
  domain
  </a> 
  </li>
  
  
   <li>
  <a title="Edit domain_tab table" href="<?php echo Link::Build('admin/domain_tab.php'); ?>">
   domain_tab
  </a>
  </li>
  
  <li>
  <a title="Edit unit table " href="<?php echo Link::Build('admin/unit.php'); ?>">
   unit
  </a>
  </li>
  
  <li>
  <a title="Edit domain_unit table" href="<?php echo Link::Build('admin/domain_unit.php'); ?>">
   domain_unit
  </a>
  </li>
  
  <li>
  <a title="Edit user table" href="<?php echo Link::Build('admin/user.php'); ?>">
   user
  </a>
  </li>
  
  <li>  
  <a title="Edit user_data" href="<?php echo Link::Build('admin/user_data.php'); ?>">
   user_data
  </a>
  </li>
  
  <li>
  <a title="Go back to main site" href="<?php echo Link::Build('index.php'); ?>">
   Home page
  </a>
  </li>


</div> <br /><br /><br /><br />
<!-- standard page footer -->

   <div id="formft">
     <hr />
    <p>Terms and Conditions | Privacy Policy | Support(image) | Tel (image)651817527 </p>
    <p> Copyright © 2017, CalculTeller SIKEH (signature at bottom right in Gold color or Silver.)</p>
     
   </div>
  </div> 
 </body>
</html>
