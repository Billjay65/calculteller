<?php

// start session, authenticate user and store variables coming from domain for display
 session_start();
 
 // Obtaining root directory  from admin folder
 define('SITE_ROOT3', dirname(dirname(__FILE__)));
 

// include config file containing directory paths
 require_once SITE_ROOT3.'/include/config.php';
   

// include error handling class php file
 require_once SITE_ROOT3.'/error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 $user_name = (!isset($_SESSION['username']))? '' : 'Hi, ADMIN' ;


  // Authenticate Admin user
 if((!isset($_SESSION['username']) || $_SESSION['username']=='') ||
      ((isset($_SESSION['username'])) && ($_SESSION['username']!== ADMIN_USERNAME)))  
 { 
 
  fixed_html_header('CalculTELLER: Access Denied, Admins only',
                      'Unqualified User', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please BE WARNED! Only Admins can access this page</h2></center>';
 echo '<p class="login_advice">';
 echo  'Please leave this page if you are NOT an Admin. If you are an admin,
        login in to gain full access';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('admin/login_admin.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
 }
 
 
 
// check for table ID. If it is not set EXIT code execution
if ((!isset($_REQUEST['table']) || trim($_REQUEST['table']) == '')) 
{ 
    fixed_html_header('CalculTELLER: Missing Table Id-Admin Module',
                      'Admin (Change) Functions', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display missing table ID Error message to user
    echo '<center>';
    echo '<p>Missing table ID!</p>'; 
    echo '<p> .
          <a href="domain.php">Please Try Again!</a>
         </p>';
    echo '<center>';
    

fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
}



 //get table number either from query string or from form input using REQUEST

 $table =  (!isset($_REQUEST['table']))? null : (int)$_REQUEST['table'];

 //get domain Id from submitted form or from query string and obtain data from dB
  $domainId = (!isset($_REQUEST['domainId']))? null: (int)$_REQUEST['domainId'];
  
  //get tab Id from submitted form or from query string and obtain data from dB
  $tabId = (!isset($_REQUEST['tabId']))? null: (int)$_REQUEST['tabId'];
  
  //get unit Id from submitted form or from query string and obtain data from dB
  $unitId = (!isset($_REQUEST['unitId']))? null: (int)$_REQUEST['unitId'];
  
  
  //get Username from submitted form or from query string and obtain data from dB
  $userName = (!isset($_REQUEST['userName']))? null: $_REQUEST['userName'];
  
  //get unit Id from submitted form or from query string and obtain data from dB
  $dataId = (!isset($_REQUEST['dataId']))? null: (int)$_REQUEST['dataId'];
  
  

// define associative array to hold keys and values of database table
$databaseTable = array(
         'domain' => 1,
         'domain_tab' => 2,
         'unit' => 3,
         'domain_unit' => 4,
         'user' => 5,
         'user_data' => 6);
         

    // display input validation error 
    function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        return "<div class=\"error\">ERROR: Invalid data for field '$key'</div>"; 
      } else { 
        return false; 
      } 
    } 
    
    // successful record update flat set to false
    $updateRecordSuccessful = false;
    
    // error flag variable
    $errorFlag = 0;
    
    //$errorHeader = 'ERROR: Form filled incorrectly, Please correct error';
    $errorHeader = '';
   
   $linkToCancelPage = Link::Build('admin/index.php'); 
   
   // define error array to hold errors
  $inputErrors = array();      
 
   // if table ID is set, start testing the values of table id and execute
   // the appropriate code below. Start by displaying html header
                                               
?>   

   <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

 <head>
   
 <title> Caclteller:Administration Module, Edit Record </title>
   
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link rel="icon" type="image/png" href="images/logo2.png" />
  
   <link type="text/css" rel="stylesheet" href=<?php echo Link::Build('styles/admin_styles.css'); ?> />
  
  
  </head>
  
  
  
<body> 



<!-- standard page header -->


<div id="doc">

<div class="admin_header">
<a href=<?php echo  Link::Build('admin/index.php'); ?> >
 <img src="<?php echo Link::Build('images/admin_logo.png'); ?>" alt='Logo-calculteller' border=0
     align='left'  height = "100%" width ="7%"  />
</a> 
<span id="app">&nbsp; CalculTELLER:</span> &nbsp;

<span id="page">Admin-Edit Record</span> 

<p class="account_tab" >
  
  
  <a title="Admin Home Page" href="<?php echo Link::Build('admin/index.php'); ?>">
   Admin Home
  </a>
  <a title="Go back to main site" href="<?php echo Link::Build('index.php'); ?>">
   Real Site
  </a>
</p>
 
</div>


<?php


// check which table Id has been set and execute the appropriate code

// if domain table has been chosen, execute the following code
if($table == $databaseTable['domain'])
{


   if(isset($_POST['submit']) ) 
   
   {
  
          // if update button is clicked  and there are errors
         // define valid array to hold sanitized values
         $valid = array(); 
   
         // define link to previous page
        $linkToPreviousPage = $_SERVER['HTTP_REFERER'];
     
      if (!empty($_POST['name']) ) { 
        $valid['name'] = htmlentities(trim($_POST['name']));  
      } else { 
        $inputErrors[] = 'Name'; 
        $errorFlag = 1; 
      } 
      
     if (!empty(trim($_POST['description'])) ) { 
        $valid['description'] = htmlentities(trim($_POST['description']));  
      } else { 
        $inputErrors[] = 'Description'; 
        $errorFlag = 2; 
      } 
      
       if (!empty($_POST['image']) ) { 
        $valid['image'] = htmlentities(trim($_POST['image']));  
      } else { 
        $inputErrors[] = 'Image'; 
        $errorFlag = 3; 
      } 
      
      
      if(count($inputErrors) > 0 && $errorFlag > 0 ) 
      
      {
      
          
          if($errorFlag > 0)
          {
       
           // display global error message and link to previous page 
            echo '<center><br /> <br /><br />'; 
            echo   '<span class="error">'.'Error: Form filled incorrectly!'.
                  ' </span>'.'<br />'.'<b>'.
                 '<a href="'. $linkToPreviousPage .'">'. ' BACK (Go to Previous page)'.
                  '</a>'.'</b>' ;
                  
            echo '</center><br /> ';
          }
          
          
       
        // display error encountered in each input field
         echo getInputError('Name', $inputErrors);   
         echo getInputError('Description', $inputErrors);
         echo  getInputError('Image', $inputErrors); 
    }
    
       if(count($inputErrors) == 0 && $errorFlag == 0) 
   
      {
  
     // if data is valid, sanitize data before Updating record in database
     // if there are NO ERRORS in input, update data in database
        $domainId  = addslashes((int)trim($domainId));
        
       $name = addslashes($valid['name']) ;
                                               
       $description  = addslashes($valid['description']);

       $image = addslashes($valid['image']);
       
      
    
       $lastUpdateId = '';
       
       
         
    // Update data into database 
    // Build the SQL query
  
    $sql = "UPDATE   domain SET 
              domain_id = '$domainId',
               name = '$name' ,  
               description= '$description',
               image = '$image' 
           WHERE domain_id = '$domainId'";
               
               
                
            
    // Execute the query
     $lastUpdateId = executeQuery($sql, $params = null);
     $lastUpdateId = $domainId;
     
   $updateRecordSuccessful = true;
    
   unset($database_handler); 
   
   
    // if update is successful
    
   
     
  } 
  
  
  if($updateRecordSuccessful==true )
    {
          echo '<center><br /> <br /><br />';
          echo '<span class="success">'.'Data Updated Successfully! '.
               'Domain Id: '. $lastUpdateId. '</span>'.'<br />'.'<br />'.'<b>'.
             '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
   
    }
   
 } 
 
  // if record from domain table choosen
  // if form not submitted, check for record Id, get data from database
  // and fill the form

   if (!isset($_POST['submit']))
   {
       
   
   
       // check for record ID
       if ((!isset($_REQUEST['domainId']) || trim($_REQUEST['domainId']) == '')) 
       { 
         // display missing table ID Error message to user
          echo '<center>';
          echo '<h2 style="color:#ff0000;"> Missing domain ID!</h2>';
          echo '<p>
                <a href="domain.php">Please Try Again!</a>
                </p>';
          echo '<center>';
        
 
         unset($database_handler);
         exit();
        }
       
       // get domain id, name and other properties  from dB
       $query = "SELECT COUNT(*) FROM domain 
             WHERE domain_id = $domainId"; 
                   
      $result = getRow($query, $params=NULL);
     
       // get total number of records
       $total_records =  $result['COUNT(*)'];
    
     
     
     if($total_records > 0)
     {
     
       // get domain id, name and other properties  from dB
       $query1 = "SELECT * FROM domain 
                  WHERE domain_id = $domainId";       
        $result1 = getRow($query1, $params=NULL);
       
       // display form containing data gotten from database
       
       $name = strip_tags($result1['name']);
       $description = strip_tags($result1['description']);
       $image = strip_tags($result1['image']);

      ?>
      
        <table cellspacing="5" cellpadding="5">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

           <input type="hidden" name="table" value="<?php echo $table; ?>">
           <input type="hidden" name="domainId" value="<?php echo $domainId; ?>">
          
           
            <tr>
              <td colspan="2"> 
               <h1> CalculTELLER: Edit domain Record:  Update domain record </h1>
  
             </td>
            </tr>
             <?php
           if(isset($domainId))
           { 
     
                $domainId = (int)$domainId;
               echo '<tr>';
               echo '<td valign="top"><b>Domain Id </b></td>';
               echo  '<td>';
  
    
    
                echo  $domainId;
      
                echo  '</td>';
                echo  '</tr>'; 
           }  
  
            ?> 
    
           <tr>
               <td valign="top"><b>Name</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="name" 
                       value="<?php echo $name; ?>" >
      
                 </td>
           </tr>                   
           <tr>
                <td valign="top"><b>Description</b></td>
                <td>
                  <textarea name="description" cols="60" rows="8" >
                     <?php echo $description; ?>
                   </textarea>
       
                </td>
           </tr>
           <tr>
             <td valign="top"><b>Image</b></td>
             <td>
                <input size="50" maxlength="50" type="text" name="image"
                    value="<?php echo $image; ?>"  >
              </td>
          </tr>    
          <tr> 
            <td colspan="2">
        
                <input type="Submit" name="submit" value="Update">
          
               <a title="Go to Admin Home Page" href="<?php echo $linkToCancelPage; ?>">
                  |Cancel|
               </a>
           </td>
          </tr>
        </form>
      </table>
     
     <?php
     }
     
     elseif($total_records <= 0)
     {
       echo '<center>';
       echo '<h2 style="color:#ff0000;"> No record available with such and ID!</h2>';
       echo '<center>';
     }
     
   }
  
     
  
}






else if($table == $databaseTable['domain_tab'])
{

 if(isset($_POST['submit']) ) 
   
   {
   
   
          // if update button is clicked  and there are errors
         // define valid array to hold sanitized values
         $valid = array(); 
   
         // define link to previous page
        $linkToPreviousPage = $_SERVER['HTTP_REFERER'];
     
      if (!empty($_POST['domainId']) && is_numeric($_POST['domainId']) ) { 
        $valid['domainId'] = htmlentities(trim($_POST['domainId']));  
      } else { 
        $inputErrors[] = 'Domain ID'; 
        $errorFlag = 1; 
      } 
      
     if (!empty(trim($_POST['tabName'])) ) { 
        $valid['tabName'] = htmlentities(trim($_POST['tabName']));  
      } else { 
        $inputErrors[] = 'Tab_name'; 
        $errorFlag = 2; 
      } 
      
       
      
      
      if(count($inputErrors) > 0 && $errorFlag > 0 ) 
      
      {
      
          
          if($errorFlag > 0)
          {
       
           // display global error message and link to previous page 
            echo '<center><br /> <br /><br />'; 
            echo   '<span class="error">'.'Error: Form filled incorrectly!'.
                  ' </span>'.'<br />'.'<b>'.
                 '<a href="'. $linkToPreviousPage .'">'. ' BACK (Go to Previous page)'.
                  '</a>'.'</b>' ;
                  
            echo '</center><br /> ';
          }
          
          
       
        // display error encountered in each input field
         echo getInputError('Domain ID', $inputErrors);   
         echo getInputError('Tab_name', $inputErrors);
      
    }
    
       if(count($inputErrors) == 0 && $errorFlag == 0) 
   
      {
  
     // if data is valid, sanitize data before Updating record in database
     // if there are NO ERRORS in input, update data in database
        $tabId  = addslashes((int)trim($tabId));
        
       $domainId = addslashes($valid['domainId']) ;
                                               
       $tabName  = addslashes($valid['tabName']);

              
    
       $lastUpdateId = '';
       
       
         
    // Update data into database 
    // Build the SQL query
  
    $sql = "UPDATE   domain_tab SET 
              tab_id = '$tabId',
               domain_id = '$domainId' ,  
               tab_name = '$tabName'  
           WHERE tab_id = '$tabId'";
               
               
                
            
    // Execute the query
     $lastUpdateId = executeQuery($sql, $params = null);
     $lastUpdateId = $domainId;
     
   $updateRecordSuccessful = true;
    
   unset($database_handler); 
   
   
    // if update is successful
    
   
     
  } 
  
  
  if($updateRecordSuccessful==true )
    {
          echo '<center><br /> <br /><br />';
          echo '<span class="success">'.'Data Updated Successfully! '.
               'Tab Id: '. $lastUpdateId. '</span>'.'<br />'.'<br />'.'<b>'.
             '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
   
    }
   
 } 
 
 

  // if record from domain_tab table choosen
  // if form not submitted, check for record Id, get data from database
  // and fill the form

   if (!isset($_POST['submit']))
   {
       
       // check for record ID
        if ((!isset($_REQUEST['tabId']) || trim($_REQUEST['tabId']) == '')) 
       { 
         // display missing table ID Error message to user
          echo '<center>';
          echo '<h2 style="color:#ff0000;"> Missing tab ID!</h2>';
          echo '<p>
                <a href="domain_tab.php">Please Try Again!</a>
                </p>';
          echo '<center>';
        
 
         unset($database_handler);
         exit();
        } 
     
        // get domain id, name and other properties  from dB
       $query = "SELECT COUNT(*) FROM domain_tab 
                 WHERE tab_id = $tabId"; 
                   
      $result = getRow($query, $params=NULL);
     
       // get total number of records
       $total_records =  $result['COUNT(*)'];
    
   
      
     
     
     if($total_records > 0)
     {
     
        // get domain id, name and other properties  from dB
      $query1 = "SELECT * FROM domain_tab 
               WHERE tab_id = $tabId";       
      $result1 = getRow($query1, $params=NULL);
      
       // display form containing data gotten from database
       
       $tabId = strip_tags((int)$result1['tab_id']);
       $domainId = strip_tags($result1['domain_id']);
       $tabName = strip_tags($result1['tab_name']);

      ?>
      
        <table cellspacing="5" cellpadding="5">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

           <input type="hidden" name="table" value="<?php echo $table; ?>">
           <input type="hidden" name="tabId" value="<?php echo $tabId; ?>">
          
           
            <tr>
              <td colspan="2"> 
               <h1> CalculTELLER: Edit domain Record:  Update domain_tab record </h1>
  
             </td>
            </tr>
             <?php
           if(isset($tabId))
           { 
     
 
               echo '<tr>';
               echo '<td valign="top"><b>Tab Id; </b></td>';
               echo  '<td>';
  
    
    
                echo  ' '.$tabId;
      
                echo  '</td>';
                echo  '</tr>'; 
           }  
  
            ?> 
    
           <tr>
               <td valign="top"><b>Domain ID</b></td>
                 <td>
      
                   <input size="11" maxlength="11" type="text" name="domainId" 
                       value="<?php echo $domainId; ?>" >
      
                 </td>
           </tr>                   
           <tr>
                <td valign="top"><b>Tab_name</b></td>
                <td>
                  <textarea name="tabName" cols="60" rows="8" >
                     <?php echo $tabName; ?>
                   </textarea> 
                                      
       
                </td>
           </tr>
            
          <tr> 
            <td colspan="2">
        
                <input type="Submit" name="submit" value="Update">
          
               <a title="Go to Admin Home Page" href="<?php echo $linkToCancelPage; ?>">
                  |Cancel|
               </a>
           </td>
          </tr>
        </form>
      </table>
     
     <?php
     }
     
     elseif($total_records <= 0)
     {
       echo '<center>';
       echo '<h2 style="color:#ff0000;"> No record available with such and ID!</h2>';
       echo '<center>';
     }
     
   }
 
  
      

}




else if($table == $databaseTable['unit'])
{ 

  if(isset($_POST['submit']) ) 
   
   {
  
   
          // if update button is clicked  and there are errors
         // define valid array to hold sanitized values
         $valid = array(); 
   
         // define link to previous page
        $linkToPreviousPage = $_SERVER['HTTP_REFERER'];
     
     if (!empty($_POST['abbrevation']) ) { 
        $valid['abbrevation'] = htmlentities(trim($_POST['abbrevation']));  
      } else { 
        $inputErrors[] = 'Abbreviation'; 
        $errorFlag = 1; 
      } 
      
     if (!empty(trim($_POST['unitName'])) ) { 
        $valid['unitName'] = htmlentities(trim($_POST['unitName']));  
      } else { 
        $inputErrors[] = 'Unit_name'; 
        $errorFlag = 2; 
      } 
      
       
      
      
      if(count($inputErrors) > 0 && $errorFlag > 0 ) 
      
      {
      
          
          if($errorFlag > 0)
          {
       
           // display global error message and link to previous page 
            echo '<center><br /> <br /><br />'; 
            echo   '<span class="error">'.'Error: Form filled incorrectly!'.
                  ' </span>'.'<br />'.'<b>'.
                 '<a href="'. $linkToPreviousPage .'">'. ' BACK (Go to Previous page)'.
                  '</a>'.'</b>' ;
                  
            echo '</center><br /> ';
          }
          
          
       
        // display error encountered in each input field
         echo getInputError('Abbreviation', $inputErrors);   
         echo getInputError('Unit_name', $inputErrors);
      
    }
    
       if(count($inputErrors) == 0 && $errorFlag == 0) 
   
      {
  
     // if data is valid, sanitize data before Updating record in database
     // if there are NO ERRORS in input, update data in database
        $unitId  = addslashes((int)trim($unitId));
        
       $abbrevation = addslashes($valid['abbrevation']) ;
                                               
       $unitName  = addslashes($valid['unitName']);

              
    
       $lastUpdateId = '';
       
       
         
    // Update data into database 
    // Build the SQL query
  
    $sql = "UPDATE   unit SET 
              unit_id = '$unitId',
               abbrevation = '$abbrevation' ,  
               unit_name = '$unitName'  
           WHERE unit_id = '$unitId'";
               
               
                
            
    // Execute the query
     $lastUpdateId = executeQuery($sql, $params = null);
     $lastUpdateId = $unitId;
     
   $updateRecordSuccessful = true;
    
   unset($database_handler); 
   
   
    // if update is successful
    
   
     
  } 
  
  
  if($updateRecordSuccessful==true )
    {
          echo '<center><br /> <br /><br />';
          echo '<span class="success">'.'Data Updated Successfully! '.
               'Unit Id: '. $lastUpdateId. '</span>'.'<br />'.'<br />'.'<b>'.
             '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
   
    }
   
 }

  // if record from unit table choosen
  // if form not submitted, check for record Id, get data from database
  // and fill the form

   if (!isset($_POST['submit']))
   {
      
       // check for record ID
       if ((!isset($_REQUEST['unitId']) || trim($_REQUEST['unitId']) == '')) 
       { 
         // display missing table ID Error message to user
          echo '<center>';
          echo '<h2 style="color:#ff0000;"> Missing unit ID!</h2>';
           echo '<p>
                <a href="unit.php">Please Try Again!</a>
                </p>';
          echo '<center>';
        
 
         unset($database_handler);
         exit();
        }
        
         // get domain id, name and other properties  from dB
       $query = "SELECT COUNT(*) FROM unit
                  WHERE unit_id = '$unitId'"; 
                   
      $result = getRow($query, $params=NULL);
     
       // get total number of records
       $total_records =  $result['COUNT(*)'];
    
   
      
       
     if($total_records > 0)
     {
       
       // get unit id, name and other properties  from dB
       $query1 = "SELECT * FROM unit 
                  WHERE unit_id = '$unitId'";       
       $result1 = getRow($query1, $params=NULL);
     
     
       // display form containing data gotten from database
       
       $unitId = strip_tags((int)$result1['unit_id']);
       $abbrevation = strip_tags($result1['abbrevation']);
       $unitName = strip_tags($result1['unit_name']);

      ?>
      
        <table cellspacing="5" cellpadding="5">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

           <input type="hidden" name="table" value="<?php echo $table; ?>">
           <input type="hidden" name="unitId" value="<?php echo $unitId; ?>">
          
           
            <tr>
              <td colspan="2"> 
               <h1> CalculTELLER: Edit domain Record:  Update unit record </h1>
  
             </td>
            </tr>
             <?php
           if(isset($unitId))
           { 
     
 
               echo '<tr>';
               echo '<td valign="top"><b>Unit Id: </b></td>';
               echo  '<td>';
  
    
    
                echo  ' '.$unitId;
      
                echo  '</td>';
                echo  '</tr>'; 
           }  
  
            ?> 
    
           <tr>
               <td valign="top"><b>Abbreviation</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="abbrevation" 
                       value="<?php echo $abbrevation; ?>" >
      
                 </td>
           </tr>                   
           <tr>
                <td valign="top"><b>Unit_name</b></td>
                <td>
                  <textarea name="unitName" cols="60" rows="8" >
                     <?php echo $unitName; ?>
                   </textarea>
       
                </td>
           </tr>
            
          <tr> 
            <td colspan="2">
        
                <input type="Submit" name="submit" value="Update">
          
               <a title="Go to Admin Home Page" href="<?php echo $linkToCancelPage; ?>">
                  |Cancel|
               </a>
           </td>
          </tr>
        </form>
      </table>
     
     <?php
     }
     
     elseif($total_records <= 0)
     {
       echo '<center>';
       echo '<h2 style="color:#ff0000;"> No record available with such and ID!</h2>';
       echo '<center>';
     }
     
   }
   

}




else if($table == $databaseTable['domain_unit'])
{

    
        echo '<center>';
        echo '<h2 style="color:#ff0000;">
                Sorry you cannot edit domain_unit table directly!'.'<br />
              </h2>
              <p>This table is edited only when a new domain or unit is added
              or delete</p>'; 
       echo '<center>';
      

}



else if($table == $databaseTable['user'])
{

  if(isset($_POST['submit']) ) 
   
   {
   
          // if update button is clicked  and there are errors
         // define valid array to hold sanitized values
         $valid = array(); 
   
         // define link to previous page
        $linkToPreviousPage = $_SERVER['HTTP_REFERER'];
        
        
        
      
      
     
     if (!empty($_POST['name']) ) { 
        $valid['name'] = htmlentities(trim($_POST['name']));  
      } else { 
        $inputErrors[] = 'Name'; 
        $errorFlag = 1; 
      } 
      
     if (!empty($_POST['userName']) ) { 
        $valid['userName'] = htmlentities(trim($_POST['userName']));  
      } else { 
        $inputErrors[] = 'Username'; 
        $errorFlag = 2; 
      } 
      
      if (!empty($_POST['password']) ) { 
        $valid['password'] = htmlentities(trim($_POST['password']));  
      } else { 
        $inputErrors[] = 'Password'; 
        $errorFlag = 3; 
      } 
      
      if (!empty($_POST['email']) ) { 
        $valid['email'] = htmlentities(trim($_POST['email']));  
      } else { 
        $inputErrors[] = 'Email'; 
        $errorFlag = 4; 
      }
      
       if (!empty($_POST['address']) ) { 
        $valid['address'] = htmlentities(trim($_POST['address']));  
      } else { 
        $inputErrors[] = 'Address'; 
        $errorFlag = 5; 
      }
      
       if (!empty($_POST['city']) ) { 
        $valid['city'] = htmlentities(trim($_POST['city']));  
      } else { 
        $inputErrors[] = 'City'; 
        $errorFlag = 6; 
      }
      
        if (!empty($_POST['region']) ) { 
        $valid['region'] = htmlentities(trim($_POST['region']));  
      } else { 
        $inputErrors[] = 'Region'; 
        $errorFlag = 7; 
      }
      
       if (!empty($_POST['country']) ) { 
        $valid['country'] = htmlentities(trim($_POST['country']));  
      } else { 
        $inputErrors[] = 'Country'; 
        $errorFlag = 7; 
      }
      
       if (!empty($_POST['phone']) && is_numeric($_POST['phone']) ) { 
        $valid['phone'] = htmlentities(trim($_POST['phone']));  
      } else { 
        $inputErrors[] = 'Telephone'; 
        $errorFlag = 7; 
      }
  
       if (!empty($_POST['lvisit']) ) { 
        $valid['lvisit'] = htmlentities(trim($_POST['lvisit']));  
      } else { 
        $inputErrors[] = 'lvisit'; 
        $errorFlag = 7; 
      }
      
       
      
       
      
      
      if(count($inputErrors) > 0 && $errorFlag > 0 ) 
      
      {
      
          
          if($errorFlag > 0)
          {
       
           // display global error message and link to previous page 
            echo '<center><br /> <br /><br />'; 
            echo   '<span class="error">'.'Error: Form filled incorrectly!'.
                  ' </span>'.'<br />'.'<b>'.
                 '<a href="'. $linkToPreviousPage .'">'. ' BACK (Go to Previous page)'.
                  '</a>'.'</b>' ;
                  
            echo '</center><br /> ';
          }
          
          
       
        // display error encountered in each input field
         echo getInputError('Name', $inputErrors);   
         echo getInputError('Username', $inputErrors);
         echo getInputError('Password', $inputErrors);
         echo getInputError('Email', $inputErrors);
         echo getInputError('Address', $inputErrors);
         echo getInputError('City', $inputErrors);
         echo getInputError('Region', $inputErrors);
         echo getInputError('Country', $inputErrors);
          echo getInputError('Telephone', $inputErrors);
         echo getInputError('lvisit', $inputErrors);
         
    }
    
       if(count($inputErrors) == 0 && $errorFlag == 0) 
   
      {
  
     // if data is valid, sanitize data before Updating record in database
     // if there are NO ERRORS in input, update data in database
         $name  = addslashes($valid['name']);
        
        $userName = addslashes($valid['userName']) ;
                                               
        $password  = addslashes($valid['password']);

        $email  = addslashes($valid['email']);

        $address  = addslashes($valid['address']);                                      
       
        $city  = addslashes($valid['city']);
      
        $region  = addslashes($valid['region']);
        
        $country  = addslashes($valid['country']); 
        
        $phone  = addslashes($valid['phone']);
      
        $lvisit  = addslashes($valid['lvisit']);
       
    
       $lastUpdateId = '';
       
       
         
    // Update data into database 
    // Build the SQL query
  
    $sql = "UPDATE   user SET 
              name = '$name',
              username = '$userName' ,  
              password = '$password',
              email =  '$email',
              address = '$address',
              city = '$city',  
              region = '$region',
              country = '$country', 
              phone = '$phone',
              lvisit = '$lvisit'
           WHERE username = '$userName'";
               
               
                
            
    // Execute the query
     $lastUpdateId = executeQuery($sql, $params = null);
     $lastUpdateId = $userName;
     
   $updateRecordSuccessful = true;
    
   unset($database_handler); 
   
   
    // if update is successful
    
   
     
  } 
  
  
  if($updateRecordSuccessful==true )
    {
          echo '<center><br /> <br /><br />';
          echo '<span class="success">'.'Data Updated Successfully! '.
               'Username: '. $lastUpdateId. '</span>'.'<br />'.'<br />'.'<b>'.
             '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
   
    }
   
 } 

    // if record from user table choosen
  // if form not submitted, check for record Id, get data from database
  // and fill the form

   if (!isset($_POST['submit']))
   {
       
       
       // check for record ID
       if ((!isset($_REQUEST['userName']) || trim($_REQUEST['userName']) == ''))
       { 
         // display missing table ID Error message to user
          echo '<center>';
          echo '<h2 style="color:#ff0000;"> Missing Username!</h2>';
           echo '<p>
                <a href="user.php">Please Try Again!</a>
                </p>';
          echo '<center>';
        
 
         unset($database_handler);
         exit();
        }
        
         // get domain id, name and other properties  from dB
       $query = "SELECT COUNT(*) FROM user
                   WHERE username = '$userName'";  
                   
      $result = getRow($query, $params=NULL);
     
       // get total number of records
       $total_records =  $result['COUNT(*)'];
     
    
   
     
     if($total_records > 0)
     {
     
        // get username, name and other properties  from dB
        $query1 = "SELECT * FROM user 
                     WHERE username = '$userName'";       
        $result1 = getRow($query1, $params=NULL);
     
       //  sanitize and edit data before from database before displaying it
       // PHP also allows you to slice a string into smaller parts with the substr()
       // e.g $str = 'Welcome to nowhere'; echo substr($str, 3, 4); 
     
       $name  = strip_tags($result1['name']) ;
       $userName = strip_tags($result1['username']) ;                                        
       $password = strip_tags($result1['password']);
       $email = strip_tags($result1['email']);
       $address = strip_tags($result1['address']);
       $city = strip_tags($result1['city']);
       $region = strip_tags($result1['region']);
       $country = strip_tags($result1['country']);
       $phone = strip_tags($result1['phone']);
       $lvisit = strip_tags($result1['lvisit']);
      
       // display form containing data gotten from database

      ?>
      
        <table cellspacing="5" cellpadding="5">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

           <input type="hidden" name="table" value="<?php echo $table; ?>">
           <input type="hidden" name="userName" value="<?php echo $userName; ?>">
          
           
            <tr>
              <td colspan="2"> 
               <h1> CalculTELLER: Edit domain Record:  Update user record </h1>
  
             </td>
            </tr>
             
    
           <tr>
               <td valign="top"><b>Name</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="name" 
                       value="<?php echo $name; ?>" >
      
                 </td>
           </tr>  
                            
           <tr>
                <td valign="top"><b>Username</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="userName" 
                       value="<?php echo $userName; ?>" >
      
                 </td>
           </tr>
           
           <tr>
                <td valign="top"><b>Password</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="password" 
                       value="<?php echo $password; ?>" >
      
                 </td>
           </tr>
           
           <tr>
                <td valign="top"><b>Email</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="email" 
                       value="<?php echo $email; ?>" >
      
                 </td>
           </tr>
           
           <tr>
                <td valign="top"><b>Address</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="address" 
                       value="<?php echo $address; ?>" >
      
                 </td>
           </tr>
           
            <tr>
                <td valign="top"><b>City</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="city" 
                       value="<?php echo $city; ?>" >
      
                 </td>
           </tr>
           
           <tr>
                <td valign="top"><b>Region</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="region" 
                       value="<?php echo $region; ?>" >
      
                 </td>
           </tr>
           
           <tr>
                <td valign="top"><b>Country</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="country" 
                       value="<?php echo  $country; ?>" >
      
                 </td>
           </tr>
           
            <tr>
                <td valign="top"><b>Telephone</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="phone" 
                       value="<?php echo  $phone; ?>" >
      
                 </td>
           </tr>
           
           <tr>
                <td valign="top"><b>lvisit</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="lvisit" 
                       value="<?php echo  $lvisit; ?>" >
      
                 </td>
           </tr>
            
          <tr> 
            <td colspan="2">
        
                <input type="Submit" name="submit" value="Update">
          
               <a title="Go to Admin Home Page" href="<?php echo $linkToCancelPage; ?>">
                  |Cancel|
               </a>
           </td>
          </tr>
        </form>
      </table>
     
     <?php
     }
     
     elseif($total_records <= 0)
     {
       echo '<center>';
       echo '<h2 style="color:#ff0000;"> No record available with such username!</h2>';
       echo '<center>';
     }
     
   }
   
   
   
  

}



else if($table == $databaseTable['user_data'])
{

   // if form is submitted, execute code below
   if(isset($_POST['submit']) ) 
   
   {
   
   
   
          // if update button is clicked  and there are errors
         // define valid array to hold sanitized values
         $valid = array(); 
   
         // define link to previous page
        $linkToPreviousPage = $_SERVER['HTTP_REFERER'];
        
        
        
     
      if (!empty($_POST['userName']) ) { 
        $valid['userName'] = htmlentities(trim($_POST['userName']));  
      } else { 
        $inputErrors[] = 'Username'; 
        $errorFlag = 1; 
      } 
      
       if (!empty($_POST['dataValue']) ) { 
        $valid['dataValue'] = htmlentities(trim($_POST['dataValue']));  
      } else { 
        $inputErrors[] = 'Data_Value'; 
        $errorFlag = 3; 
      } 
      
      
     if (!empty(trim($_POST['description'])) ) { 
        $valid['description'] = htmlentities(trim($_POST['description']));  
      } else { 
        $inputErrors[] = 'Description'; 
        $errorFlag = 2; 
      }
      
       if (!empty($_POST['saved']) ) { 
        $valid['saved'] = htmlentities(trim($_POST['saved']));  
      } else { 
        $inputErrors[] = 'Saved'; 
        $errorFlag = 3; 
      }  
      
      
      
      
      if(count($inputErrors) > 0 && $errorFlag > 0 ) 
      
      {
      
          
          if($errorFlag > 0)
          {
       
           // display global error message and link to previous page 
            echo '<center><br /> <br /><br />'; 
            echo   '<span class="error">'.'Error: Form filled incorrectly!'.
                  ' </span>'.'<br />'.'<b>'.
                 '<a href="'. $linkToPreviousPage .'">'. ' BACK (Go to Previous page)'.
                  '</a>'.'</b>' ;
                  
            echo '</center><br /> ';
          }
          
          
       
        // display error encountered in each input field
         echo getInputError('Username', $inputErrors);  
         echo  getInputError('Data_Value', $inputErrors); 
         echo getInputError('Description', $inputErrors);
         echo  getInputError('Saved', $inputErrors); 
    }
    
       if(count($inputErrors) == 0 && $errorFlag == 0) 
   
      {
  
     // if data is valid, sanitize data before Updating record in database
     // if there are NO ERRORS in input, update data in database
        $dataId  = addslashes((int)trim($dataId));
        
       $userName = addslashes($valid['userName']) ;
       
       $dataValue = addslashes($valid['dataValue']) ;
                                               
       $description  = addslashes($valid['description']);

       $saved = addslashes($valid['saved']);
       
      
    
       $lastUpdateId = '';
       
       
     
           
    // Update data into database 
    // Build the SQL query
  
    $sql = "UPDATE   user_data SET 
              data_id = '$dataId',
               username = '$userName' ,
               data_value = '$dataValue' ,  
               description= '$description',
               saved = '$saved' 
           WHERE data_id = '$dataId'";
               
               
                
            
    // Execute the query
     $lastUpdateId = executeQuery($sql, $params = null);
     $lastUpdateId = $dataId;
     
   $updateRecordSuccessful = true;
    
   unset($database_handler); 
   
   
    // if update is successful
    
   
     
  } 
  
  
  if($updateRecordSuccessful==true )
    {
          echo '<center><br /> <br /><br />';
          echo '<span class="success">'.'Data Updated Successfully! '.
               'Data Id: '. $lastUpdateId. '</span>'.'<br />'.'<br />'.'<b>'.
             '<a href="'. $linkToPreviousPage .'">'. ' BACK(Go to Previous page)'.
              '</a>'.'</b>' ;
          echo '</center><br /> ';
   
    }
   
 } 


  // if record from user_data table choosen
  // if form not submitted, check for record Id, get data from database
  // and fill the form

   if (!isset($_POST['submit']))
   {
       
       
      // check for record ID
       if ((!isset($_REQUEST['dataId']) || trim($_REQUEST['dataId']) == ''))
       { 
         // display missing table ID Error message to user
          echo '<center>';
          echo '<h2 style="color:#ff0000;"> Missing data ID!</h2>';
          echo '<p>
                <a href="user.php">Please Try Again!</a>
                </p>';
          echo '<center>';
        
 
         unset($database_handler);
         exit();
        }
        
         // get domain id, name and other properties  from dB
       $query = "SELECT COUNT(*) FROM user_data
                   WHERE data_id = $dataId"; 
                   
       $result = getRow($query, $params=NULL);
     
       // get total number of records
       $total_records =  $result['COUNT(*)'];
     
     
     
     
     if($total_records > 0)
     {
     
       // get data id, name and other properties  from dB
       $query1 = "SELECT * FROM user_data 
                    WHERE data_id = $dataId";       
       $result1 = getRow($query1, $params=NULL);
     
       // display form containing data gotten from database
       
       
       $dataId = strip_tags((int)$result1['data_id']);
       $userName = strip_tags($result1['username']);
       $dataValue = strip_tags($result1['data_value']);
       $description = strip_tags($result1['description']);
        $saved = strip_tags($result1['saved']);

      ?>
      
        <table cellspacing="5" cellpadding="5">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

           <input type="hidden" name="table" value="<?php echo $table; ?>">
           <input type="hidden" name="dataId" value="<?php echo $dataId; ?>">
          
           
            <tr>
              <td colspan="2"> 
               <h1> CalculTELLER: Edit domain Record:  Update domain record </h1>
  
             </td>
            </tr>
             <?php
           if(isset($dataId))
           { 
     
 
               echo '<tr>';
               echo '<td valign="top"><b>Data Id; </b></td>';
               echo  '<td>';
  
    
    
                echo  ' '.$dataId;
      
                echo  '</td>';
                echo  '</tr>'; 
           }  
  
            ?> 
            
            
    
           <tr>
               <td valign="top"><b>Username</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="userName" 
                       value="<?php echo $userName; ?>" >
      
                 </td>
           </tr>
             
            <tr>
               <td valign="top"><b>Data_Value</b></td>
                 <td>
      
                   <input size="50" maxlength="50" type="text" name="dataValue" 
                       value="<?php echo $dataValue ; ?>" >
      
                 </td>
           </tr>  
                            
           <tr>
                <td valign="top"><b>Description</b></td>
                <td>
                  <textarea name="description" cols="60" rows="8" >
                     <?php echo $description; ?>
                   </textarea>
       
                </td>
           </tr>
           
           <tr>
             <td valign="top"><b>Saved</b></td>
             <td>
                <input size="50" maxlength="50" type="text" name="saved"
                    value="<?php echo $saved; ?>"  >
              </td>
          </tr>    
          <tr> 
            <td colspan="2">
        
                <input type="Submit" name="submit" value="Update">
          
               <a title="Go to Admin Home Page" href="<?php echo $linkToCancelPage; ?>">
                  |Cancel|
               </a>
           </td>
          </tr>
        </form>
      </table>
     
     <?php
     }
     
     elseif($total_records <= 0)
     {
       echo '<center>';
       echo '<h2 style="color:#ff0000;"> No record available with such and ID!</h2>';
       echo '<center>';
     }
     
   }
   
  

}

?>

 </div> 
 </body>
</html>
