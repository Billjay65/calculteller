### Calculteller Version 1.0.0 ###
# Date: 2023-02-24 14:00:00   - Febuary 24, 2023

# Calculteller version 1.0.0
- Domains: Balance  - Electricity 
- Electricity - Tenant tab:  Answer and Save functionality WP
  Electricity domain uses myaccount to save values here. 
- All domains are non ajaxified

# Local environment - Development Environment
- Apache2.4
- php 8.0.21
- MySQL 5.7