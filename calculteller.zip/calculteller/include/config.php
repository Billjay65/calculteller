<?php
// SITE_ROOT contains the full path to the calculteller folder
define('SITE_ROOT', dirname(dirname(__FILE__)));


// Application directories
define('PRESENTATION_DIR', SITE_ROOT . '/presentation/');
define('TEMPLATE_DIR', PRESENTATION_DIR. 'templates');
define('BUSINESS_DIR', SITE_ROOT . '/business/');

//Libraries directories: function libraries and others
define('FUNCTIONS_DIR', SITE_ROOT . '/libs/');

//Configuration directory
define('CONFIG_DIR', SITE_ROOT . '/include/configs');


// These should be true while developing the web site
define('IS_WARNING_FATAL', true);
define('DEBUGGING', true);

// The error types to be reported
define('ERROR_TYPES', E_ALL);

// By default we don't log errors to a file
define('LOG_ERRORS', false);
define('LOG_ERRORS_FILE', 'c:\\tshirtshop\\errors_log.txt'); // Windows


// Settings about mailing the error messages to admin
define('SEND_ERROR_MAIL', false);
define('ADMIN_ERROR_MAIL', 'Administrator@example.com');
define('SENDMAIL_FROM', 'Errors@example.com');
ini_set('sendmail_from', SENDMAIL_FROM);

// settings for donate email to admin
define('ADMIN_DONATE_MAIL', 'calculteller@yahoo.com');


// define Social media links constants
define('FACEBOOK_LINK', 'http://www.facebook.com');
define('INSTAGRAM_LINK', 'http://www.instagram.com');
define('TWITTER_LINK', 'http://www.twitter.com');
define('GOOGLEPLUS_LINK', 'http://www.googleplus.com');


/* Generic error message to be displayed instead of debug info
   (when DEBUGGING is false) WINDOWS */
define('SITE_GENERIC_ERROR_MESSAGE', '<h1>TShirtShop Error!</h1>');
/*
// Database connectivity setup
define('DB_PERSISTENCY', 'true');
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'jay.v');
define('DB_PASSWORD', 'Sikehjaphetberyuf12');
define('DB_DATABASE', 'music');
define('PDO_DSN', 'mysql:host=' . DB_SERVER . ';dbname=' . DB_DATABASE);
 */
 
 //site LINKS' constants
// Server HTTP port (can omit if the default 80 is used)
define('HTTP_SERVER_PORT', '');
/* Name of the virtual directory the site runs in, for example:
   '/tshirtshop/' if the site runs at http://www.example.com/tshirtshop/
   '/' if the site runs at http://www.example.com/*/ 
define('VIRTUAL_LOCATION', '/calculteller/');

// Configure domains list display options
define('DOMAIN_DESCRIPTION_LENGTH', 100);
define('DOMAINS_PER_PAGE', 7);

// Configure default number of rows of data to be displayed for a domain

define('DOMAIN_ROWS_NO', 1);


// Random value used for hashing
define('HASH_PREFIX', 'S1-');

/*
// We enable and enforce SSL when this is set to anything else than 'no'
define('USE_SSL', 'yes');


define('DB_USERNAME', 'calcultellerberyuf');
define('DB_PASSWORD', 'sefakcalcultellerberyuf3');
*/
 
// Administrator login information for admin module
define('ADMIN_USERNAME', 'calculteller');
define('ADMIN_PASSWORD', '21599979d3acef7ca222f1d372d2cf5e41712b46');  

// Database connectivity setup
define('DB_PERSISTENCY', 'true');
define('DB_SERVER', 'localhost'); 
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'Sikehjaphetberyuf12');
define('DB_DATABASE', 'calculteller');
define('PDO_DSN', 'mysql:host=' . DB_SERVER . ';dbname=' . DB_DATABASE);


/*
// Configure product lists display options
define('SHORT_PRODUCT_DESCRIPTION_LENGTH', 150);
define('PRODUCTS_PER_PAGE', 4);
*/
?>