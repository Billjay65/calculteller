<?php

/***English strings and text***/

$lang['app_name_caps'] = 'CalcuTELLER';



// HOME (index.php) strings
$lang['home']        = 'Accueil';
$lang['title_index'] = 'CalculTELLER: calcule votre solde, vos prêts,
                         Moyenne, Temps, Âge, Périmètre, Bénéfice et plus
                         en moins d\'une seconde';

// register_user.php strings
$lang['register_title']    = 'S\'inscrire: Enregistrer CalculTeller';
$lang['register_heading']  = 'Inscrivez-vous pour avoir un accès complet!';

$lang['register_form_title'] = 'S\'il vous plaît entrer vos détails';
$lang['name']                = 'Nom:';
$lang['username']            = 'Nom d\'utilisateur:';
$lang['email']               = 'Adresse e-mail:';
$lang['password']            = 'Mot de passe:';
$lang['password_confirm']    = 'Ressaisissez votre mot de passe:';
$lang['address']             = 'Adresse:';
$lang['city']                = 'Ville:';
$lang['region']              = 'Region:';
$lang['telephone']           = 'Téléphone:';
$lang['country']             = 'Country:';

$lang['signup_btn']          = 'Inscrivez-vous';
$lang['cancel_btn']          = 'Annuler';



// login.php strings
$lang['login_title']         = 'Calculteller: Connectez-vous à calculteller!';
$lang['login_heading']       = 'Connectez-vous et laissez calculteller vous parler!';

// reset_password.php strings
$lang['reset_password_title']       = 'Calculteller: Reset Your Password'; 
$lang['reset_password_form_title']  = 'Enter Your New Password';
$lang['reset_password_btn']         = 'Reset Password';

$lang['login_form_title']    = 'CalculTELLER Connexion';
$lang['username']            = 'Nom d\'utilisateur:';
$lang['password']            = 'Mot de passe:';
$lang['login_btn']           = 'Connexion';
$lang['forgot_passwd']       = 'Forgot Password';
$lang['register']            = 'Inscription';


// output_fns.php Strings
//header strings
$lang['logout']           = 'Déconnexion';
$lang['login']            = 'Connexion';
$lang['signup']           = 'Inscription';

$lang['language_invite']  = 'Langue';

$lang['english']         = 'English';
$lang['french']          = 'Français';
$lang['spanish']         = 'Espagnol';
$lang['chinese']         = '中文';
$lang['more_langs']      = 'Plus >>';

$lang['domains']        = 'Domaines';
$lang['my_account']      = 'Mon compte';
$lang['calculator']      = 'Calculatrice';
$lang['news']            = 'Nouvelles';
$lang['help']            = 'Aide ';
$lang['search']          = 'Recherche';

$lang['facebook']       = 'Partager sur Facebook (f)';
$lang['instagram']      = 'Partager sur Instagram (I)';
$lang['twitter']        = 'Partager sur Twitter (T)';
$lang['googlep']        = 'Partager sur Googleplus (G+)';

// footer strings
$lang['terms_conditions'] = 'Termes et conditions';
$lang['privacy_policy']   = 'Politique de confidentialité';
$lang['aboutus']          = 'À propos de nous';
$lang['sitemap']          = 'Plan du site';
$lang['news']             = 'Nouvelles';
$lang['tel']              = '+1 123 4550';
$lang['help_ft']          = 'Aide';
$lang['cookies']          = 'Cookies';





// domain_array
$lang['domains_arr'] [0] = 'Solde';
$lang['domains_arr'] [1] = 'Pari';
$lang['domains_arr'] [2] = 'Proportion';
$lang['domains_arr'] [3] = 'Temps';
$lang['domains_arr'] [4] = 'Entreprise';
$lang['domains_arr'] [5] = 'Banque';
$lang['domains_arr'] [6] = 'Ecole';
$lang['domains_arr'] [7] = 'Mesures';
$lang['domains_arr'] [8] = 'Maths';
$lang['domains_arr'] [9] = 'Age';
$lang['domains_arr'] [10] = 'Électricité';



?>