<?php

/***English strings and text***/

$lang['app_name_caps'] = 'CalcuTELLER';



// HOME (index.php) strings
$lang['home']        = 'Inicio';
$lang['title_index'] = 'CalculTELLER: Calcula su saldo, préstamos,
                         Promedio, tiempo, edad, perímetro, ganancias y más
                         en menos de un segundo';

// register_user.php strings
$lang['register_title']    = 'Regístrate: Regístrate CalculTeller';
$lang['register_heading']  = 'Regístrate para obtener acceso completo!';

$lang['register_form_title'] = 'Por favor ingrese sus detalles';
$lang['name']                = 'Nombre:';
$lang['username']            = 'Nombre de usuario:';
$lang['email']               = 'Correo Electrónico:';
$lang['password']            = 'Contraseña:';
$lang['password_confirm']    = 'Escriba la contraseña otra vez:';
$lang['address']             = 'Dirección:';
$lang['city']                = 'Ciudad:';
$lang['region']              = 'Región:';
$lang['telephone']           = 'Teléfono:';
$lang['country']             = 'País:';

$lang['signup_btn']          = 'Regístrate';
$lang['cancel_btn']          = 'Cancelar';



// login.php strings
$lang['login_title']      = 'Calculteller: Iniciar sesión en calculteller!';
$lang['login_heading']    = '¡Inicia sesión y deja que el calculteller te hable!';

// reset_password.php strings
$lang['reset_password_title']       = 'Calculteller: Reset Your Password'; 
$lang['reset_password_form_title']  = 'Enter Your New Password';
$lang['reset_password_btn']         = 'Reset Password';

$lang['login_form_title'] = 'CalculTELLER Registrarse';
$lang['username']         = 'Nombre de usuario:';
$lang['password']         = 'Contraseña:';
$lang['login_btn']        = 'Iniciar sesión';
$lang['forgot_passwd']    = 'Forgot Password';
$lang['register']         = 'Regístrate';


// output_fns.php Strings
// header strings
$lang['logout'] = 'Cerrar sesión';
$lang['login']  = 'Registrarse';
$lang['signup'] = 'Regístrate';

$lang['language_invite'] = 'Idioma';
$lang['english']         = 'English';
$lang['french']          = 'Français';
$lang['spanish']         = 'Espagnol';
$lang['chinese']         = '中文';
$lang['more_langs']      = 'Más >>';

$lang['domains']        = 'Domains';
$lang['my_account']     = 'Mi Cuenta';
$lang['calculator']     = 'Calculadora';
$lang['news']           = 'Noticias';
$lang['help']           = 'AYUDA';
$lang['search']         = 'Busca';

$lang['facebook']         = 'Compartir en Facebook (f)';
$lang['instagram']        = 'Compartir en Instagram (I)';
$lang['twitter']          = 'Compartir en Twitter (T)';
$lang['googlep']          = 'Compartir en Googleplus (G +)';

// footer strings
$lang['terms_conditions'] = 'Términos y Condiciones';
$lang['privacy_policy']   = 'Política de privacidad';
$lang['aboutus']          = 'Sobre nosotros';
$lang['sitemap']          = 'Mapa del sitio';
$lang['news']             = 'Noticias';
$lang['tel']              = '+1 123 4550';
$lang['help_ft']          = 'Ayuda'; 
$lang['cookies']          = 'Cookies';



// domains_array
$lang['domains_arr'][0] = 'Balance';
$lang['domains_arr'][1] = 'Apuesta';
$lang['domains_arr'][2] = 'Proporción';
$lang['domains_arr'][3] = 'Hora';
$lang['domains_arr'][4] = 'Negocio';
$lang['domains_arr'][5] = 'Banco';
$lang['domains_arr'][6] = 'Colegio';
$lang['domains_arr'][7] = 'Mediciones';
$lang['domains_arr'][8] = 'Matemáticas';
$lang['domains_arr'][9] = 'Años';
$lang['domains_arr'][10] = 'Electricidad';


?>