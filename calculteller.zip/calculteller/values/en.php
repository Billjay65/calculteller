<?php

/***English strings and text***/

$lang['app_name_caps'] = 'CalcuTELLER';



// HOME (index.php) strings
$lang['home']        = 'Home';
$lang['title_index'] = 'CalculTELLER: Calculates your Balance, Loans, 
                        Average, Time, Age, Perimeter, Profit and more 
                        in less than a second';

// register_user.php strings
$lang['register_title']    = 'Sign Up: Register CalculTeller';
$lang['register_heading']  = 'Sign Up to gain full access!';

$lang['register_form_title'] = 'Please enter your details';
$lang['name']                = 'Name:';
$lang['username']            = 'Username:';
$lang['email']               = 'E-mail Address:';
$lang['password']            = 'Password:';
$lang['password_confirm']    = 'Re-enter Password:';
$lang['address']             = 'Address:';
$lang['city']                = 'City:';
$lang['region']              = 'Region:';
$lang['telephone']           = 'Telephone:';
$lang['country']             = 'Country:';

$lang['signup_btn']          = 'Sign Up';
$lang['cancel_btn']          = 'Cancel';



// login.php strings
$lang['login_title']      = 'Calculteller: Sign In into calculteller!';
$lang['login_heading']    = 'Sign In and let calculteller talk to you!';

$lang['login_form_title'] = 'CalculTELLER Sign in';
$lang['username']         = 'Username:';
$lang['password']         = 'Password:';
$lang['login_btn']        = 'Sign in';
$lang['forgot_passwd']    = 'Forgot Password';
$lang['register']         = 'Register';

// reset_password.php strings
$lang['reset_password_title']       = 'Calculteller: Reset Your Password'; 
$lang['reset_password_form_title']  = 'Enter Your New Password';
$lang['reset_password_btn']         = 'Reset Password';



// output_fns.php Strings
// header strings
$lang['logout'] = 'Logout';
$lang['login']  = 'Login';
$lang['signup'] = 'Signup';

$lang['language_invite'] = 'Language';
$lang['english']         = 'English';
$lang['french']          = 'Français';
$lang['spanish']         = 'Espagnol';
$lang['chinese']         = '中文';
$lang['more_langs']      = 'More >>';

$lang['domains']        = 'Domains';
$lang['my_account']     = 'My Account';
$lang['calculator']     = 'Calculator';
$lang['news']           = 'News';
$lang['help']           = 'HELP';
$lang['search']         = 'Search';

$lang['facebook']         = 'Share on Facebook (f)';
$lang['instagram']        = 'Share on Instagram (I)';
$lang['twitter']          = 'Share on Twitter (T)';
$lang['googlep']          = 'Share on Googleplus (G+)';

// footer strings
$lang['terms_conditions'] = 'Terms and Conditions';
$lang['privacy_policy']   = 'Privacy Policy';
$lang['aboutus']          = 'About Us';
$lang['sitemap']          = 'Sitemap';
$lang['news']             = 'News';
$lang['tel']              = '+1 123 4550';
$lang['help_ft']          = 'Help'; 
$lang['cookies']          = 'Cookies';





// domains_array
$lang['domains_arr'][0] = 'Balance';
$lang['domains_arr'][1] = 'Bet';
$lang['domains_arr'][2] = 'Proportion';
$lang['domains_arr'][3] = 'Time';
$lang['domains_arr'][4] = 'Business';
$lang['domains_arr'][5] = 'Bank';
$lang['domains_arr'][6] = 'School';
$lang['domains_arr'][7] = 'Measurements';
$lang['domains_arr'][8] = 'Maths';
$lang['domains_arr'][9] = 'Age';
$lang['domains_arr'][10] = 'Electricity';


?>