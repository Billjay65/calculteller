<?php

/***English strings and text***/

$lang['app_name_caps'] = 'CalcuTELLER';



// HOME (index.php) strings
// Chinese (Traditional)
$lang['home']        = '主頁';
$lang['title_index'] = 'CalculTELLER：計算您的餘額，貸款，
                         平均，時間，年齡，周長，利潤等
                         在不到一秒鐘';

// register_user.php strings
$lang['register_title']    = '註冊: 註冊CalculTeller';
$lang['register_heading']  = '註冊以獲得完全訪問權限！';

$lang['register_form_title'] = '請輸入您的詳細信息';
$lang['name']                = '名稱：';
$lang['username']            = '用戶名：';
$lang['email']               = '電子郵件地址：';
$lang['password']            = '密碼：';
$lang['password_confirm']    = '重新輸入密碼：';
$lang['address']             = '地址：';
$lang['city']                = '市：';
$lang['region']              = '區域：';
$lang['telephone']           = '電話：';
$lang['country']             = '國家：';

$lang['signup_btn']          = '註冊';
$lang['cancel_btn']          = '取消';



// login.php strings
$lang['login_title']      = 'Calculteller: 登錄calculteller！';
$lang['login_heading']    = '登錄讓calculteller跟你說話！';

$lang['login_form_title'] = 'CalculTELLER 登入';
$lang['username']         = '用戶名：';
$lang['password']         = '密碼：';
$lang['login_btn']        = '登入';
$lang['forgot_passwd']    = 'Forgot Password';
$lang['register']         = '寄存器';

// reset_password.php strings
$lang['reset_password_title']       = 'Calculteller: Reset Your Password'; 
$lang['reset_password_form_title']  = 'Enter Your New Password';
$lang['reset_password_btn']         = 'Reset Password';


// output_fns.php Strings
// header strings
$lang['logout'] = '登出';
$lang['login']  = '登錄';
$lang['signup'] = '註冊';

$lang['language_invite'] = '語言';
$lang['english']         = 'English';
$lang['french']          = 'Français';
$lang['spanish']         = 'Espagnol';
$lang['chinese']         = '中文';
$lang['more_langs']      = '更多 >>';

$lang['domains']        = '域';
$lang['my_account']     = '我的帳戶';
$lang['calculator']     = '計算器';
$lang['news']           = '新聞';
$lang['help']           = '救命';
$lang['search']         = '搜索';

$lang['facebook']         = '在Facebook上分享（f）';
$lang['instagram']        = '在Instagram上分享（I）';
$lang['twitter']          = '在Twitter上分享（T）';
$lang['googlep']          = '分享到Googleplus（G +）';

// footer strings
$lang['terms_conditions'] = '條款和條件';
$lang['privacy_policy']   = '隱私政策';
$lang['aboutus']          = '關於我們';
$lang['sitemap']          = '網站地圖';
$lang['news']             = '新聞';
$lang['tel']              = '+1 123 4550';
$lang['help_ft']          = '救命'; 
$lang['cookies']          = 'Cookies';





// domains_array
$lang['domains_arr'][0] = '结余';
$lang['domains_arr'][1] = '打賭';
$lang['domains_arr'][2] = '比例';
$lang['domains_arr'][3] = '時間';
$lang['domains_arr'][4] = '商業';
$lang['domains_arr'][5] = '銀行';
$lang['domains_arr'][6] = '學校';
$lang['domains_arr'][7] = '測量';
$lang['domains_arr'][8] = '數學';
$lang['domains_arr'][9] = '年齡';
$lang['domains_arr'][10] = '力電';



?>