<?php

 // start session, authenticate user....
 session_start();
 
 // Start output buffer
 ob_start();
 
 // include config file containing directory paths
 require_once 'include/config.php';
 
 // include error handling class php file
 require_once 'error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 
 // Call the home page functions to display html content on screen
 
 fixed_html_header('CalculTELLER: About Us',
                      '', $user_name, $member);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

?>

  <div class="extra_page_content">
    <h1>About Us</h1>
     
      <p>
        <b>Why calculteller?</b>
        Have you ever picked up a calculator to calculate your <em>average, cost
        of items on your shopping list, or proportion</em> and you discover 
        that you <b>MUST use PEN or PENCIL</b> if you dream of achieving results. 
        This is the motivation behind calculteller. The  fact that 
        with all the computers and calculators lying around us, it is practically
        impossible to carry out simple basic calculations without using a pen,
        pencil, paper and caculator. 
      </p>
      
      <p>
        Calculteller is a revolution of of calculation. Calculteller 
        can be defined as a calculator that speaks. It is a collection 
        of simple basic daily calculations. Calculteller is a <b>PEN, PENCIL,
        PAPER, CALCULATOR, and more</b> <br />
        Contact Us at <a href="mailto://calculteller@yahoo.com"> 
          calculteller@yahoo.com </a>
      </p>
      
    
    <!--End of extra-page-content div-->
  </div>
<?php

fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();
?>