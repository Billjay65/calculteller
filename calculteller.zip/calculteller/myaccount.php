<?php

// start session, authenticate user and store variables coming from domain for display
 session_start();
 
 
// include config file containing directory paths
 require_once 'include/config.php';
 
 
  // include error handling class php file
 require_once SITE_ROOT.'/error_handler.php';
 
 // Set the error handler
 ErrorHandler::SetHandler();
 
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 
 //  authenticate user and store variables coming from domain for display
 
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 if(!isset($_SESSION['username']) || $_SESSION['username']=='')  
 { 
 
  fixed_html_header('CalculTELLER: Balance domain calculates 
                    your change in less than a second',
                      'Balance (Change) Functions', $user_name);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

// display login advice to user
  
 echo  '<center><h2>Please Login to gain FULL ACCESS to all domains</h2></center>';
 echo '<p class="login_advice">';
 echo  'After you log in, you can  SAVE your answers and information
              and retrieve them anywhere in the world and at any time of the day.
              Thank You!';
 echo '</p>';
 echo '<center>';
 echo '<span style="float:center;">'.'<b>'.'<a href="'.
        Link::Build('login.php').'">'.' LogIn'.'</a>'.'</b>'.'</span>' ;
 echo '</center>';
//display_domain_image_links();
fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 
 exit();
 }
 
                                               
$_SESSION['answer']  = (!isset($_SESSION['answer']))? NULL : $_SESSION['answer'];

 $_SESSION['description'] = (!isset( $_SESSION['description']))? NULL :  $_SESSION['description'];
    
$_SESSION['username'] = (!isset($_SESSION['username']))? NULL : $_SESSION['username'] ; 

$userName =  $_SESSION['username'];



  




function getInputError($key, $errArray) { 
      if (in_array($key, $errArray)) { 
        if($key == "Passwords Different")
        {
          return "<div class=\"error\">ERROR: Invalid password fields,
                  $key .  </div>";
        }
        else
        {
          return "<div class=\"error\">ERROR: Invalid data for '$key' form
           field.  </div>"; 
        }
      } else { 
        return false; 
      } 
    } 
  
  
  // define error array to hold errors
  $inputErrors = array(); 
  
  // define error flag to detect errors in form
  $errorFlag = 0;
  
  // define database insert flag to determine if record has been successfully
  // inserted into database
  $insertRecordSuccessful = false;
  
  // update record in database flag
  $updateRecordSuccessful = false;
    
  // define link to cancel page (index.php) which is the page visited before
  // coming to save myaccount page
   $linkToCancelPage = Link::Build('index.php');
   
  /*VARIABLES FOR PAGE3 : USER ACCOUNT DETAILS from register_user.php script*/  
   $editMode = 0;
   $errorFlag = 0;
   $submitted = false;
   //$errorHeader = 'ERROR: Form filled incorrectly, Please correct error';
   $errorHeader = ''; 
    
 
 // define array to hold the number records to be displayed in my account
 // range(1,120) creates and arry with values from 1 to 120 Max=120
 $arr = range(1, 120);
  
  //Get number of records to display
  $dataRecords = (!isset($_POST['datarecords']))? 10 : $_POST['datarecords'];
  
  // Get the account page number or tab currently selected 
  // Saved Data = 1; Data Details = 2; Edit Account 3;
  
  $page = (!isset($_GET['page']))? '1' : $_GET['page'];
  
  
  
  
  
  // Get button which has been clicked
  
  $recordsNo = (!isset($_POST['recordsno']))? false : true;
  
  $save = (!isset($_POST['save']))? false : true;
  
  $update = (!isset($_POST['update']))? false : true;
  
  $saveDetails = (!isset($_POST['save_details']))? false : true;
  
 
  
  // get page when form is submitted
  
  if($save || $update)
      $page = 2;
  
  // get page when form is submitted
  if($saveDetails)
      $page = 3;    


 // if HTTP_REFERER is Not set  display error message
 // This ensures that user accesses this page ONLY from within app
 if(!isset($_SERVER['HTTP_REFERER']))
 {
   echo '<h2> Error: Unable to display page.</h2>
         <p> Please login and try again.
          <a href="login.php">Login.</a>
         </p>';
   
   exit();
 }
 else
 {
    $linkToPreviousPage =  $_SERVER['HTTP_REFERER'];
 
 }

  
 
 
 ?>
 
    
   
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

 <head>
   
 <title> Caclteller:My Account </title>
 
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
 <meta charset="UTF-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0" />
   
  <link rel="icon" type="image/png" href="images/logo2.png" />
  
   <link type="text/css" rel="stylesheet" href=<?php echo 
                      Link::Build('styles/myaccount.css'); ?> />
  
  
  </head>
  
  
<body> 

<?php
 
 
 
 
 

if(isset($page))
{
?>

<!-- form not yet submitted -->





<!-- standard page header -->


<div id="doc">

<div class="admin_header">
<p class="page_app">

  <a href=<?php echo  Link::Build('index.php'); ?>  style="float:left">
    <img src='images/admin_logo.png' alt='Logo-calculteller' border=0
       style="float:left; max-width: 100%;" />
  </a> 
  
  <span id="page">My Account - </span>&nbsp; 

  <span id="app">CalculTELLER</span>
 </p> 


  <span id="help_logout">
       <a href=<?php echo  Link::Build('forum.php'); ?> >
        HELP
       </a>
  
       <a href=<?php echo  Link::Build('logout.php'); ?> >
        Logout
       </a> 
    </span> 


 <span class="user_name">
       <?php 
       echo '<span>'.$user_name.' '.'</span>';
       
       if(!empty($user_name))
       { 
         echo '<a href="'.Link::Build('myaccount.php').'">';
         echo '<img id="user_image" src="'.Link::Build('images/user_image.png').'" alt="user_image" />';
         echo '</a>';
       }
       ?>
  </span>  


<p class="account_tab">
  <a   <?php if($page==1) 
                echo 'class="item"';
             else 
                echo ''; ?> title="Displays a list of saved data" 
      href="<?php echo Link::Build('myaccount.php?page=1'); ?>">
  Saved Data
  </a>
  <a   <?php if($page==2) 
                echo 'class="item"';
             else 
                echo ''; ?> title="Displays a data form" href="<?php echo Link::Build('myaccount.php?page=2'); ?>">
   Data Details
  </a>
  <a   <?php if($page==3) 
                echo 'class="item"';
             else 
                echo ''; ?>title="Displays a data form" href="<?php echo Link::Build('myaccount.php?page=3&username='.$userName); ?>">
   Edit Account
  </a>
  <a title="Go back to Home page" href="<?php echo Link::Build('index.php'); ?>">
   Home Page
  </a>
</p>

  

</div> 
 
<?php 
}

 
if($page == 1) { 
?>


<table class="admin_table_list" >
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

<tr>
    <td colspan="6"> 
    <h1> CalculTELLER: My Account </h1>
    </td>
</tr>
<tr>
  <td colspan="6"><label>NUMBER of records to display</label>
   <select name="datarecords"> 
    <?php
    
    // Display select list for number of years of investment
  
    // Number of years/months range from 1 to 80
  
     for($i=0; $i < sizeof($arr); $i++)
     {
       echo   '<option value="'.$arr[$i].'"';
               if($arr[$i] ==  $dataRecords)
                echo 'selected';
       echo   ' >';
      
      
         echo     $arr[$i]; 
       
     
       echo   '</option>' ;
    }
    ?>
    </select> 
                          
 
   
  <input type="submit" name="recordsno" value="GO!" > <br />
  
  </td>
  </tr>  
<tr>
      <td>Data_Number</td>
      <td>Answer</td>
      <td>Description</td>
      <td>Save Date/Time</td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>   
 <!-- Display the number of rows of user data obtained from database-->
<?php

  
 // Get the number of records to display and build rows of display table
 
 // open connection to MySQL server and execute queries
 // Get number of records
  $startRecord = 0;
  $recordsDisplayed = '';

  $sql = "SELECT COUNT(*) FROM user_data
          WHERE username = '$userName'"; 

 $rows = getRow($sql, $params=NULL);
  
   // get total number of records
  $total_records = $rows['COUNT(*)'];
  
 
 // if records exist and number of records in database is less than or equal to 
 // specified dataRecords, then use the value of the number of records in db
  if (($total_records > 0)  )
  {
    if( $total_records <=  $dataRecords)
    {
       $recordsDisplayed = $total_records;
       $dataRecords = $total_records;
    }
    else
    {
       $recordsDisplayed = $dataRecords;
    }
  
    
    // create and execute query to get batch of records
    $query = "SELECT * FROM user_data 
              WHERE  username = '$userName' 
              ORDER BY saved DESC
              LIMIT $startRecord, $recordsDisplayed";   
    
    $result = getAll($query, $params=NULL);
    
     
     
     // Array function sizeof() is used to find the number of results return
     

  
 // Display specified number of records of user data
  for($j=0; $j < $dataRecords ; $j++) 
  {
     //  sanitize and edit data before from database before displaying it
     // PHP also allows you to slice a string into smaller parts with the substr()
     // e.g $str = 'Welcome to nowhere'; echo substr($str, 3, 4); 
       $dataId  = strip_tags($result[$j]['data_id']) ;
       $username = strip_tags($result[$j]['username']) ;
                                               
       $dataValue   = strip_tags($result[$j]['data_value']);

       $description = strip_tags(substr($result[$j]['description'], 0, 34));
       
       $saved  = strip_tags($result[$j]['saved']);
       
       $linkToDataString =   Link::Build('myaccount.php?page=2&dataId='.$dataId); 
       
       $linkToData = '<a class="datalink" title="View and Edit data details" href="'.
                      $linkToDataString. '"> Edit </a>';
                      
       // link to delete.php carrying dataId as query string
       $linkToDeleteIdString =   Link::Build('delete.php?deleteId='.$dataId); 
       
       $linkToDelete= '<a class="datalink" title="Delete data record" href="'.
                      $linkToDeleteIdString. '"> Delete </a>';
          
    
    echo '<tr>';
   
    echo  '<td>'. $dataId.'</td>';
    echo  '<td>'.$dataValue .'</td>';
    echo  '<td>'.$description.'</td>';
    echo  '<td>'.$saved.'</td>';
   
    echo  '<td>'.$linkToData;
    echo  '</td>';
   
    echo  '<td>';
    echo   '<input type="hidden" name="data_to_delete" value="'. $dataId.'"/>';
    echo   $linkToDelete;
    echo  '</td>';
    
   
  
    echo  '</tr>';
    
  }
  
 }
 else
 {
     echo '<br /><br /><br /><br /><br /><br />';
     echo '<center>';
     echo '<h2 style="color:#ff0000;"> No records available!</h2>';
     echo '<center>';
 }
 
 /*END OF PAGE 1 CODE*/
 } 
    
 ?> 

</form>
</table>


<?php


if($page == 2)
{

  if(isset($_GET['dataId']))
  { 
     // show Data Id if it is set from the list of userdata
     // Get data details from database for given dataId and store in
     //SESSION variables for display
    $dataId = $_GET['dataId'];
    
    // get data_id, data_value, description  and saved from database
    $query1 = "SELECT * FROM user_data 
             WHERE data_id = $dataId";       
     $result1 = getRow($query1, $params=NULL);
     
    
     $_SESSION['data_id'] = trim(strip_tags($result1['data_id']));  
     $_SESSION['answer']  = trim(strip_tags($result1['data_value'])); 

     $_SESSION['description'] = trim(strip_tags($result1['description'])); 
    
      $_SESSION['saved']  =  trim(strip_tags($result1['saved']));
      
      
  }
      

 if ($save) 
 { 
    // if save button is clicked
   // define valid array to hold sanitized values
   $valid = array(); 
   // validate all user data input and save to database and generate success message
   // and display link to go back to previous page or home page
      if (!empty($_SESSION['username']) ) { 
        $valid['username'] = htmlentities(trim($_SESSION['username']));  
      } else { 
        $inputErrors[] = 'all'; 
        $errorFlag = 1; 
      } 
      
      if (!empty($_SESSION['answer']) ) { 
        $valid['answer'] = htmlentities(trim($_SESSION['answer']));  
      } else { 
        $inputErrors[] = 'all'; 
        $errorFlag = 2; 
      } 
       if (!empty($_SESSION['description']) ) { 
        $valid['description'] = htmlentities(trim($_SESSION['description']));  
      } else { 
        $inputErrors[] = 'all'; 
        $errorFlag = 3; 
      } 
      
  // if there are no errors in input INSERT user details into database
  if(($errorFlag == 0) || count($inputErrors) == 0)
  {   
       // if data is valid, sanitize data before inserting it into database
       $username = addslashes($valid['username']) ;
                                               
       $dataValue   = addslashes($_SESSION['answer']);

       $description = addslashes($_SESSION['description']);
       
       $saved  = addslashes(date("Y-m-d H:i:s", time()));
    
       $lastInsertId = '';
      
       $insertRecordSuccessful = true;
     
  // Insert data into database 
  // Build the SQL query
  
  /**/
  
    $sql = "INSERT INTO user_data (username, data_value, description, saved) 
            VALUES ('$username', '$dataValue', '$description', '$saved')";

    // Execute the query
     $lastInsertId = executeQuery($sql, $params = null);
     
   
              
   unset($database_handler); 
   
        if($lastInsertId > 0)
         {
           // if user data save successfully, create message to display
           $insertRecordSuccessful = true;
           
         }                  
            
         else
         {
           // if user data was NOT saved, store error message
           
           $errorHeader = 'Error: We were unable to save data.
                            Try again!';
             $errorFlag = 1;   
           
           // DELETE this after testing subscriber code
           // exit();
         }  
   
  } 
 
 
 }
 
 if ($update) 
 { 
    // if update button is clicked
   // define valid array to hold sanitized values
   $valid = array(); 
   
    // get answer from form and save it in session and insert in dB
       
     $_SESSION['answer']  = (isset($_POST['answer']))? $_POST['answer']:$_SESSION['answer'] ;  

     $_SESSION['description'] = (isset($_POST['description']))? $_POST['description']:$_SESSION['description'] ;  
    
      $_SESSION['saved']  =  (isset($_POST['datetime']))? $_POST['datetime']:$_SESSION['saved'] ;
   
   
   
   // validate all user data input and save to database and generate success message
   // and display link to go back to previous page or home page
      if (isset( $_SESSION['data_id']) && is_numeric( $_SESSION['data_id']) ) { 
        $valid['dataId'] = (int)trim( $_SESSION['data_id']);  
      } else { 
        $inputErrors[] = 'all'; 
        $errorFlag = 1; 
      } 
     
      if (!empty($_SESSION['username']) ) { 
        $valid['username'] = htmlentities(trim($_SESSION['username']));  
      } else { 
        $inputErrors[] = 'all'; 
        $errorFlag = 1; 
      } 
      
      if (!empty($_SESSION['answer']) ) { 
        $valid['answer'] = htmlentities(trim($_SESSION['answer']));  
      } else { 
        $inputErrors[] = 'all'; 
        $errorFlag = 2; 
      } 
       if (!empty($_SESSION['description']) ) { 
        $valid['description'] = htmlentities(trim($_SESSION['description']));  
      } else { 
        $inputErrors[] = 'all'; 
        $errorFlag = 3; 
      } 
      
    // if there are no errors in input UPDATE user details into database
   if(($errorFlag == 0) || count($inputErrors) == 0)
   {    
       // if data is valid, sanitize data before Updating record in database
        $dataId  = addslashes($valid['dataId']);
        
       $username = addslashes($valid['username']) ;
                                               
       $dataValue   = addslashes($valid['answer']);

       $description = addslashes($valid['description']);
       
       $saved  = addslashes($_SESSION['saved']);
    
       $lastUpdateId = '';
       
       
         
    // Update data into database 
    // Build the SQL query
  
    $sql = "UPDATE   user_data SET 
              data_id = '$dataId',
               username = '$username' , 
               data_value = '$dataValue', 
               description= '$description',
               saved = '$saved' 
           WHERE data_id = '$dataId'";
               
               
                
            
    // Execute the query
     $lastUpdateId = executeQuery($sql, $params = null);
      
              
   unset($database_handler); 
   
        if($lastUpdateId == 0)
         {
           // if user data save successfully, create message to display
           $updateRecordSuccessful = true;
           
         }                  
            
         else
         {
           // if user data was NOT saved, store error message
           
           $errorHeader = 'Error: We were unable to update your data.
                            Try again!';
             $errorFlag = 1;   
           
           // DELETE this after testing subscriber code
           // exit();
         }  
    
   unset($database_handler); 
   
   
   }
 
 }
       
      
 if (($save = true && count($inputErrors) > 0) || $save == false || 
          ($save = true && $insertRecordSuccessful==true &&  $errorFlag == 0 ) ||
           ($update = true && $updateRecordSuccessful==true &&  $errorFlag == 0 ) ) 
 { 
  ?>
   <table cellspacing="5" cellpadding="5">
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

  <input type="hidden" name="domain" value="<?php echo $page; ?>"> 
  <tr>
     <td colspan="2"> 
     <h1> CalculTELLER: My Account: Store, Update and Retrieve your data  and personal
           information. </h1>
  <?php
 
   // display success message if no errors are encountered and action is successful
   // and display cancel link or (link to previous page visited by user)
   if($insertRecordSuccessful==true &&  $errorFlag == 0)
   {
       
      echo '<span class="success">'.'Data Saved Successfully! '.
             'Data Id: '. $lastInsertId. '</span>'.'<br />'.'<b>'.
          '<a href="'. $linkToPreviousPage.'">'. ' BACK to Previous Page'.
           '</a>'.'</b>' ;
   }
    // if update is successful
   elseif($updateRecordSuccessful==true &&  $errorFlag == 0)
   {
       
      echo '<span class="success">'.'Data record Updated Successfully! '.
             '</span>'.'<br />'.'<b>'.
          '<a href="'. $linkToPreviousPage.'">'. ' BACK to Previous Page'.
           '</a>'.'</b>' ;
   } 
   elseif(($insertRecordSuccessful==false || $updateRecordSuccessful==false)
                                 &&  ($errorFlag) > 0)
   {
     echo '<span class="error_header">'.$errorHeader.'</span>'.'<br />'.'<b>'.
          '<a href="'. $linkToPreviousPage.'">'. ' BACK to Home Page'.
           '</a>'.'</b>' ;
   
   }    
  ?>
     </td>
  </tr>
  <?php
   if(isset($dataId))
   { 
     
 
      echo '<tr>';
      echo '<td valign="top"><b>Data Id; </b></td>';
      echo  '<td>';
  
    
    
       echo  ' '.$dataId;
      
       echo  '</td>';
        echo  '</tr>'; 
      }  
  
  ?> 
    
  <tr>
     <td valign="top"><b>Answer</b></td>
     <td>
      <?php echo getInputError('all', $inputErrors); ?> 
       <input size="50" maxlength="250" type="text" name="answer" 
              value="<?php echo $_SESSION['answer']; ?>" >
     </td>
  </tr>                   
  <tr>
     <td valign="top"><b>Description</b></td>
     <td>
       <textarea name="description" cols="60" rows="8" >
       <?php echo $_SESSION['description']; ?>
       </textarea>
     </td>
  </tr>
  <tr>
     <td valign="top"><b>Saved Date/Time</b></td>
     <td>
       <input size="50" maxlength="250" type="text" name="datetime"
             value="<?php  
                    $dateTime = (isset($_GET['dataId']))?  $_SESSION['saved'] : 
                                      date("Y-m-d H:i:s", time());
                     echo $dateTime; ?>" >
     </td>
  </tr>    
  <tr>
     <td colspan=2>
     
       <?php if(!isset($dataId)){
      
           echo  '<input type="Submit" name="save" value="Save">';
         }
         else if(isset($dataId)) {
           echo '<input type="Submit" name="update" value="Update">';
         }
       ?>
       
       <a title="Go to Home Page" href="<?php echo LINK::Build('index.php'); ?>">
       |Cancel|
        </a>
     </td>
  </tr>
  </form>
 </table>

 <?php
  }

} 

if($page == 3)
{

 // if $_GET['username']is Not set  display error message
 // This ensures that this page is displayed ONLY for valid User
 if(!isset($_POST['username']) && !isset($_GET['username']))
 {
   echo '<h2> Error: Unrecognized user.</h2>
         <p> Please login and try again.
          <a href="login.php">Login.</a>
         </p>';
   
   exit();
 }

 // if form submitted 
 // validate form input 
if ($saveDetails) 
{ 
      
      $submitted = true; 
      $valid = array(); 
      $_username = '';
      $_email = '';
      
 
       // validate user name 
      if (!empty($_POST['name']) && (strlen($_POST['name']) >= 2  && strlen($_POST['name']) < 40)) { 
        $valid['name'] = htmlentities(trim($_POST['name']));  
      } else { 
        $inputErrors[] = 'name'; 
        $errorFlag = 1; 
      } 
      
    
  
      
       // validate username atmost 14 characters 
      if (!empty($_POST['username']) && preg_match('/^([a-zA-Z]){2,20}$/', $_POST['username']))
      { 
        $_username = htmlentities(trim($_POST['username'])); 
       
         // Check if submitted username is unique
         // create and execute SELECT query 
        $sql = "SELECT COUNT(*) FROM user
                WHERE username = '$_username'"; 

        $row1 = getOne($sql, $params=NULL);
        
        // Check if submitted username is unique and only belongs
        // to current logged in user 
        // if it is owned by current user then it is safe to
        // update it to current value knowing it is unique
        // and owned by just a single user in the database
        $sql = "SELECT COUNT(*) FROM user
                WHERE username = '$_username'
                AND username = '$userName'"; 

        $row2 = getOne($sql, $params=NULL);
 
         // username is unique and valid here if only one instance exist
         //  and it solely belongs to the current user
         // or the username does not exist in database
         // For Now Username Cannot be changed
         if(!($row1[0]== 1) || ($row1[0]== 1 && $row2[0] == 1))
         {
            $valid['username'] = htmlentities(trim($_username));
         }
         else
         {
          $inputErrors[] = 'Username-Already taken';
          $errorFlag = 2; 
         
         }
        
        
          
      } 
      else { 
        $inputErrors[] = 'Username';
        $errorFlag = 2; 
      } 
      
      // validate user email 
      if (!empty($_POST['email']) && preg_match('/^([a-z0-9_-])+([\.a-z0-9_-])*@([a-z0-9-])+(\ 
       .[a-z0-9-]+)*\.([a-z]{2,6})$/', $_POST['email'])) { 
       
        $_email = htmlentities(trim($_POST['email'])); 
       
        // Check if email is unique  
         // create and execute SELECT query 
        $sql = "SELECT COUNT(*) FROM user
                WHERE email = '$_email'"; 

        $row1 = getOne($sql, $params=NULL);
        
        // Check if email is unique and only belongs to current user 
        // if it is owned by current user then it is safe to
        // update it to current value knowing it is unique
        // and owned by just a single user in the database
        $sql = "SELECT COUNT(*) FROM user
                WHERE email = '$_email'
                AND username = '$userName'"; 

        $row2 = getOne($sql, $params=NULL);
 
         // email is unique here if only one instance exist
         //  and it solely belongs to the current user
         // or it does not exist in database
         if((!$row1[0]== 1) || ($row1[0]== 1 && $row2[0] == 1))
         {
            $valid['email'] = htmlentities(trim($_POST['email']));
         }
         else
         {
          $inputErrors[] = 'email-Already used';
          $errorFlag = 3; 
         
         }
       
      } else { 
        $inputErrors[] = 'email';
        $errorFlag = 3; 
      } 
 
      // validate user password Must start with Capital letter atleast 4 characters long
      // passord can accept any character in utf-8 or ansi
      if (!empty($_POST['password']) && preg_match('/^([A-Z])+(.){3,16}$/', $_POST['password']))  { 
        $valid['password'] = htmlentities(trim($_POST['password'])); 
      } else { 
        $inputErrors[] = 'password';
        $errorFlag = 4; 
      } 
      // validate user password Must start with Capital letter atleast 4 characters long
      if (!empty($_POST['passwordconfirm']) && preg_match('/^([A-Z])+(.){3,16}$/', $_POST['passwordconfirm']))  { 
        $valid['passwordconfirm'] = htmlentities(trim($_POST['passwordconfirm'])); 
      } else { 
        $inputErrors[] = 'password confirm'; 
        $errorFlag = 5;
      } 
      
      // validate telephone number
      // first replace any space, or _- with empty string use str_replace()
      // from phone number before testing
      
      if(!empty($_POST['phone'])){
           
           // first initialize $phoneCleaned to empty variable before
           // cleaning the string
            $phoneCleaned = '';
            $phoneCleanedInt = '';
            
            $phoneCleaned = (string)($_POST['phone']);
            $phoneCleaned = str_replace('+', '', $phoneCleaned);
            $phoneCleaned = str_replace(' ', '', $phoneCleaned);
            $phoneCleaned = str_replace('-', '', $phoneCleaned);
    
            $phoneCleanedInt = $phoneCleaned;
            $phoneCleaned = '';
            
          
      }
            
            
            
                 
      // save cleaned phone number into database not the number posted by user
      if (!empty($phoneCleanedInt) 
                    && is_numeric($phoneCleanedInt) 
                     && preg_match('/^([0-9]){4,16}$/', ($phoneCleanedInt))) 
      { 
        $valid['phone'] = htmlentities(trim($phoneCleanedInt)); 
        
        //echo $valid['phone'];
      } else { 
        $inputErrors[] = 'Telephone';
        $errorFlag = 6; 
      } 
      
       // validate user address 
      if (!empty($_POST['address']) && preg_match('/^([a-zA-Z0-9\-_]){2,40}$/', $_POST['address'])) { 
        $valid['address'] = htmlentities(trim($_POST['address'])); 
      } else { 
        $inputErrors[] = 'Address';
        $errorFlag = 7; 
      } 
      
      // validate user city 
       if (!empty($_POST['city']) && preg_match('/^([a-zA-Z0-9\-_]){2,40}$/', $_POST['city']))  { 
        $valid['city'] = htmlentities(trim($_POST['city'])); 
      } else { 
        $inputErrors[] = 'City';
        $errorFlag = 8; 
      }    
       // validate user region 
      if (!empty($_POST['region']) && preg_match('/^([a-zA-Z0-9\-_]){2,40}$/', $_POST['region'])) { 
        $valid['region'] = htmlentities(trim($_POST['region'])); 
      } else { 
        $inputErrors[] = 'Region';
        $errorFlag = 9; 
      }    
      // validate user country 
      if (!empty($_POST['country'])) { 
        $valid['country'] = htmlentities(trim($_POST['country'])); 
      } else { 
        $inputErrors[] = 'Country';
        $errorFlag = 10; 
      }  
      
      // Validate user password
      if (isset($valid['passwordconfirm']) && isset($valid['password']))
      {
        if  ($valid['passwordconfirm'] == $valid['password'])
        { 
          $valid['password'] = htmlentities(trim($_POST['password'])); 
        } else { 
        $inputErrors[] = 'Passwords Different'; 
        $errorFlag = 11;
        } 
      }
    
    
      
        $valid['date'] = date("Y-m-d H:i:s", time());
        
        
      
      if($errorFlag > 0)
        $errorHeader = 'ERROR: Form filled incorrectly <br />
                       Make sure there are no empty fields.
                     Please  correct errors and trying again!';
      
 // if there are no errors in input UPDATE user details in database
 if(($errorFlag == 0) || count($inputErrors) == 0)
 { 
    
  // sanitize data and insert into database including date
  $name = addslashes($valid['name']);
  $username = addslashes($valid['username']);
  $password = addslashes($valid['password']);
  $email = addslashes($valid['email']);
  $address = addslashes($valid['address']);
  $city = addslashes($valid['city']);
  $region = addslashes($valid['region']);
  $country = addslashes($valid['country']);
  $phone = addslashes($valid['phone']);
  $date = addslashes($valid['date']);
  $password = PasswordHasher::Hash($password, true);
 
 
  
   // Insert data into database: user table 
   // Build the SQL query
  
    // Update data into database 
    // Build the SQL query
  
    $sql = "UPDATE   user SET 
                    name = '$name',
                username = '$username',
                password = '$password',
                   email = '$email',
                 address = '$address',
                    city = '$city',
                  region = '$region',
                 country = '$country',
                   phone = '$phone', 
                  lvisit = '$date'
          
          WHERE username = '$userName'"; 
                  
                  
           

    // Execute the query
     $lastInsertId1 = '';
     $lastInsertId1 = executeQuery($sql, $params = null);
     
     // update user_data table 
     // Build the SQL query
    $sql = "UPDATE   user_data SET 
                     username = '$username'
            WHERE    username = '$userName'"; 
                  
                  
    // Execute the query
     $lastInsertId2 = '';
     $lastInsertId2 = executeQuery($sql, $params = null);
     
     
    
         if($lastInsertId1 == 0 && $lastInsertId2 == 0)
         {
           // if user data save successfully, create message to display
           $insertRecordSuccessful = true;
           
           // update username session variable
           $_SESSION['username'] = $username;
           $userName = $_SESSION['username']; 
           
         }                  
            
         else
         {
           // if user data was NOT saved, store error message
           
           $errorHeader = 'Error: We were unable to save your details.
                            Try again!';
             $errorFlag = 1;   
           
           // DELETE this after testing subscriber code
           // exit();
         }  
   }               
} 
 
    // if form not submitted 
    // or if validation errors exist 
    // (re)display form 
if (($saveDetails == true && count($inputErrors) > 0) || $saveDetails == false
      || ($saveDetails == true && count($inputErrors) <= 0)) 
{ 

     // get list of countries 
     $query1 = "SELECT city_id, country FROM city";
    $result1 = getAll($query1, $params = null);
    
    // variable containing list of countries
    $countries = $result1;
    
    // create and execute query to get user records
    $query2 = "SELECT * FROM user 
              WHERE  username = '$userName'";   
    
    $result2 = getAll($query2, $params=NULL);
    
    
     // sanitize data retrieved from database for display in form
  $name = strip_tags($result2[0]['name']);
  $username = strip_tags($result2[0]['username']);
  $password = strip_tags($result2[0]['password']);
  $email = strip_tags($result2[0]['email']);
  $address = strip_tags($result2[0]['address']);
  $city = strip_tags($result2[0]['city']);
  $region = strip_tags($result2[0]['region']);
  $country = strip_tags($result2[0]['country']);
  $phone = strip_tags($result2[0]['phone']);
  $date = strip_tags($result2[0]['lvisit']);
  
  
  
  unset($database_handler); 
  
  
 
  // display success message if no errors are encountered and action is successful
   // and display cancel link or (link to previous page visited by user)
   if($insertRecordSuccessful==true &&  $errorFlag == 0)
   {
       
      echo '<span class="success">'.'Your Data has been Saved Successfully! '.
            '</span>'.'<br />'.'<b>'.
          '<a href="'. $linkToCancelPage.'">'. ' BACK to Home Page'.
           '</a>'.'</b>' ;
   }
   elseif($insertRecordSuccessful==false &&  $errorFlag > 0)
   {
     echo '<span class="error_header">'.$errorHeader.'</span>'.'<br />'.'<b>'.
          '<a href="'. $linkToCancelPage.'">'. ' BACK to Home Page'.
           '</a>'.'</b>' ;
   
   } 
   
   
                                     
  
 ?>
                 
  <br /> 
  <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="signup_form">
  <h3>Please enter your details and update your account</h3>
  <table class="user-table">
  
    <input type="hidden" name="username" 
                 value="<?php echo $userName; ?>">
  
     <tr>
      <td>Name:</td>
      <td>
        <input type="text" name="name"  
        value="<?php echo isset($_POST['name']) ? $_POST['name'] : $name;?>" 
        size="40" maxlength="50"/>
        <?php echo getInputError('name', $inputErrors); ?> 
      </td> 
      <td><em><small>*Atmost 50 character</small></em></td>
    </tr>
    <tr>
      <td>Username:</td>
      <td>
        <input type="text" name="username"  
        value="<?php echo isset($_POST['username']) ? $_POST['username'] : $username;?>" 
        size="32" maxlength="20" />
        <?php echo getInputError('Username', $inputErrors); ?> 
        <?php echo getInputError('Username-Already taken', $inputErrors); ?> 
      </td>
      <td><em><small>*Atmost 20 characters</small></em></td>
    </tr>
     <tr>
      <td>E-mail Address:</td> 
      <td>
      <input type="text" name="email"  maxlength="100"
        value="<?php echo isset($_POST['email']) ? $_POST['email'] : $email;?>" 
        <?php if($editMode="readonly") echo 'size="40"';?> /> 
        <?php echo getInputError('email-Already used', $inputErrors); ?> 
        
      <?php echo getInputError('email', $inputErrors); ?> 
      </td>
      <td><em>*Required</em></td>
    </tr>
    
     <tr>
      <td>Password:</td>
      <td>
        <input type="password" name="password" size="40" maxlength="40"
         value="<?php echo isset($_POST['password']) ? $_POST['password'] : '';?>" />
        <?php echo getInputError('password', $inputErrors); ?> 
        <?php echo getInputError('Passwords Different', $inputErrors); ?> 
         
      </td>
      <td><em><small>*Must start with a Capital Letter</small></em></td>
    </tr>
    <tr>
      <td>Re-enter Password:</td>
      <td>
        <input type="password" name="passwordconfirm" size="40" maxlength="40"
         value="<?php echo isset($_POST['passwordconfirm']) ? $_POST['passwordconfirm'] : '';?>"/>
        <?php echo getInputError('password confirm', $inputErrors); ?>
        
      </td>
      <td><em><small>*Must start with a Capital Letter</small></em></td>
    </tr>
    <tr>
      <td>Address:</td>
      <td>
        <input type="text" name="address"  value="<?php echo isset($_POST['address']) ? $_POST['address'] : $address;?>"
          <?php if($editMode) echo 'size="32"';?> maxlength="50" />
        <?php echo getInputError('Address', $inputErrors); ?>     
        
      </td>
      <td><em><small>*Atmost 50 character</small></em></td>
    </tr>
    <tr>
      <td>City:</td>
      <td>
        <input type="text" name="city"  value="<?php echo isset($_POST['city']) ? $_POST['city'] : $city;?>"
          <?php if($editMode) echo 'size="32"';?>  maxlength="50" />
        <?php echo getInputError('City', $inputErrors); ?>     
        
      </td>
      <td><em><small>*Atmost 50 character</small></em></td>
    </tr>
    
    <tr>
      <td>Region:</td>
      <td>
        <input type="text" name="region"  value="<?php echo isset($_POST['region']) ? $_POST['region'] : $region;?>"
          <?php if($editMode) echo 'size="32"';?> maxlength="50" />
        <?php echo getInputError('Region', $inputErrors); ?>     
        
      </td>
      <td><em><small>*Atmost 50 character</small></em></td>
    </tr>
    
    
    <tr>
      <td>Telephone:</td>
      <td>
        <input type="text" name="phone"  value="<?php echo isset($_POST['phone']) ? $_POST['phone'] : $phone;?>"
          <?php if($editMode) echo 'size="32"';?> maxlength="50" />
        <?php echo getInputError('Telephone', $inputErrors); ?>
          
        
      </td>
      <td><em><small>* e.g 111 222 11111</small></em></td>
    </tr>
    <tr>
      <td>Country:</td>
      <td>
        <select name="country"> 
    <?php
    
    // Display a timezone select element with different timezones as options
  
     for($i=0; $i < sizeof($countries); $i++)
     {
       echo   '<option value="'.$countries[$i]['country'].'"';
               if($countries[$i]['country'] == 'United States' && !isset($country) )
                  echo 'selected';
               elseif(isset($country) && ($country ==$countries[$i]['country']))
                  echo 'selected';
       echo   ' >';
      
        
          echo    $countries[$i]['country']; 
       
     
       echo   '</option>' ;
    }
    ?>
    </select>
        <?php echo getInputError('Country', $inputErrors); ?>
          
        
      </td>
    </tr>
    
    
      
  <tr>
    <td>
       <input type="submit" name="save_details" value="SAVE" /> |
   <a href="<?php  echo $linkToCancelPage; ?>">Cancel</a>
    </td>
 </tr>
 </table>
 
 
    
    
  </form> 
  


<?php 

} 



?>



<?php

//END OF PAGE 3 CODE BRACE
}
 
?>
<!-- standard page footer -->

   <div id="formft">
     <hr />
    <p>Terms and Conditions | Privacy Policy | Support(image) | Tel (image)651817527 </p>
    <p> Copyright © 2017, CalculTeller SIKEH (signature at bottom right in Gold color or Silver.)</p>
     
   </div>
  </div> 
  
   <!--Colored menu links script-->
       <script>
            var anchorArr = document.getElementsByTagName("a");
            
            
            for(var i=0; i<anchorArr.length; i++)
            {
              
              if(anchorArr[i].className=="item")
              {   
                
                     
                     anchorArr[i].className="selected";
                     //alert(anchorArr[i].className);
                      
                
              }
              
               else if(anchorArr[i].className=="item_mobile")
               {
                  
                     anchorArr[i].className = "selected_mobile";
                    
               }
            }
        </script>     
  
 </body>
</html>
