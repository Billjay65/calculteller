<?php
if(true /*mail('japhet@yahoo.com','test message','This is the mail body')*/){
     if(true)
     {
       echo 'I am nested in here';
       return true;
     }
     echo('ok');
     
     //echo 'Code execution still going on';
     echo "I am still here oh";
     }
else{
  echo 'Unable to send';
  return true;
}

echo 'Code execution still going on';
?>