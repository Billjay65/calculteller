<?php

// start session and store session user variable
session_start();
$username = (!isset($_SESSION['username']))? '' : $_SESSION['username'] ;
$old_user = $username;

// include config file containing directory paths
 require_once 'include/config.php';
 
 // include error handling class php file
 require_once 'error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 // Get web browser language of User 
// get first value(Primary Language) from language array
 $browserLanguage = $_SERVER['HTTP_ACCEPT_LANGUAGE'][0] 
                      . $_SERVER['HTTP_ACCEPT_LANGUAGE'][1];
                      
  // Get selected language of page default is en
  // include language configuration file based on selected language
	$language = "en";
                      
  // Create session variable to store selected language
  if(isset($_SESSION['language'])){
     $userLanguage = $_SESSION['language'];
     $language     = $userLanguage; 
  }
  else{
     $userLanguage = ''; 
  }
 
 

  
  // read browser language Only when user language SESSION variable
  // is NOT SET(equals ''), if userLanguage is set, do not use browser language
  if((!empty($browserLanguage)) && ($browserLanguage == 'en' ||
       $browserLanguage == 'fr' || $browserLanguage == 'es'
       || $browserLanguage == 'zh')
      && ($userLanguage =='')){
    $language = $browserLanguage;
      
  }
  
	if(isset($_GET['lang'])){ 
		$language = $_GET['lang'];
    $_SESSION['language'] = $language;
     
	} 
 
   
  // get language file based on user's language
	require_once(SITE_ROOT."/values/".$language.".php");
 
 
 

// Call the home page to display html content on screen

//store to test if they *were* logged in 
unset($_SESSION['username']);
$result_dest = session_destroy();

// start output html
fixed_html_header('CalculTELLER: Logout, logs user out and closes his account',
                      'Logging out ...', null);

fixed_html_sidebar();
display_domains_list();
fixed_html_content();


if(!empty($old_user))
{
  if($result_dest)
  {
    // if they were logged in and are now logged out
    echo '<center>'.'Logged out!'.'</center>'.'<br />';
    
    //do_html_url('login.php', 'Login');
  }
  else
  {
    // they were logged in and could not be logged out 
    echo '<center>'.'Could not log you out'.'</center>'.'<br />';
  }
}
else 
{
  // if they weren't logged in but came to this page somehow 
  echo '<center>'.'You were not logged in , and so have not been logged out'.
        '</center>'.'<br />';
  //do_html_url('login.php', 'Login');
}
display_domain_image_links();
fixed_html_ads();
fixed_html_footer();

?>










