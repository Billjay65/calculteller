

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
 
 <head>
   
 <title> Calculteller: ...function determines the ....</title>
   
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <link rel="icon" type="image/png" href="images/logo2.png" />
  
  <link type="text/css" rel="stylesheet" href="styles/calculteller.css" />
  
  
  </head>
  
  
<body>
     
<div id="doc" class="calcult">
    
    <div id="header">
       <img id="logo" src="images/logo2.png"  alt="Logo-calculteller" />
       <h1 id="app-name">CalculTELLER </h1>  
       <span>SOCIAL MEDIA, REGISTER and other...</span>
    </div>
 
    <div id="sidebar">
      side bar: contains SEARCH BOX at the top and CalcuTeller functions..
    </div>
    
    <div id="ct-main">
            
       CONTENTS and tabs of each function found in left side bar
            
    </div>
    
    <div id="ads">
      Ads: google adsence.......
    </div>
        
    <div id="ft">
       <p>Terms and Conditions | Privacy Policy | Support(image) | Tel (image)651817527 </p>
       <p>Copyright 2017, CalculTeller SIKEH (signature at bottom right in Gold color or Silver.)</p>
     </div>
        
 </div>
 
 </body>
</html>

