<?php

 // start session, authenticate user....
 session_start();
 
 // Start output buffer
 ob_start();
 
 // include config file containing directory paths
 require_once 'include/config.php';
 
 // include error handling class php file
 require_once 'error_handler.php';

 // Set the error handler
 ErrorHandler::SetHandler();
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';
 
 
 
 $user_name = (!isset($_SESSION['name']))? '' : 'Hi, '.$_SESSION['name'] ;
 
 //Flag to see if user is a member(Registered to Calculteller)
 $member= ($user_name!='')? true : false ;
 
 
 // Call the home page functions to display html content on screen
 
 fixed_html_header('CalculTELLER: About Us',
                      '', $user_name, $member);
fixed_html_sidebar();
display_domains_list();
fixed_html_content();

?>

  <div class="extra_page_content">
    <h1>Cookies</h1>
     
      <p>
        Calculteller uses <b>cookies</b> to store small pieces of information
        on your device in order to improve your experience when using the app.
         The cookies are safe and the information is used only within
        calculteller. We do not share your information with third parties.
         We value your privacy and your information is safe.
      </p>
      
      
    
    <!--End of extra-page-content div-->
  </div>
<?php

fixed_html_ads();
fixed_html_footer();
 
 unset($database_handler);
 
 // Output content from the buffer
flush();
ob_flush();
ob_end_clean();
?>