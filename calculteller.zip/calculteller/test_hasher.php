<?php
if (isset ($_GET['to_be_hashed']))
{
 // include config file containing directory paths
 require_once 'include/config.php';
 
 // include the calculteller functions file containing all fns
 require_once FUNCTIONS_DIR. 'calculteller_fns.php';

  $original_string = $_GET['to_be_hashed'];

  echo 'The hash of "' . $original_string . '" is ' .
       PasswordHasher::Hash($original_string, false);

  echo '<br />';

  echo '... and the hash of "' . HASH_PREFIX . $original_string .
       '" (secret prefix concatenated with password) is ' .
       strlen(PasswordHasher::Hash($original_string, true));
       
  
}
// Test time() replacement for mktime()     
  echo time();
  $date1 =  date("Y-m-d H:i:s", time());
  echo $date1;
  
  $date2 =  date("Y-m-d H:i:s");
  echo $date2;
  print_r(getdate());
  
?>

<br /><br />
<form action="test_hasher.php">
  Write your password:
  <input type="text" name="to_be_hashed" /><br />
  <input type="submit" value="Hash it" />
</form>
