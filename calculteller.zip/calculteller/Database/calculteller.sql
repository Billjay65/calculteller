-- Create calculteller database
CREATE DATABASE calculteller;
       DEFAULT CHARACTER SET 'utf8' COLLATE 'utf8_unicode_ci';
 
USE calculteller;
 
 -- Create calculteller user
GRANT ALL PRIVILEGES ON calculteller.*
      TO calcultellerberyuf@localhost  IDENTIFIED BY 'sefakcalcultellerberyuf3'
      WITH GRANT OPTION;
 
 --CT Create user table
CREATE TABLE user
( 
  name     VARCHAR(50)   NOT NULL,
  username VARCHAR(15)   NOT NULL,
  password VARCHAR(50)   NOT NULL,
  email    VARCHAR(100)  NOT NULL,
  address  VARCHAR(100), 
  city     VARCHAR(100),
  region   VARCHAR(100),
  country  VARCHAR(100)  NOT NULL,
  phone    VARCHAR(100),
  lvisit   DATETIME, 
  PRIMARY KEY (username),
  UNIQUE KEY idx_user_email (email) 
)ENGINE=MyISAM;

--CT create user_data table
CREATE TABLE user_data
(
 data_id     INT    NOT NULL AUTO_INCREMENT,
 username    VARCHAR(15)   NOT NULL,
 data_value  VARCHAR(100)  NOT NULL,
 description VARCHAR(255),
 saved       DATETIME,
 PRIMARY KEY (data_id),
 KEY idx_user_data_username (username)
)ENGINE=MyISAM;

--CT create domain table
CREATE TABLE domain
(
  domain_id   INT NOT NULL AUTO_INCREMENT,
  name        VARCHAR(100) NOT NULL,
  description VARCHAR(255),
  image       VARCHAR(150),
  PRIMARY KEY (domain_id),
  UNIQUE KEY (name)
)ENGINE=MyISAM;

--CT populate domain table
INSERT INTO domain (domain_id, name, description, image)  VALUES
       (1, 'Balance', 'Calculates the balance of a buyer or seller','balance.png'),
       (2, 'Bet', 'Calculates bet wins and losses','bet.png'),
       (3, 'Proportion', 'Calculates simple proportion and predicts the future','proportion.png'),
       (4, 'Time', 'Calculates  time of different time zones of the globe','time.png'),
       (5, 'Business', 'Calculates  profits and losses to investment in business','business.png'),
       (6, 'Bank', 'Calculates interest, loans and dividents.','bank.png');
       (7, 'School', 'Calculates averages, coefficients and position of students','school.png'),

  --CT Create domain_tab table
CREATE TABLE domain_tab
( 
  tab_id     INT NOT NULL AUTO_INCREMENT,
  domain_id   INT NOT NULL,
  tab_name   VARCHAR(50),
  PRIMARY KEY (tab_id) 
)ENGINE=MyISAM;
 
 --CT populate domain_tab table
INSERT INTO domain_tab (tab_id, domain_id, tab_name)  VALUES 
       (1, 1, 'Buyer'),  
       (2, 1, 'Seller'),
       (3, 2, 'Parifoot'),
       (4, 2, 'Fair_Play'),
       (5, 7, 'Average') ,
       (6, 7, 'Score') ,
       (7, 3, 'Simple') ,
       (8, 5, 'Investment'),
       (9, 5, 'Shop'),
       (10, 6, 'Loan'), 
       (11, 6, 'Savings');
       
 
  --CT Create unit table
CREATE TABLE unit
( 
  unit_id     INT NOT NULL AUTO_INCREMENT,
  abbrevation VARCHAR(50)  NOT NULL,
  unit_name   VARCHAR(50)  NOT NULL,
  PRIMARY KEY (unit_id) 
)ENGINE=MyISAM;  


--CT Populate unit table
INSERT INTO unit (unit_id, abbrevation, unit_name)  VALUES
    (1, 'unit', 'unit(s)'),
    (2, 'mm', 'millimeter(s)'),
    (3, 'cm', 'centimeter(s)'),
    (4, 'm', 'meter(s)'),
    (5, 'km', 'kilometer(s)'),
    (6, 's', 'second(s)'),
    (7, 'mn', 'minute(s)'),
    (8, 'h',  'hour(s)'),
    (9, 'dy',  'day(s)'),
    (10, 'mth', 'month(s)'),
    (11, 'yr', 'year(s)'),
    (12, 'wk', 'week(s)'),
    (13, 'deg', 'degree(s)'),
    (14, 'USD', 'US Dolar(s)'),
    (15, 'FRS', 'Francs CFA'),
    (16, 'm2', 'square meters'),
    (17, 'km2', 'square kilometers'),
    (18, 'ha', 'hectare(s)'),
    (19, 'L', 'liter(s)'),
    (20, '%', 'percent'),
    (21, 'person(s)' 'person(s)');
   
       
 --CT Create domain_unit linking table(many-to-many relationship) 
 CREATE TABLE domain_unit (
 domain_id     INT NOT NULL,
 unit_id       INT NOT NULL,
PRIMARY KEY (domain_id, unit_id)
) ENGINE=MyISAM;



-- CT Populate domain_unit  table automatically (CROSS JOIN)
INSERT INTO domain_unit (domain_id, unit_id)
SELECT d.domain_id, u.unit_id 
FROM domain d, unit u;

-- CT Populate domain_unit table with newly added unit (person, id = 21)
INSERT INTO domain_unit (domain_id, unit_id)
 SELECT d.domain_id, u.unit_id
 FROM   domain d, unit u
 WHERE  u.unit_id = 21;
 
--CT query to get units for a given  domain  
SELECT        u.unit_id, u.abbrevation, u.unit_name
FROM     unit u
WHERE    u.unit_id IN
(SELECT unit_id
FROM    domain_unit
WHERE   domain_id = $domainId)  
ORDER BY u.unit_id;    

--CT query to get tabs from the domain_tab table for a given domain
SELECT tab_id, tab_name from domain_tab
WHERE  domain_id = $domainId ;
 
--CT query to create CITY table to store countries and cities for TIMEZONES
// create country table in calculteller database
CREATE TABLE city (
city_id     INT NOT NULL AUTO_INCREMENT,
city_name   CHAR(35) NOT NULL,  
country     CHAR(52) NOT NULL,
continent   CHAR(52) NOT NULL,
PRIMARY KEY (city_id)
)ENGINE=MyISAM; 

--CT query to populate the CITY table with values from world db tables
INSERT INTO city
SELECT c.Name, t.Name, t.Continent 
FROM  city c
INNER JOIN country t
ON    c.CountryCode = t.Code
GROUP BY t.Name
ORDER BY t.Name;

--CT query to populate the CITY table of CalculTeller db with values selected from world db
INSERT INTO  city (city_name, country, continent)
       VALUES
--CT  query to get ALL countries in the world from the city table and adding to user signup
SELECT city_id, country FROM city;

--CT Update MLM tables, lists and subsribers, add language feature... 1=en, 2=fr,
ALTER TABLE lists ADD language tinyint  NOT NULL  DEFAULT 1;
ALTER TABLE subscribers ADD language tinyint  NOT NULL  DEFAULT 1;       





/*
-- Populate attribute_value table
INSERT INTO `attribute_value` (`attribute_value_id`, `attribute_id`, `value`)
VALUES
(1, 1, 'S'), (2, 1, 'M'), (3, 1, 'L'), (4, 1, 'XL'), (5, 1, 'XXL'),
(6, 2, 'White'),  (7, 2, 'Black'), (8, 2, 'Red'), (9, 2, 'Orange'),
(10, 2, 'Yellow'), (11, 2, 'Green'), (12, 2, 'Blue'),
(13, 2, 'Indigo'), (14, 2, 'Purple');
3. Create and populate the product_attribute table, using the code in the following listing:
-- Create product_attribute table (associates attribute values to products)
CREATE TABLE `product_attribute` (
`product_id`         INT NOT NULL,
`attribute_value_id` INT NOT NULL,
PRIMARY KEY (`product_id`, `attribute_value_id`)
) ENGINE=MyISAM;
-- Populate product_attribute table
INSERT INTO `product_attribute` (`product_id`, `attribute_value_id`)
SELECT `p`.`product_id`, `av`.`attribute_value_id`
FROM   `product` `p`, `attribute_value` `av`;

-- Create catalog_get_product_attributes stored procedure
CREATE PROCEDURE catalog_get_product_attributes(IN inProductId INT)
BEGIN
SELECT     a.name AS attribute_name,
av.attribute_value_id, av.value AS attribute_value
FROM       attribute_value av
INNER JOIN attribute a
ON av.attribute_id = a.attribute_id
WHERE      av.attribute_value_id IN
(SELECT attribute_value_id
FROM   product_attribute
WHERE  product_id = inProductId)
ORDER BY   a.name;
END$$ 
      

  
  
      
 -- Create product table
CREATE TABLE `product` (
  `product_id`       INT            NOT NULL AUTO_INCREMENT,
  `name`             VARCHAR(100)   NOT NULL,
  `description`      VARCHAR(1000)  NOT NULL,
  `price`            NUMERIC(10, 2) NOT NULL,
  `discounted_price` NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
  `image`            VARCHAR(150),
  `image_2`          VARCHAR(150),
  `thumbnail`        VARCHAR(150),
  `display`          SMALLINT       NOT NULL DEFAULT 0,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM;
-- Populate shipping_region table
INSERT INTO `shipping_region` (`shipping_region_id`, `shipping_region`) VALUES
       (1, 'Please Select') , (2, 'US / Canada'),
       (3, 'Europe'),         (4, 'Rest of World');

-- Create customer table
CREATE TABLE `customer` (
  `customer_id`        INT           NOT NULL  AUTO_INCREMENT,
  `name`               VARCHAR(50)   NOT NULL,
  `email`              VARCHAR(100)  NOT NULL,
  `password`           VARCHAR(50)   NOT NULL,
  `credit_card`        TEXT,
  `address_1`          VARCHAR(100),
  `address_2`          VARCHAR(100),
  `city`               VARCHAR(100),
  `region`             VARCHAR(100),
  `postal_code`        VARCHAR(100),
  `country`            VARCHAR(100),
  `shipping_region_id` INTEGER       NOT NULL  DEFAULT 1,
  `day_phone`          VARCHAR(100),
  `eve_phone`          VARCHAR(100),
  `mob_phone`          VARCHAR(100),
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `idx_customer_email` (`email`),
  KEY `idx_customer_shipping_region_id` (`shipping_region_id`)
)ENGINE=MyISAM;






-- Create catalog_delete_category stored procedure
DELIMITER $$
CREATE PROCEDURE catalog_delete_category(IN inCategoryId INT)
BEGIN
DECLARE productCategoryRowsCount INT;
SELECT      count(*)
FROM        product p
INNER JOIN  product_category pc
ON p.product_id = pc.product_id
WHERE       pc.category_id = inCategoryId
INTO        productCategoryRowsCount;
IF productCategoryRowsCount = 0 THEN
DELETE FROM category WHERE category.category_id = inCategoryId;
SELECT 1;
ELSE
SELECT -1;
END IF;

-- Create catalog_delete_product stored procedure
CREATE PROCEDURE catalog_delete_product(IN inProductId INT)
BEGIN
  DELETE FROM product_attribute WHERE product_id = inProductId;
  DELETE FROM product_category WHERE product_id = inProductId;
  DELETE FROM product WHERE product_id = inProductId;
END$$

-- Create catalog_remove_product_from_category stored procedure
CREATE PROCEDURE catalog_remove_product_from_category(
  IN inProductId INT, IN inCategoryId INT)
BEGIN
  DECLARE productCategoryRowsCount INT;

  SELECT count(*)
  FROM   product_category
  WHERE  product_id = inProductId
  INTO   productCategoryRowsCount;

  IF productCategoryRowsCount = 1 THEN
    CALL catalog_delete_product(inProductId);

    SELECT 0;
  ELSE
    DELETE FROM product_category
    WHERE  category_id = inCategoryId AND product_id = inProductId;

    SELECT 1;
  END IF;
END$$

-- Create catalog_delete_category stored procedure
DELIMITER $$
CREATE PROCEDURE catalog_delete_category(IN inCategoryId INT)
BEGIN
DECLARE productCategoryRowsCount INT;
SELECT      count(*)
FROM        product p
INNER JOIN  product_category pc
ON p.product_id = pc.product_id
WHERE       pc.category_id = inCategoryId
INTO        productCategoryRowsCount;
IF productCategoryRowsCount = 0 THEN
DELETE FROM category WHERE category.category_id = inCategoryId;
SELECT 1;
ELSE
SELECT -1;
END IF;

*/